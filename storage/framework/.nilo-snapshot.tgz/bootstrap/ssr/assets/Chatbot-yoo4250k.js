import { jsx, jsxs } from "react/jsx-runtime";
import { MessageCircle, Bot, Minimize2, Send } from "lucide-react";
import { useState } from "react";
const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: "1",
      text: "Hi, my name is Nilo, your AI invoice assistant. How can I help you today?",
      isBot: true,
      timestamp: /* @__PURE__ */ new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const botResponses = [
    {
      keywords: ["price", "pricing", "cost", "plan"],
      response: "Our pricing is simple: Free forever plan, Professional at $19/month, and Enterprise at $49/month. All plans include a 14-day free trial!"
    },
    {
      keywords: ["feature", "what", "can", "do"],
      response: "Nilo offers unlimited invoices, beautiful templates, payment processing, client management, reporting, and much more!"
    },
    {
      keywords: ["trial", "free", "demo"],
      response: "Yes! We offer a 14-day free trial with no credit card required. You can try all Professional features risk-free."
    },
    {
      keywords: ["support", "help", "contact"],
      response: "We provide email support for all users, priority support for Professional users, and dedicated support for Enterprise. You can reach us at hello@invoiceflow.com"
    },
    {
      keywords: ["integration", "connect", "api"],
      response: "We integrate with popular payment processors like Stripe, and offer API access for Enterprise customers. More integrations coming soon!"
    },
    {
      keywords: ["security", "safe", "data"],
      response: "Your data is protected with bank-level encryption, regular backups, and 99.9% uptime. We take security very seriously!"
    },
    {
      keywords: ["hello", "hi", "hey"],
      response: "Hi, my name is Nilo, your AI invoice assistant. What would you like to know?"
    }
  ];
  const sendMessage = () => {
    if (!inputMessage.trim()) return;
    const userMessage = {
      id: Date.now().toString(),
      text: inputMessage,
      isBot: false,
      timestamp: /* @__PURE__ */ new Date()
    };
    setMessages((prev) => [...prev, userMessage]);
    setInputMessage("");
    setIsTyping(true);
    setTimeout(() => {
      const lowerInput = inputMessage.toLowerCase();
      const matchedResponse = botResponses.find(
        (response) => response.keywords.some(
          (keyword) => lowerInput.includes(keyword)
        )
      );
      const botMessage = {
        id: (Date.now() + 1).toString(),
        text: matchedResponse?.response || "Thanks for your message! For specific questions, please contact our support team at hello@nilo.com or use the contact form below.",
        isBot: true,
        timestamp: /* @__PURE__ */ new Date()
      };
      setMessages((prev) => [...prev, botMessage]);
      setIsTyping(false);
    }, 1e3);
  };
  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };
  return /* @__PURE__ */ jsx("div", { className: "fixed right-6 bottom-6 z-50", children: !isOpen ? /* @__PURE__ */ jsxs("div", { className: "group relative", children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        onClick: () => setIsOpen(true),
        className: "transform rounded-full bg-brand p-4 text-white shadow-lg transition-all duration-300 hover:scale-110 hover:shadow-xl",
        "aria-label": "Open chatbot",
        children: /* @__PURE__ */ jsx(MessageCircle, { className: "h-6 w-6" })
      }
    ),
    /* @__PURE__ */ jsx("span", { className: "pointer-events-none absolute bottom-full left-1/2 mb-2 w-max -translate-x-1/2 scale-0 rounded bg-gray-800 px-2 py-1 text-xs text-white opacity-0 transition-all group-hover:scale-100 group-hover:opacity-100", children: "Chat with your AI assistant" })
  ] }) : /* @__PURE__ */ jsxs("div", { className: "flex h-96 w-80 flex-col rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-700 dark:bg-slate-800", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between rounded-t-2xl bg-brand p-4 text-white", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-start space-x-3", children: [
        /* @__PURE__ */ jsx("div", { className: "flex h-8 w-8 items-center justify-center rounded-full bg-white/20", children: /* @__PURE__ */ jsx(Bot, { className: "h-4 w-4" }) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h4", { className: "font-semibold", children: "Nilo" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs opacity-90", children: "Your AI invoice assistant" })
        ] })
      ] }),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => setIsOpen(false),
          className: "text-white/80 transition-colors hover:text-white",
          children: /* @__PURE__ */ jsx(Minimize2, { className: "h-5 w-5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex-1 space-y-4 overflow-y-auto p-4", children: [
      messages.map((message) => /* @__PURE__ */ jsx(
        "div",
        {
          className: `flex ${message.isBot ? "justify-start" : "justify-end"}`,
          children: /* @__PURE__ */ jsx(
            "div",
            {
              className: `max-w-xs rounded-2xl px-4 py-2 ${message.isBot ? "bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-white" : "bg-brand text-white"}`,
              children: /* @__PURE__ */ jsx("p", { className: "text-sm", children: message.text })
            }
          )
        },
        message.id
      )),
      isTyping && /* @__PURE__ */ jsx("div", { className: "flex justify-start", children: /* @__PURE__ */ jsx("div", { className: "rounded-2xl bg-slate-100 px-4 py-2 dark:bg-slate-700", children: /* @__PURE__ */ jsxs("div", { className: "flex space-x-1", children: [
        /* @__PURE__ */ jsx("div", { className: "h-2 w-2 animate-bounce rounded-full bg-slate-400" }),
        /* @__PURE__ */ jsx(
          "div",
          {
            className: "h-2 w-2 animate-bounce rounded-full bg-slate-400",
            style: { animationDelay: "0.1s" }
          }
        ),
        /* @__PURE__ */ jsx(
          "div",
          {
            className: "h-2 w-2 animate-bounce rounded-full bg-slate-400",
            style: { animationDelay: "0.2s" }
          }
        )
      ] }) }) })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "border-t border-slate-200 p-4 dark:border-slate-700", children: /* @__PURE__ */ jsxs("div", { className: "flex space-x-2", children: [
      /* @__PURE__ */ jsx(
        "input",
        {
          type: "text",
          value: inputMessage,
          onChange: (e) => setInputMessage(e.target.value),
          onKeyPress: handleKeyPress,
          placeholder: "Type your message...",
          className: "flex-1 rounded-lg border border-slate-200 px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none dark:border-slate-600 dark:bg-slate-700 dark:text-white"
        }
      ),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: sendMessage,
          className: "rounded-lg bg-brand p-2 text-white transition-all duration-300 hover:shadow-lg",
          children: /* @__PURE__ */ jsx(Send, { className: "h-4 w-4" })
        }
      )
    ] }) })
  ] }) });
};
export {
  Chatbot as C
};
