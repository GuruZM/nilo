import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { A as AppLayout } from "./app-layout-JvxHjkrs.js";
import { useForm, Head } from "@inertiajs/react";
import { motion } from "framer-motion";
import { Users, ArrowLeft, UserPlus, Mail, Phone, IdCard, MapPin, StickyNote, Loader2, Building2 } from "lucide-react";
import { toast } from "sonner";
import { B as Badge } from "./badge-CfxidL8Q.js";
import { B as Button } from "./button-DMGEFYrU.js";
import { C as Card } from "./card-MypPWj87.js";
import { I as Input } from "./input-nVyaPHpJ.js";
import { L as Label } from "./label-BjflLCFy.js";
import { S as Separator } from "./separator-Bcia5PKZ.js";
import { T as Textarea } from "./textarea-B2f7VE2B.js";
import "./Chatbot-yoo4250k.js";
import "react";
import "./app-sidebar-layout-BGzXXcN9.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
import "@radix-ui/react-separator";
const breadcrumbs = [
  { title: "Clients", href: "/clients" },
  { title: "Create", href: "/clients/create" }
];
function ClientsCreate() {
  const form = useForm({
    name: "",
    contact_person: "",
    email: "",
    phone: "",
    tpin: "",
    address: "",
    city: "",
    country: "",
    notes: ""
  });
  const submit = (e) => {
    e.preventDefault();
    form.post("/clients", {
      preserveScroll: true,
      onSuccess: () => {
        toast.success("Client created.");
        form.reset();
      },
      onError: (errors) => {
        toast.error(
          errors?.name || errors?.email || errors?.phone || errors?.tpin || "Failed to create client."
        );
      }
    });
  };
  const goBack = () => window.history.back();
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Create Client" }),
    /* @__PURE__ */ jsxs(
      motion.div,
      {
        initial: "hidden",
        animate: "show",
        className: "mx-auto w-full max-w-5xl px-4 py-10 sm:px-6",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "grid h-11 w-11 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(Users, { className: "h-6 w-6 text-foreground/80" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight sm:text-3xl", children: "Create client" }),
                  /* @__PURE__ */ jsx(
                    Badge,
                    {
                      variant: "secondary",
                      className: "hidden sm:inline-flex",
                      children: "Active company scoped"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "Add a client to your active company. You’ll be able to attach this client to invoices, quotations and delivery notes." })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxs(
                Button,
                {
                  type: "button",
                  variant: "outline",
                  onClick: goBack,
                  className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                  children: [
                    /* @__PURE__ */ jsx(ArrowLeft, { className: "mr-2 h-4 w-4" }),
                    "Back"
                  ]
                }
              ),
              /* @__PURE__ */ jsxs(
                Button,
                {
                  type: "button",
                  onClick: () => {
                    const el = document.getElementById("client-form");
                    el?.scrollIntoView({
                      behavior: "smooth",
                      block: "start"
                    });
                  },
                  className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                  children: [
                    /* @__PURE__ */ jsx(UserPlus, { className: "mr-2 h-4 w-4" }),
                    "New client"
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsx(Separator, { className: "mb-6" }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-6 lg:grid-cols-12", children: [
            /* @__PURE__ */ jsx(
              motion.div,
              {
                initial: "hidden",
                animate: "show",
                className: "lg:col-span-8",
                id: "client-form",
                children: /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm", children: [
                  /* @__PURE__ */ jsxs("div", { className: "mb-5 flex items-center justify-between gap-3", children: [
                    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsx("div", { className: "grid h-9 w-9 place-items-center rounded-xl bg-muted", children: /* @__PURE__ */ jsx(UserPlus, { className: "h-5 w-5 text-foreground/80" }) }),
                      /* @__PURE__ */ jsxs("div", { children: [
                        /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Client information" }),
                        /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Keep it accurate for clean invoices." })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsx(
                      Badge,
                      {
                        variant: "outline",
                        className: "hidden sm:inline-flex",
                        children: "Fields marked * are required"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "space-y-6", children: [
                    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx(Label, { htmlFor: "name", children: "Client name *" }),
                        /* @__PURE__ */ jsx(
                          Input,
                          {
                            id: "name",
                            placeholder: "e.g. Cozyhouse Interiors",
                            value: form.data.name,
                            onChange: (e) => form.setData(
                              "name",
                              e.target.value
                            ),
                            required: true
                          }
                        ),
                        form.errors.name && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.name })
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx(Label, { htmlFor: "contact_person", children: "Contact person" }),
                        /* @__PURE__ */ jsx(
                          Input,
                          {
                            id: "contact_person",
                            placeholder: "e.g. Mary Zulu",
                            value: form.data.contact_person ?? "",
                            onChange: (e) => form.setData(
                              "contact_person",
                              e.target.value
                            )
                          }
                        ),
                        form.errors.contact_person && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.contact_person })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsxs(
                          Label,
                          {
                            htmlFor: "email",
                            className: "flex items-center gap-2",
                            children: [
                              /* @__PURE__ */ jsx(Mail, { className: "h-4 w-4 text-muted-foreground" }),
                              "Email"
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsx(
                          Input,
                          {
                            id: "email",
                            type: "email",
                            placeholder: "billing@client.com",
                            value: form.data.email ?? "",
                            onChange: (e) => form.setData(
                              "email",
                              e.target.value
                            )
                          }
                        ),
                        form.errors.email && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.email })
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsxs(
                          Label,
                          {
                            htmlFor: "phone",
                            className: "flex items-center gap-2",
                            children: [
                              /* @__PURE__ */ jsx(Phone, { className: "h-4 w-4 text-muted-foreground" }),
                              "Phone"
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsx(
                          Input,
                          {
                            id: "phone",
                            placeholder: "+260...",
                            value: form.data.phone ?? "",
                            onChange: (e) => form.setData(
                              "phone",
                              e.target.value
                            )
                          }
                        ),
                        form.errors.phone && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.phone })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsxs(
                          Label,
                          {
                            htmlFor: "tpin",
                            className: "flex items-center gap-2",
                            children: [
                              /* @__PURE__ */ jsx(IdCard, { className: "h-4 w-4 text-muted-foreground" }),
                              "TPIN"
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsx(
                          Input,
                          {
                            id: "tpin",
                            placeholder: "e.g. 100XXXXXXX",
                            value: form.data.tpin ?? "",
                            onChange: (e) => form.setData(
                              "tpin",
                              e.target.value
                            )
                          }
                        ),
                        form.errors.tpin && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.tpin })
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsxs(
                          Label,
                          {
                            htmlFor: "address",
                            className: "flex items-center gap-2",
                            children: [
                              /* @__PURE__ */ jsx(MapPin, { className: "h-4 w-4 text-muted-foreground" }),
                              "Address"
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsx(
                          Input,
                          {
                            id: "address",
                            placeholder: "Street, Area",
                            value: form.data.address ?? "",
                            onChange: (e) => form.setData(
                              "address",
                              e.target.value
                            )
                          }
                        ),
                        form.errors.address && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.address })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx(Label, { htmlFor: "city", children: "City" }),
                        /* @__PURE__ */ jsx(
                          Input,
                          {
                            id: "city",
                            placeholder: "e.g. Lusaka",
                            value: form.data.city ?? "",
                            onChange: (e) => form.setData(
                              "city",
                              e.target.value
                            )
                          }
                        ),
                        form.errors.city && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.city })
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx(Label, { htmlFor: "country", children: "Country" }),
                        /* @__PURE__ */ jsx(
                          Input,
                          {
                            id: "country",
                            placeholder: "e.g. Zambia",
                            value: form.data.country ?? "",
                            onChange: (e) => form.setData(
                              "country",
                              e.target.value
                            )
                          }
                        ),
                        form.errors.country && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.country })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                      /* @__PURE__ */ jsxs(
                        Label,
                        {
                          htmlFor: "notes",
                          className: "flex items-center gap-2",
                          children: [
                            /* @__PURE__ */ jsx(StickyNote, { className: "h-4 w-4 text-muted-foreground" }),
                            "Notes"
                          ]
                        }
                      ),
                      /* @__PURE__ */ jsx(
                        Textarea,
                        {
                          id: "notes",
                          placeholder: "Any extra details (delivery instructions, preferred contact time, etc.)",
                          value: form.data.notes ?? "",
                          onChange: (e) => form.setData(
                            "notes",
                            e.target.value
                          ),
                          rows: 4
                        }
                      ),
                      form.errors.notes && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.notes })
                    ] }),
                    /* @__PURE__ */ jsx(Separator, {}),
                    /* @__PURE__ */ jsxs("div", { className: "flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-end", children: [
                      /* @__PURE__ */ jsx(
                        Button,
                        {
                          type: "button",
                          variant: "ghost",
                          onClick: goBack,
                          disabled: form.processing,
                          className: "rounded-xl",
                          children: "Cancel"
                        }
                      ),
                      /* @__PURE__ */ jsx(
                        Button,
                        {
                          type: "submit",
                          disabled: form.processing || !form.data.name.trim(),
                          className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                          children: form.processing ? /* @__PURE__ */ jsxs(Fragment, { children: [
                            /* @__PURE__ */ jsx(Loader2, { className: "mr-2 h-4 w-4 animate-spin" }),
                            "Saving..."
                          ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
                            /* @__PURE__ */ jsx(UserPlus, { className: "mr-2 h-4 w-4" }),
                            "Create client"
                          ] })
                        }
                      )
                    ] })
                  ] })
                ] })
              }
            ),
            /* @__PURE__ */ jsx(
              motion.div,
              {
                initial: "hidden",
                animate: "show",
                className: "lg:col-span-4",
                children: /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
                  /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm", children: [
                    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsx("div", { className: "grid h-9 w-9 place-items-center rounded-xl bg-muted", children: /* @__PURE__ */ jsx(Building2, { className: "h-5 w-5 text-foreground/80" }) }),
                      /* @__PURE__ */ jsxs("div", { children: [
                        /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Quick preview" }),
                        /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "What will appear on invoices." })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxs("div", { className: "mt-5 space-y-3 text-sm", children: [
                      /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
                        /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Client" }),
                        /* @__PURE__ */ jsx("span", { className: "max-w-[60%] truncate text-right font-medium", children: form.data.name?.trim() || "—" })
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
                        /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Contact" }),
                        /* @__PURE__ */ jsx("span", { className: "max-w-[60%] truncate text-right font-medium", children: form.data.contact_person?.trim() || "—" })
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
                        /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Email" }),
                        /* @__PURE__ */ jsx("span", { className: "max-w-[60%] truncate text-right font-medium", children: form.data.email?.trim() || "—" })
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
                        /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Phone" }),
                        /* @__PURE__ */ jsx("span", { className: "max-w-[60%] truncate text-right font-medium", children: form.data.phone?.trim() || "—" })
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
                        /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "TPIN" }),
                        /* @__PURE__ */ jsx("span", { className: "max-w-[60%] truncate text-right font-medium", children: form.data.tpin?.trim() || "—" })
                      ] })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm", children: [
                    /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Tips" }),
                    /* @__PURE__ */ jsxs("ul", { className: "mt-3 space-y-2 text-sm text-muted-foreground", children: [
                      /* @__PURE__ */ jsx("li", { children: "• Add an email to send invoices directly." }),
                      /* @__PURE__ */ jsx("li", { children: "• TPIN helps with compliance and clean receipts." }),
                      /* @__PURE__ */ jsx("li", { children: "• Use notes for delivery instructions or billing rules." })
                    ] })
                  ] })
                ] })
              }
            )
          ] })
        ]
      }
    )
  ] });
}
export {
  ClientsCreate as default
};
