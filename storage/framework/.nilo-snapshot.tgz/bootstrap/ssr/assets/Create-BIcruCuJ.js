import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useForm, Head, Link } from "@inertiajs/react";
import { motion, AnimatePresence } from "framer-motion";
import { ClipboardList, Receipt, CheckCircle2, ArrowLeft, ArrowRight, FileSignature, BadgePercent, Plus, Trash2 } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";
import { A as AppLayout } from "./app-layout-JvxHjkrs.js";
import { B as Button, c as cn } from "./button-DMGEFYrU.js";
import { C as Card } from "./card-MypPWj87.js";
import { I as Input } from "./input-nVyaPHpJ.js";
import { L as Label } from "./label-BjflLCFy.js";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-DesEnXXV.js";
import { S as Separator } from "./separator-Bcia5PKZ.js";
import { T as Textarea } from "./textarea-B2f7VE2B.js";
import "./Chatbot-yoo4250k.js";
import "./app-sidebar-layout-BGzXXcN9.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
import "@radix-ui/react-select";
import "@radix-ui/react-separator";
const breadcrumbs = [
  { title: "Quotations", href: "/quotations" },
  { title: "Create", href: "/quotations/create" }
];
const steps = [
  {
    key: "details",
    title: "Details",
    description: "Client, dates, currency, and terms",
    icon: ClipboardList
  },
  {
    key: "items",
    title: "Items",
    description: "Line items and pricing",
    icon: Receipt
  },
  {
    key: "review",
    title: "Review",
    description: "Status, totals, and create",
    icon: CheckCircle2
  }
];
function QuotationsCreate({
  clients,
  defaultCurrencyCode,
  currencies,
  hasActiveCompany = true
}) {
  const currencyList = currencies?.all ?? [];
  const activeCurrency = currencies?.current ?? null;
  const hasClients = clients.length > 0;
  const hasCurrencies = currencyList.length > 0;
  const canCreateQuotation = hasActiveCompany && hasClients && hasCurrencies;
  const initialCurrencyCode = currencyList.find((currency) => currency.code === defaultCurrencyCode)?.code ?? activeCurrency?.code ?? currencyList[0]?.code ?? "";
  const [step, setStep] = React.useState("details");
  const form = useForm({
    client_id: "",
    title: "",
    reference: "",
    issue_date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
    valid_until: "",
    currency_code: initialCurrencyCode,
    status: "draft",
    notes: "",
    terms: "",
    quotation_discount: 0,
    items: [
      {
        description: "",
        unit: "",
        quantity: 1,
        unit_price: 0,
        discount: 0,
        tax: 0
      }
    ]
  });
  const precision = React.useMemo(() => {
    const selected = currencyList.find(
      (currency) => currency.code === form.data.currency_code
    );
    return selected?.precision ?? activeCurrency?.precision ?? 2;
  }, [activeCurrency?.precision, currencyList, form.data.currency_code]);
  const fmt = (value) => (Number.isFinite(value) ? value : 0).toFixed(precision);
  const computed = React.useMemo(() => {
    let subtotal = 0;
    let lineDiscount = 0;
    let tax = 0;
    for (const item of form.data.items) {
      const quantity = Number(item.quantity || 0);
      const price = Number(item.unit_price || 0);
      const discount = Number(item.discount || 0);
      const itemTax = Number(item.tax || 0);
      subtotal += quantity * price;
      lineDiscount += discount;
      tax += itemTax;
    }
    const quotationDiscount = Number(form.data.quotation_discount || 0);
    const totalDiscount = lineDiscount + quotationDiscount;
    const total = Math.max(0, subtotal - totalDiscount + tax);
    return {
      subtotal,
      lineDiscount,
      quotationDiscount,
      tax,
      total
    };
  }, [form.data.items, form.data.quotation_discount]);
  const addItem = () => {
    form.setData("items", [
      ...form.data.items,
      {
        description: "",
        unit: "",
        quantity: 1,
        unit_price: 0,
        discount: 0,
        tax: 0
      }
    ]);
  };
  const removeItem = (index) => {
    const next = form.data.items.filter((_, current) => current !== index);
    form.setData(
      "items",
      next.length ? next : [
        {
          description: "",
          unit: "",
          quantity: 1,
          unit_price: 0,
          discount: 0,
          tax: 0
        }
      ]
    );
  };
  const updateItem = (index, key, value) => {
    const next = [...form.data.items];
    next[index] = {
      ...next[index],
      [key]: value
    };
    form.setData("items", next);
  };
  const validateStep = (currentStep) => {
    if (!hasActiveCompany) {
      return toast.error(
        "Add or select a company before creating a quotation."
      ), false;
    }
    if (!hasClients) {
      return toast.error("Add a client before creating a quotation."), false;
    }
    if (!hasCurrencies) {
      return toast.error("Add an active currency before creating a quotation."), false;
    }
    if (currentStep === "details") {
      if (!form.data.client_id) {
        return toast.error("Select a client."), false;
      }
      if (!form.data.issue_date) {
        return toast.error("Issue date is required."), false;
      }
      if (!form.data.currency_code) {
        return toast.error("Currency is required."), false;
      }
    }
    if (currentStep === "items") {
      const hasValidItem = form.data.items.some(
        (item) => item.description.trim().length > 0 && Number(item.quantity) > 0 && Number(item.unit_price) >= 0
      );
      if (!hasValidItem) {
        return toast.error("Add at least one valid line item."), false;
      }
    }
    if (currentStep === "review") {
      if (Number(form.data.quotation_discount || 0) < 0) {
        return toast.error("Quotation discount cannot be negative."), false;
      }
    }
    return true;
  };
  const order = ["details", "items", "review"];
  const goNext = () => {
    if (!validateStep(step)) {
      return;
    }
    setStep(order[Math.min(order.indexOf(step) + 1, order.length - 1)]);
  };
  const goBack = () => {
    setStep(order[Math.max(order.indexOf(step) - 1, 0)]);
  };
  const submit = () => {
    if (step !== "review") {
      toast.error("Finish the review step first.");
      return;
    }
    if (!validateStep("review")) {
      return;
    }
    form.post("/quotations", {
      preserveScroll: true,
      preserveState: false,
      onSuccess: () => {
        toast.success("Quotation created.");
      },
      onError: (errors) => {
        const quotationError2 = errors.quotation;
        toast.error(
          quotationError2 || errors?.client_id || errors?.currency_code || errors?.status || errors?.items || "Failed to create quotation."
        );
      }
    });
  };
  const currentStepIcon = steps.find((current) => current.key === step)?.icon ?? ClipboardList;
  const quotationError = form.errors.quotation;
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Create quotation" }),
    /* @__PURE__ */ jsx("div", { className: "sticky top-0 z-30 border-b bg-background/80 backdrop-blur", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto flex w-full items-center justify-between gap-3 px-4 py-3 sm:px-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex min-w-0 items-center gap-3", children: [
        /* @__PURE__ */ jsx("div", { className: "grid h-10 w-10 place-items-center rounded-2xl bg-muted", children: React.createElement(currentStepIcon, {
          className: "h-5 w-5 opacity-80"
        }) }),
        /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsx("div", { className: "truncate text-sm font-semibold", children: "Create quotation" }),
          /* @__PURE__ */ jsxs("div", { className: "truncate text-xs text-muted-foreground", children: [
            steps.find((current) => current.key === step)?.title,
            " ",
            "•",
            " ",
            steps.find((current) => current.key === step)?.description
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxs(
          Button,
          {
            type: "button",
            variant: "outline",
            onClick: goBack,
            disabled: step === "details" || form.processing,
            className: "rounded-xl",
            children: [
              /* @__PURE__ */ jsx(ArrowLeft, { className: "mr-2 h-4 w-4" }),
              "Back"
            ]
          }
        ),
        step !== "review" ? /* @__PURE__ */ jsxs(
          Button,
          {
            type: "button",
            onClick: goNext,
            disabled: form.processing || !canCreateQuotation,
            className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
            children: [
              "Next",
              /* @__PURE__ */ jsx(ArrowRight, { className: "ml-2 h-4 w-4" })
            ]
          }
        ) : /* @__PURE__ */ jsxs(
          Button,
          {
            type: "button",
            onClick: submit,
            disabled: form.processing || !canCreateQuotation,
            className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
            children: [
              "Create",
              /* @__PURE__ */ jsx(CheckCircle2, { className: "ml-2 h-4 w-4" })
            ]
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs(
      motion.div,
      {
        initial: { opacity: 0, y: 14 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.25, ease: "easeOut" },
        className: "mx-auto w-full px-4 py-8 sm:px-6",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-6 flex items-start gap-3", children: [
            /* @__PURE__ */ jsx("div", { className: "grid h-11 w-11 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(FileSignature, { className: "h-6 w-6 opacity-80" }) }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight sm:text-3xl", children: "Create quotation" }),
              /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "Build a client-ready quotation with the same guided flow as invoices." })
            ] })
          ] }),
          !canCreateQuotation && /* @__PURE__ */ jsx(Card, { className: "mb-6 rounded-2xl border-dashed bg-muted/20 p-5 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: hasActiveCompany ? "Finish setup before creating quotations" : "Add or select a company before creating quotations" }),
              /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: hasActiveCompany ? "Quotations stay available even with no data, but you need at least one client and one active currency before you can create one." : "Quotations are available, but you need an active company before clients and quotations can be managed." })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex flex-col gap-2 sm:flex-row", children: hasActiveCompany ? /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx(Button, { asChild: true, className: "rounded-xl", children: /* @__PURE__ */ jsx(Link, { href: "/clients/create", children: "Add client" }) }),
              /* @__PURE__ */ jsx(
                Button,
                {
                  asChild: true,
                  variant: "outline",
                  className: "rounded-xl",
                  children: /* @__PURE__ */ jsx(Link, { href: "/settings/currencies", children: "Manage currencies" })
                }
              )
            ] }) : /* @__PURE__ */ jsx(Button, { asChild: true, className: "rounded-xl", children: /* @__PURE__ */ jsx(Link, { href: "/companies", children: "Manage companies" }) }) })
          ] }) }),
          /* @__PURE__ */ jsx("div", { className: "mb-6 grid grid-cols-1 gap-3 sm:grid-cols-3", children: steps.map((current) => {
            const Icon = current.icon;
            const active = current.key === step;
            const currentIndex = order.indexOf(step);
            const targetIndex = order.indexOf(current.key);
            const completed = targetIndex < currentIndex;
            return /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => {
                  if (targetIndex <= currentIndex) {
                    setStep(current.key);
                    return;
                  }
                  if (!validateStep(step)) {
                    return;
                  }
                  setStep(current.key);
                },
                className: cn(
                  "rounded-2xl border bg-background p-4 text-left shadow-sm transition",
                  "hover:bg-muted/20",
                  active && "border-foreground/20 bg-muted/20"
                ),
                children: /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
                  /* @__PURE__ */ jsx(
                    "div",
                    {
                      className: cn(
                        "grid h-10 w-10 place-items-center rounded-2xl",
                        completed ? "bg-foreground text-background" : active ? "bg-foreground/90 text-background" : "bg-muted"
                      ),
                      children: /* @__PURE__ */ jsx(Icon, { className: "h-5 w-5 opacity-90" })
                    }
                  ),
                  /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1", children: [
                    /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: current.title }),
                    /* @__PURE__ */ jsx("div", { className: "mt-1 text-xs text-muted-foreground", children: current.description })
                  ] })
                ] })
              },
              current.key
            );
          }) }),
          /* @__PURE__ */ jsx(Card, { className: "mb-6 rounded-2xl border bg-background p-4 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3 sm:grid-cols-5", children: [
            /* @__PURE__ */ jsx(
              MiniStat,
              {
                label: "Subtotal",
                value: fmt(computed.subtotal)
              }
            ),
            /* @__PURE__ */ jsx(
              MiniStat,
              {
                label: "Line discount",
                value: fmt(computed.lineDiscount)
              }
            ),
            /* @__PURE__ */ jsx(MiniStat, { label: "Tax", value: fmt(computed.tax) }),
            /* @__PURE__ */ jsx(
              MiniStat,
              {
                label: "Quotation discount",
                value: step === "review" ? fmt(computed.quotationDiscount) : "—"
              }
            ),
            /* @__PURE__ */ jsx(
              MiniStat,
              {
                label: "Currency",
                value: form.data.currency_code || "Not set"
              }
            )
          ] }) }),
          /* @__PURE__ */ jsx(
            "form",
            {
              onSubmit: (event) => {
                event.preventDefault();
                if (step === "review") {
                  submit();
                  return;
                }
                goNext();
              },
              className: "space-y-6",
              children: /* @__PURE__ */ jsxs(AnimatePresence, { mode: "wait", children: [
                step === "details" && /* @__PURE__ */ jsxs(
                  motion.div,
                  {
                    initial: { opacity: 0, y: 10 },
                    animate: { opacity: 1, y: 0 },
                    exit: { opacity: 0, y: 10 },
                    transition: { duration: 0.22 },
                    className: "grid grid-cols-1 gap-6 lg:grid-cols-12",
                    children: [
                      /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-8", children: [
                        /* @__PURE__ */ jsx(
                          SectionTitle,
                          {
                            icon: ClipboardList,
                            title: "Quotation details"
                          }
                        ),
                        /* @__PURE__ */ jsxs("div", { className: "mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                          /* @__PURE__ */ jsxs(Field, { label: "Client *", children: [
                            /* @__PURE__ */ jsxs(
                              Select,
                              {
                                value: form.data.client_id,
                                disabled: !hasClients,
                                onValueChange: (value) => form.setData(
                                  "client_id",
                                  value
                                ),
                                children: [
                                  /* @__PURE__ */ jsx(SelectTrigger, { className: "rounded-xl", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Select client" }) }),
                                  /* @__PURE__ */ jsx(SelectContent, { children: hasClients ? clients.map((client) => /* @__PURE__ */ jsx(
                                    SelectItem,
                                    {
                                      value: String(
                                        client.id
                                      ),
                                      children: client.name
                                    },
                                    client.id
                                  )) : /* @__PURE__ */ jsx("div", { className: "px-2 py-3 text-sm text-muted-foreground", children: "No clients yet. Add a client to continue." }) })
                                ]
                              }
                            ),
                            form.errors.client_id && /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-destructive", children: form.errors.client_id })
                          ] }),
                          /* @__PURE__ */ jsx(Field, { label: "Currency *", children: /* @__PURE__ */ jsxs(
                            Select,
                            {
                              value: form.data.currency_code,
                              disabled: !hasCurrencies,
                              onValueChange: (value) => form.setData(
                                "currency_code",
                                value
                              ),
                              children: [
                                /* @__PURE__ */ jsx(SelectTrigger, { className: "rounded-xl", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Select currency" }) }),
                                /* @__PURE__ */ jsx(SelectContent, { children: hasCurrencies ? currencyList.map(
                                  (currency) => /* @__PURE__ */ jsxs(
                                    SelectItem,
                                    {
                                      value: currency.code,
                                      children: [
                                        currency.code,
                                        " ",
                                        "—",
                                        " ",
                                        currency.name
                                      ]
                                    },
                                    currency.code
                                  )
                                ) : /* @__PURE__ */ jsx("div", { className: "px-2 py-3 text-sm text-muted-foreground", children: "No active currencies configured yet." }) })
                              ]
                            }
                          ) }),
                          /* @__PURE__ */ jsx(Field, { label: "Issue date *", children: /* @__PURE__ */ jsx(
                            Input,
                            {
                              type: "date",
                              value: form.data.issue_date,
                              onChange: (event) => form.setData(
                                "issue_date",
                                event.target.value
                              ),
                              className: "rounded-xl"
                            }
                          ) }),
                          /* @__PURE__ */ jsx(Field, { label: "Valid until", children: /* @__PURE__ */ jsx(
                            Input,
                            {
                              type: "date",
                              value: form.data.valid_until,
                              onChange: (event) => form.setData(
                                "valid_until",
                                event.target.value
                              ),
                              className: "rounded-xl"
                            }
                          ) }),
                          /* @__PURE__ */ jsx(Field, { label: "Title", children: /* @__PURE__ */ jsx(
                            Input,
                            {
                              value: form.data.title,
                              onChange: (event) => form.setData(
                                "title",
                                event.target.value
                              ),
                              className: "rounded-xl",
                              placeholder: "Optional quotation title"
                            }
                          ) }),
                          /* @__PURE__ */ jsx(Field, { label: "Reference", children: /* @__PURE__ */ jsx(
                            Input,
                            {
                              value: form.data.reference,
                              onChange: (event) => form.setData(
                                "reference",
                                event.target.value
                              ),
                              className: "rounded-xl",
                              placeholder: "Customer reference"
                            }
                          ) }),
                          /* @__PURE__ */ jsx(
                            Field,
                            {
                              label: "Notes",
                              className: "sm:col-span-2",
                              children: /* @__PURE__ */ jsx(
                                Textarea,
                                {
                                  value: form.data.notes,
                                  onChange: (event) => form.setData(
                                    "notes",
                                    event.target.value
                                  ),
                                  className: "min-h-24 rounded-xl",
                                  placeholder: "Optional notes for the client"
                                }
                              )
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            Field,
                            {
                              label: "Terms",
                              className: "sm:col-span-2",
                              children: /* @__PURE__ */ jsx(
                                Textarea,
                                {
                                  value: form.data.terms,
                                  onChange: (event) => form.setData(
                                    "terms",
                                    event.target.value
                                  ),
                                  className: "min-h-24 rounded-xl",
                                  placeholder: "Optional terms and conditions"
                                }
                              )
                            }
                          )
                        ] })
                      ] }),
                      /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-4", children: [
                        /* @__PURE__ */ jsx(
                          SectionTitle,
                          {
                            icon: BadgePercent,
                            title: "At a glance"
                          }
                        ),
                        /* @__PURE__ */ jsxs("div", { className: "mt-4 space-y-2 rounded-2xl border bg-muted/20 p-4", children: [
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Client",
                              value: clientLabel(
                                clients,
                                form.data.client_id
                              )
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Issue date",
                              value: form.data.issue_date || "—"
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Valid until",
                              value: form.data.valid_until || "—"
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Currency",
                              value: form.data.currency_code || "—"
                            }
                          )
                        ] }),
                        /* @__PURE__ */ jsx("div", { className: "mt-4 text-xs text-muted-foreground", children: "Move to the items step to price the quotation and calculate totals." })
                      ] })
                    ]
                  },
                  "details"
                ),
                step === "items" && /* @__PURE__ */ jsxs(
                  motion.div,
                  {
                    initial: { opacity: 0, y: 10 },
                    animate: { opacity: 1, y: 0 },
                    exit: { opacity: 0, y: 10 },
                    transition: { duration: 0.22 },
                    className: "grid grid-cols-1 gap-6 lg:grid-cols-12",
                    children: [
                      /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-8", children: [
                        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3", children: [
                          /* @__PURE__ */ jsx(
                            SectionTitle,
                            {
                              icon: Receipt,
                              title: "Line items"
                            }
                          ),
                          /* @__PURE__ */ jsxs(
                            Button,
                            {
                              type: "button",
                              variant: "outline",
                              onClick: addItem,
                              className: "gap-2 rounded-xl",
                              children: [
                                /* @__PURE__ */ jsx(Plus, { className: "h-4 w-4" }),
                                "Add item"
                              ]
                            }
                          )
                        ] }),
                        /* @__PURE__ */ jsx("div", { className: "mt-4 space-y-4", children: form.data.items.map((item, index) => /* @__PURE__ */ jsxs(
                          motion.div,
                          {
                            layout: true,
                            className: "rounded-2xl border p-4",
                            children: [
                              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3", children: [
                                /* @__PURE__ */ jsxs("div", { className: "text-sm font-semibold", children: [
                                  "Item ",
                                  index + 1
                                ] }),
                                /* @__PURE__ */ jsx(
                                  Button,
                                  {
                                    type: "button",
                                    variant: "ghost",
                                    size: "icon",
                                    onClick: () => removeItem(index),
                                    className: "rounded-xl",
                                    children: /* @__PURE__ */ jsx(Trash2, { className: "h-4 w-4" })
                                  }
                                )
                              ] }),
                              /* @__PURE__ */ jsxs("div", { className: "mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                                /* @__PURE__ */ jsx(
                                  Field,
                                  {
                                    label: "Description",
                                    className: "sm:col-span-2",
                                    children: /* @__PURE__ */ jsx(
                                      Input,
                                      {
                                        value: item.description,
                                        onChange: (event) => updateItem(
                                          index,
                                          "description",
                                          event.target.value
                                        ),
                                        className: "rounded-xl",
                                        placeholder: "Service or item description"
                                      }
                                    )
                                  }
                                ),
                                /* @__PURE__ */ jsx(Field, { label: "Unit", children: /* @__PURE__ */ jsx(
                                  Input,
                                  {
                                    value: item.unit,
                                    onChange: (event) => updateItem(
                                      index,
                                      "unit",
                                      event.target.value
                                    ),
                                    className: "rounded-xl",
                                    placeholder: "hrs / pcs"
                                  }
                                ) }),
                                /* @__PURE__ */ jsx(Field, { label: "Quantity", children: /* @__PURE__ */ jsx(
                                  Input,
                                  {
                                    type: "number",
                                    min: 0.01,
                                    step: 0.01,
                                    value: item.quantity,
                                    onChange: (event) => updateItem(
                                      index,
                                      "quantity",
                                      Number(
                                        event.target.value
                                      )
                                    ),
                                    className: "rounded-xl"
                                  }
                                ) }),
                                /* @__PURE__ */ jsx(Field, { label: "Unit price", children: /* @__PURE__ */ jsx(
                                  Input,
                                  {
                                    type: "number",
                                    min: 0,
                                    step: 0.01,
                                    value: item.unit_price,
                                    onChange: (event) => updateItem(
                                      index,
                                      "unit_price",
                                      Number(
                                        event.target.value
                                      )
                                    ),
                                    className: "rounded-xl"
                                  }
                                ) }),
                                /* @__PURE__ */ jsx(Field, { label: "Discount", children: /* @__PURE__ */ jsx(
                                  Input,
                                  {
                                    type: "number",
                                    min: 0,
                                    step: 0.01,
                                    value: item.discount,
                                    onChange: (event) => updateItem(
                                      index,
                                      "discount",
                                      Number(
                                        event.target.value
                                      )
                                    ),
                                    className: "rounded-xl"
                                  }
                                ) }),
                                /* @__PURE__ */ jsx(Field, { label: "Tax", children: /* @__PURE__ */ jsx(
                                  Input,
                                  {
                                    type: "number",
                                    min: 0,
                                    step: 0.01,
                                    value: item.tax,
                                    onChange: (event) => updateItem(
                                      index,
                                      "tax",
                                      Number(
                                        event.target.value
                                      )
                                    ),
                                    className: "rounded-xl"
                                  }
                                ) })
                              ] })
                            ]
                          },
                          index
                        )) })
                      ] }),
                      /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-4", children: [
                        /* @__PURE__ */ jsx(
                          SectionTitle,
                          {
                            icon: BadgePercent,
                            title: "Totals preview"
                          }
                        ),
                        /* @__PURE__ */ jsxs("div", { className: "mt-4 space-y-2 rounded-2xl border bg-muted/20 p-4", children: [
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Subtotal",
                              value: computed.subtotal,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Line discount",
                              value: computed.lineDiscount,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Tax",
                              value: computed.tax,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(Separator, { className: "my-2" }),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Total",
                              value: computed.total,
                              precision,
                              strong: true
                            }
                          )
                        ] }),
                        /* @__PURE__ */ jsx("div", { className: "mt-4 text-xs text-muted-foreground", children: "Overall quotation discount is applied on the review step." })
                      ] })
                    ]
                  },
                  "items"
                ),
                step === "review" && /* @__PURE__ */ jsxs(
                  motion.div,
                  {
                    initial: { opacity: 0, y: 10 },
                    animate: { opacity: 1, y: 0 },
                    exit: { opacity: 0, y: 10 },
                    transition: { duration: 0.22 },
                    className: "grid grid-cols-1 gap-6 lg:grid-cols-12",
                    children: [
                      /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-8", children: [
                        /* @__PURE__ */ jsx(
                          SectionTitle,
                          {
                            icon: CheckCircle2,
                            title: "Review"
                          }
                        ),
                        /* @__PURE__ */ jsxs("div", { className: "mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Client",
                              value: clientLabel(
                                clients,
                                form.data.client_id
                              )
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Currency",
                              value: form.data.currency_code || "Not set"
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Issue date",
                              value: form.data.issue_date || "—"
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Valid until",
                              value: form.data.valid_until || "—"
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Title",
                              value: form.data.title || "—"
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Reference",
                              value: form.data.reference || "—"
                            }
                          )
                        ] }),
                        /* @__PURE__ */ jsx(Separator, { className: "my-6" }),
                        /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border p-4", children: [
                          /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
                            /* @__PURE__ */ jsx("div", { className: "grid h-10 w-10 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(BadgePercent, { className: "h-5 w-5 opacity-80" }) }),
                            /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
                              /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Final adjustments" }),
                              /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Apply an overall discount and set the quotation status." })
                            ] })
                          ] }),
                          /* @__PURE__ */ jsxs("div", { className: "mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                            /* @__PURE__ */ jsx(Field, { label: "Overall discount", children: /* @__PURE__ */ jsx(
                              Input,
                              {
                                type: "number",
                                min: 0,
                                step: 0.01,
                                value: form.data.quotation_discount,
                                onChange: (event) => form.setData(
                                  "quotation_discount",
                                  Number(
                                    event.target.value
                                  )
                                ),
                                className: "rounded-xl"
                              }
                            ) }),
                            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                              /* @__PURE__ */ jsx(Label, { children: "Status" }),
                              /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2", children: [
                                "draft",
                                "sent",
                                "accepted",
                                "expired"
                              ].map((status) => /* @__PURE__ */ jsx(
                                StatusPill,
                                {
                                  active: form.data.status === status,
                                  label: status,
                                  onClick: () => form.setData(
                                    "status",
                                    status
                                  )
                                },
                                status
                              )) }),
                              form.errors.status && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.status })
                            ] })
                          ] })
                        ] }),
                        /* @__PURE__ */ jsx(Separator, { className: "my-6" }),
                        /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Items" }),
                        /* @__PURE__ */ jsxs("div", { className: "mt-3 rounded-2xl border", children: [
                          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-12 gap-2 border-b bg-muted/40 px-4 py-3 text-xs font-semibold text-muted-foreground", children: [
                            /* @__PURE__ */ jsx("div", { className: "col-span-6", children: "Description" }),
                            /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: "Qty" }),
                            /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: "Price" }),
                            /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: "Line" })
                          ] }),
                          /* @__PURE__ */ jsx("div", { className: "divide-y", children: form.data.items.map(
                            (item, index) => {
                              const quantity = Number(
                                item.quantity || 0
                              );
                              const price = Number(
                                item.unit_price || 0
                              );
                              const discount = Number(
                                item.discount || 0
                              );
                              const tax = Number(
                                item.tax || 0
                              );
                              const line = Math.max(
                                0,
                                quantity * price - discount + tax
                              );
                              return /* @__PURE__ */ jsxs(
                                "div",
                                {
                                  className: "grid grid-cols-12 gap-2 px-4 py-3 text-sm",
                                  children: [
                                    /* @__PURE__ */ jsx("div", { className: "col-span-6 min-w-0", children: /* @__PURE__ */ jsx("div", { className: "truncate font-medium", children: item.description || "—" }) }),
                                    /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: fmt(
                                      quantity
                                    ) }),
                                    /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: fmt(price) }),
                                    /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right font-semibold", children: fmt(line) })
                                  ]
                                },
                                index
                              );
                            }
                          ) })
                        ] })
                      ] }),
                      /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-4", children: [
                        /* @__PURE__ */ jsx(
                          SectionTitle,
                          {
                            icon: BadgePercent,
                            title: "Final totals"
                          }
                        ),
                        /* @__PURE__ */ jsxs("div", { className: "mt-4 space-y-2 rounded-2xl border bg-muted/20 p-4", children: [
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Subtotal",
                              value: computed.subtotal,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Line discount",
                              value: computed.lineDiscount,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Quotation discount",
                              value: computed.quotationDiscount,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Tax",
                              value: computed.tax,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(Separator, { className: "my-2" }),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Total",
                              value: computed.total,
                              precision,
                              strong: true
                            }
                          )
                        ] }),
                        quotationError && /* @__PURE__ */ jsx("p", { className: "mt-4 text-sm text-destructive", children: quotationError }),
                        /* @__PURE__ */ jsxs(
                          Button,
                          {
                            type: "button",
                            onClick: submit,
                            disabled: form.processing || !canCreateQuotation,
                            className: "mt-4 w-full gap-2 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                            children: [
                              "Create quotation",
                              /* @__PURE__ */ jsx(CheckCircle2, { className: "h-4 w-4" })
                            ]
                          }
                        )
                      ] })
                    ]
                  },
                  "review"
                )
              ] })
            }
          )
        ]
      }
    )
  ] });
}
function SectionTitle({
  icon: Icon,
  title
}) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ jsx(Icon, { className: "h-5 w-5 opacity-80" }),
    /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: title })
  ] });
}
function Field({
  label,
  children,
  className
}) {
  return /* @__PURE__ */ jsxs("div", { className: cn("space-y-2", className), children: [
    /* @__PURE__ */ jsx(Label, { children: label }),
    children
  ] });
}
function MiniStat({
  label,
  value
}) {
  return /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border bg-muted/20 px-4 py-3", children: [
    /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: label }),
    /* @__PURE__ */ jsx("div", { className: "mt-1 text-sm font-semibold", children: value })
  ] });
}
function Row({
  label,
  value,
  precision,
  strong = false
}) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3 text-sm", children: [
    /* @__PURE__ */ jsx("div", { className: cn("text-muted-foreground", strong && "font-medium text-foreground"), children: label }),
    /* @__PURE__ */ jsx("div", { className: cn("font-medium", strong && "text-base font-semibold"), children: value.toFixed(precision) })
  ] });
}
function ReviewField({
  label,
  value
}) {
  return /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border bg-muted/20 p-4", children: [
    /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: label }),
    /* @__PURE__ */ jsx("div", { className: "mt-1 text-sm font-semibold", children: value })
  ] });
}
function StatusPill({
  active,
  label,
  onClick
}) {
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      onClick,
      className: cn(
        "rounded-xl border px-3 py-2 text-sm font-medium capitalize transition",
        active ? "border-foreground bg-foreground text-background" : "border-border bg-background hover:bg-muted/40"
      ),
      children: label
    }
  );
}
function clientLabel(clients, clientId) {
  return clients.find((client) => String(client.id) === clientId)?.name ?? "Not selected";
}
export {
  QuotationsCreate as default
};
