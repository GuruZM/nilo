import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useForm, Head, Link } from "@inertiajs/react";
import { motion, AnimatePresence } from "framer-motion";
import { ClipboardList, Receipt, CheckCircle2, ArrowLeft, ArrowRight, FileText, Eye, CalendarClock, Plus, Trash2, BadgePercent } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";
import { A as AppLayout } from "./app-layout-JvxHjkrs.js";
import { B as Button, c as cn } from "./button-DMGEFYrU.js";
import { C as Card } from "./card-MypPWj87.js";
import { D as Dialog, b as DialogContent, c as DialogHeader, d as DialogTitle } from "./dialog-Md5slGnn.js";
import { I as Input } from "./input-nVyaPHpJ.js";
import { L as Label } from "./label-BjflLCFy.js";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-DesEnXXV.js";
import { S as Separator } from "./separator-Bcia5PKZ.js";
import { S as Switch } from "./switch-4h1eh9fE.js";
import { T as Textarea } from "./textarea-B2f7VE2B.js";
import "./Chatbot-yoo4250k.js";
import "./app-sidebar-layout-BGzXXcN9.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
import "@radix-ui/react-select";
import "@radix-ui/react-separator";
import "@radix-ui/react-switch";
const breadcrumbs = [
  { title: "Invoices", href: "/invoices" },
  { title: "Create", href: "/invoices/create" }
];
const steps = [
  {
    key: "details",
    title: "Details",
    description: "Client, template, dates, currency, recurrence",
    icon: ClipboardList
  },
  {
    key: "items",
    title: "Items",
    description: "Line items and pricing",
    icon: Receipt
  },
  {
    key: "review",
    title: "Review",
    description: "Discount, status, preview & create",
    icon: CheckCircle2
  }
];
function InvoicesCreate({
  clients,
  templates,
  defaultCurrencyCode,
  currencies,
  hasActiveCompany = true
}) {
  const currencyList = currencies?.all ?? [];
  const activeCurrency = currencies?.current ?? null;
  const hasClients = clients.length > 0;
  const hasCurrencies = currencyList.length > 0;
  const canCreateInvoice = hasActiveCompany && hasClients && hasCurrencies;
  const initialCurrencyCode = currencyList.find((currency) => currency.code === defaultCurrencyCode)?.code ?? activeCurrency?.code ?? currencyList[0]?.code ?? "";
  const [step, setStep] = React.useState("details");
  const [previewOpen, setPreviewOpen] = React.useState(false);
  const [previewHtml, setPreviewHtml] = React.useState("");
  const form = useForm({
    client_id: "",
    invoice_template_id: templates.find((t) => t.is_default)?.id?.toString() ?? "",
    title: "",
    reference: "",
    issue_date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
    due_date: "",
    currency_code: initialCurrencyCode,
    has_delivery_note: false,
    // ✅ default pending
    status: "pending",
    is_recurring: false,
    recurrence_frequency: "monthly",
    recurrence_interval: 1,
    recurrence_start_date: "",
    recurrence_end_date: "",
    notes: "",
    terms: "",
    // ✅ overall discount on review
    invoice_discount: 0,
    items: [
      {
        description: "",
        unit: "",
        quantity: 1,
        unit_price: 0,
        discount: 0,
        tax: 0
      }
    ]
  });
  const precision = React.useMemo(() => {
    const selected = currencyList.find(
      (c) => c.code === form.data.currency_code
    );
    return selected?.precision ?? activeCurrency?.precision ?? 2;
  }, [currencyList, form.data.currency_code, activeCurrency?.precision]);
  const fmt = (v) => (Number.isFinite(v) ? v : 0).toFixed(precision);
  const computed = React.useMemo(() => {
    let subtotal = 0;
    let lineDiscount = 0;
    let tax = 0;
    for (const it of form.data.items) {
      const qty = Number(it.quantity || 0);
      const price = Number(it.unit_price || 0);
      const disc = Number(it.discount || 0);
      const t = Number(it.tax || 0);
      subtotal += qty * price;
      lineDiscount += disc;
      tax += t;
    }
    const invoiceDiscount = Number(form.data.invoice_discount || 0);
    const totalDiscount = lineDiscount + invoiceDiscount;
    const total = Math.max(0, subtotal - totalDiscount + tax);
    return { subtotal, lineDiscount, invoiceDiscount, tax, total };
  }, [form.data.items, form.data.invoice_discount]);
  const addItem = () => {
    form.setData("items", [
      ...form.data.items,
      {
        description: "",
        unit: "",
        quantity: 1,
        unit_price: 0,
        discount: 0,
        tax: 0
      }
    ]);
  };
  const removeItem = (idx) => {
    const next = form.data.items.filter((_, i) => i !== idx);
    form.setData(
      "items",
      next.length ? next : [
        {
          description: "",
          unit: "",
          quantity: 1,
          unit_price: 0,
          discount: 0,
          tax: 0
        }
      ]
    );
  };
  const updateItem = (idx, key, value) => {
    const next = [...form.data.items];
    next[idx][key] = value;
    form.setData("items", next);
  };
  const validateStep = (s) => {
    if (!hasActiveCompany) {
      return toast.error("Add or select a company before creating an invoice."), false;
    }
    if (!hasClients) {
      return toast.error("Add a client before creating an invoice."), false;
    }
    if (!hasCurrencies) {
      return toast.error("Add an active currency before creating an invoice."), false;
    }
    if (s === "details") {
      if (!form.data.client_id)
        return toast.error("Select a client."), false;
      if (!form.data.issue_date)
        return toast.error("Issue date is required."), false;
      if (!form.data.currency_code)
        return toast.error("Currency is required."), false;
      if (form.data.is_recurring) {
        if (!form.data.recurrence_frequency)
          return toast.error("Select a recurrence frequency."), false;
        if (!form.data.recurrence_interval || form.data.recurrence_interval < 1)
          return toast.error("Recurrence interval must be at least 1."), false;
      }
    }
    if (s === "items") {
      const hasValidItem = form.data.items.some(
        (it) => (it.description || "").trim().length > 0 && Number(it.quantity) > 0 && Number(it.unit_price) >= 0
      );
      if (!hasValidItem)
        return toast.error("Add at least one valid line item."), false;
    }
    if (s === "review") {
      const d = Number(form.data.invoice_discount || 0);
      if (d < 0)
        return toast.error("Invoice discount cannot be negative."), false;
    }
    return true;
  };
  const order = ["details", "items", "review"];
  const goNext = () => {
    if (!validateStep(step)) return;
    setStep(order[Math.min(order.indexOf(step) + 1, order.length - 1)]);
  };
  const goBack = () => {
    setStep(order[Math.max(order.indexOf(step) - 1, 0)]);
  };
  const openPreview = async () => {
    const idx = order.indexOf(step);
    for (let i = 0; i <= Math.max(idx, order.indexOf("review")); i++) {
      if (!validateStep(order[i])) return;
    }
    try {
      const res = await fetch("/invoices/preview", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "X-CSRF-TOKEN": document.querySelector(
            'meta[name="csrf-token"]'
          )?.content ?? ""
        },
        body: JSON.stringify(form.data)
      });
      if (!res.ok) {
        const json = await res.json().catch(() => null);
        toast.error(json?.message || "Preview failed.");
        return;
      }
      const html = await res.text();
      setPreviewHtml(html);
      setPreviewOpen(true);
    } catch (e) {
      toast.error("Preview failed.");
    }
  };
  const submit = () => {
    if (step !== "review") return toast.error("Finish review first.");
    if (!validateStep("review")) return;
    form.post("/invoices", {
      preserveScroll: true,
      preserveState: false,
      // ✅ ensures UI updates after redirect
      onSuccess: () => toast.success("Invoice created."),
      onError: (errors) => toast.error(
        errors?.client_id || errors?.currency_code || errors?.invoice_template_id || errors?.status || errors?.invoice_discount || errors?.items || errors?.invoice || "Failed to create invoice."
      )
    });
  };
  const StepIcon = steps.find((s) => s.key === step)?.icon ?? ClipboardList;
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Create invoice" }),
    /* @__PURE__ */ jsx("div", { className: "sticky top-0 z-30 border-b bg-background/80 backdrop-blur", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto flex w-full items-center justify-between gap-3 px-4 py-3 sm:px-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex min-w-0 items-center gap-3", children: [
        /* @__PURE__ */ jsx("div", { className: "grid h-10 w-10 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(StepIcon, { className: "h-5 w-5 opacity-80" }) }),
        /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsx("div", { className: "truncate text-sm font-semibold", children: "Create invoice" }),
          /* @__PURE__ */ jsxs("div", { className: "truncate text-xs text-muted-foreground", children: [
            steps.find((s) => s.key === step)?.title,
            " •",
            " ",
            steps.find((s) => s.key === step)?.description
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxs(
          Button,
          {
            type: "button",
            variant: "outline",
            onClick: goBack,
            disabled: step === "details" || form.processing,
            className: "rounded-xl",
            children: [
              /* @__PURE__ */ jsx(ArrowLeft, { className: "mr-2 h-4 w-4" }),
              "Back"
            ]
          }
        ),
        step !== "review" ? /* @__PURE__ */ jsxs(
          Button,
          {
            type: "button",
            onClick: goNext,
            disabled: form.processing || !canCreateInvoice,
            className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
            children: [
              "Next",
              /* @__PURE__ */ jsx(ArrowRight, { className: "ml-2 h-4 w-4" })
            ]
          }
        ) : /* @__PURE__ */ jsxs(
          Button,
          {
            type: "button",
            onClick: submit,
            disabled: form.processing || !canCreateInvoice,
            className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
            children: [
              "Create",
              /* @__PURE__ */ jsx(CheckCircle2, { className: "ml-2 h-4 w-4" })
            ]
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs(
      motion.div,
      {
        initial: { opacity: 0, y: 14 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.25, ease: "easeOut" },
        className: "mx-auto w-full px-4 py-8 sm:px-6",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-6 flex items-start justify-between gap-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "grid h-11 w-11 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(FileText, { className: "h-6 w-6 opacity-80" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight sm:text-3xl", children: "Create invoice" }),
                /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "Details → Items → Review. Preview before creating." })
              ] })
            ] }),
            step === "review" && /* @__PURE__ */ jsxs(
              Button,
              {
                type: "button",
                variant: "outline",
                onClick: openPreview,
                disabled: !canCreateInvoice,
                className: "gap-2 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                children: [
                  /* @__PURE__ */ jsx(Eye, { className: "h-4 w-4" }),
                  "Preview"
                ]
              }
            )
          ] }),
          !canCreateInvoice && /* @__PURE__ */ jsx(Card, { className: "mb-6 rounded-2xl border-dashed bg-muted/20 p-5 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: hasActiveCompany ? "Finish setup before creating invoices" : "Add or select a company before creating invoices" }),
              /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: hasActiveCompany ? "Invoices stay available even with no data, but you need at least one client and one active currency before you can create one." : "Invoices are available, but you need an active company before clients, templates, and invoices can be managed." })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex flex-col gap-2 sm:flex-row", children: hasActiveCompany ? /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx(Button, { asChild: true, className: "rounded-xl", children: /* @__PURE__ */ jsx(Link, { href: "/clients/create", children: "Add client" }) }),
              /* @__PURE__ */ jsx(
                Button,
                {
                  asChild: true,
                  variant: "outline",
                  className: "rounded-xl",
                  children: /* @__PURE__ */ jsx(Link, { href: "/settings/currencies", children: "Manage currencies" })
                }
              )
            ] }) : /* @__PURE__ */ jsx(Button, { asChild: true, className: "rounded-xl", children: /* @__PURE__ */ jsx(Link, { href: "/companies", children: "Manage companies" }) }) })
          ] }) }),
          /* @__PURE__ */ jsx("div", { className: "mb-6 grid grid-cols-1 gap-3 sm:grid-cols-3", children: steps.map((s) => {
            const Icon = s.icon;
            const active = s.key === step;
            const cur = order.indexOf(step);
            const target = order.indexOf(s.key);
            const done = target < cur;
            return /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => {
                  if (target <= cur) return setStep(s.key);
                  if (!validateStep(step)) return;
                  setStep(s.key);
                },
                className: cn(
                  "rounded-2xl border bg-background p-4 text-left shadow-sm transition",
                  "hover:bg-muted/20",
                  active && "border-foreground/20 bg-muted/20"
                ),
                children: /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
                  /* @__PURE__ */ jsx(
                    "div",
                    {
                      className: cn(
                        "grid h-10 w-10 place-items-center rounded-2xl",
                        done ? "bg-foreground text-background" : active ? "bg-foreground/90 text-background" : "bg-muted"
                      ),
                      children: /* @__PURE__ */ jsx(Icon, { className: "h-5 w-5 opacity-90" })
                    }
                  ),
                  /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1", children: [
                    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                      /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: s.title }),
                      done && /* @__PURE__ */ jsx(CheckCircle2, { className: "h-4 w-4 opacity-70" })
                    ] }),
                    /* @__PURE__ */ jsx("div", { className: "mt-1 text-xs text-muted-foreground", children: s.description }),
                    /* @__PURE__ */ jsx("div", { className: "mt-3 h-[2px] w-full overflow-hidden rounded-full bg-muted", children: /* @__PURE__ */ jsx(
                      motion.div,
                      {
                        initial: false,
                        animate: {
                          width: done ? "100%" : active ? "66%" : "0%"
                        },
                        transition: {
                          duration: 0.25,
                          ease: "easeOut"
                        },
                        className: "h-full bg-foreground/80"
                      }
                    ) })
                  ] })
                ] })
              },
              s.key
            );
          }) }),
          /* @__PURE__ */ jsx(Card, { className: "mb-6 rounded-2xl border bg-background p-4 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3 sm:grid-cols-6", children: [
            /* @__PURE__ */ jsx(
              MiniStat,
              {
                label: "Subtotal",
                value: fmt(computed.subtotal)
              }
            ),
            /* @__PURE__ */ jsx(
              MiniStat,
              {
                label: "Line discount",
                value: fmt(computed.lineDiscount)
              }
            ),
            /* @__PURE__ */ jsx(MiniStat, { label: "Tax", value: fmt(computed.tax) }),
            /* @__PURE__ */ jsx(
              MiniStat,
              {
                label: "Invoice discount",
                value: step === "review" ? fmt(computed.invoiceDiscount) : "—"
              }
            ),
            /* @__PURE__ */ jsx(
              MiniStat,
              {
                label: "Total",
                value: fmt(computed.total),
                strong: true
              }
            ),
            /* @__PURE__ */ jsx(
              MiniStat,
              {
                label: "Currency",
                value: form.data.currency_code || "Not set"
              }
            )
          ] }) }),
          /* @__PURE__ */ jsx(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                step === "review" ? submit() : goNext();
              },
              className: "space-y-6",
              children: /* @__PURE__ */ jsxs(AnimatePresence, { mode: "wait", children: [
                step === "details" && /* @__PURE__ */ jsxs(
                  motion.div,
                  {
                    initial: { opacity: 0, y: 10 },
                    animate: { opacity: 1, y: 0 },
                    exit: { opacity: 0, y: 10 },
                    transition: { duration: 0.22 },
                    className: "grid grid-cols-1 gap-6 lg:grid-cols-12",
                    children: [
                      /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-7", children: [
                        /* @__PURE__ */ jsx(
                          SectionTitle,
                          {
                            icon: ClipboardList,
                            title: "Invoice details"
                          }
                        ),
                        /* @__PURE__ */ jsxs("div", { className: "mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                          /* @__PURE__ */ jsxs(Field, { label: "Client *", children: [
                            /* @__PURE__ */ jsxs(
                              Select,
                              {
                                value: form.data.client_id,
                                disabled: !hasClients,
                                onValueChange: (v) => form.setData("client_id", v),
                                children: [
                                  /* @__PURE__ */ jsx(SelectTrigger, { className: "rounded-xl", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Select client" }) }),
                                  /* @__PURE__ */ jsx(SelectContent, { children: hasClients ? clients.map((c) => /* @__PURE__ */ jsx(
                                    SelectItem,
                                    {
                                      value: String(
                                        c.id
                                      ),
                                      children: c.name
                                    },
                                    c.id
                                  )) : /* @__PURE__ */ jsx("div", { className: "px-2 py-3 text-sm text-muted-foreground", children: "No clients yet. Add a client to continue." }) })
                                ]
                              }
                            ),
                            !hasClients && /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "Create a client first, then return here." }),
                            form.errors.client_id && /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-destructive", children: form.errors.client_id })
                          ] }),
                          /* @__PURE__ */ jsx(Field, { label: "Template", children: /* @__PURE__ */ jsxs(
                            Select,
                            {
                              value: form.data.invoice_template_id,
                              onValueChange: (v) => form.setData(
                                "invoice_template_id",
                                v
                              ),
                              children: [
                                /* @__PURE__ */ jsx(SelectTrigger, { className: "rounded-xl", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Select template" }) }),
                                /* @__PURE__ */ jsx(SelectContent, { children: templates.map((t) => /* @__PURE__ */ jsxs(
                                  SelectItem,
                                  {
                                    value: String(t.id),
                                    children: [
                                      t.name,
                                      t.is_default ? " (default)" : ""
                                    ]
                                  },
                                  t.id
                                )) })
                              ]
                            }
                          ) }),
                          /* @__PURE__ */ jsx(Field, { label: "Issue date *", children: /* @__PURE__ */ jsx(
                            Input,
                            {
                              type: "date",
                              value: form.data.issue_date,
                              onChange: (e) => form.setData(
                                "issue_date",
                                e.target.value
                              ),
                              className: "rounded-xl",
                              required: true
                            }
                          ) }),
                          /* @__PURE__ */ jsx(Field, { label: "Due date", children: /* @__PURE__ */ jsx(
                            Input,
                            {
                              type: "date",
                              value: form.data.due_date,
                              onChange: (e) => form.setData(
                                "due_date",
                                e.target.value
                              ),
                              className: "rounded-xl"
                            }
                          ) }),
                          /* @__PURE__ */ jsxs(
                            Field,
                            {
                              label: "Currency *",
                              className: "sm:col-span-2",
                              children: [
                                /* @__PURE__ */ jsxs(
                                  Select,
                                  {
                                    value: form.data.currency_code,
                                    disabled: !hasCurrencies,
                                    onValueChange: (v) => form.setData(
                                      "currency_code",
                                      v
                                    ),
                                    children: [
                                      /* @__PURE__ */ jsx(SelectTrigger, { className: "rounded-xl", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Select currency" }) }),
                                      /* @__PURE__ */ jsx(SelectContent, { children: hasCurrencies ? currencyList.map((c) => /* @__PURE__ */ jsxs(
                                        SelectItem,
                                        {
                                          value: c.code,
                                          children: [
                                            c.code,
                                            " —",
                                            " ",
                                            c.name
                                          ]
                                        },
                                        c.code
                                      )) : /* @__PURE__ */ jsx("div", { className: "px-2 py-3 text-sm text-muted-foreground", children: "No active currencies configured yet." }) })
                                    ]
                                  }
                                ),
                                !hasCurrencies && /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "Activate at least one currency before creating an invoice." })
                              ]
                            }
                          ),
                          /* @__PURE__ */ jsx(Field, { label: "Title", children: /* @__PURE__ */ jsx(
                            Input,
                            {
                              value: form.data.title,
                              onChange: (e) => form.setData(
                                "title",
                                e.target.value
                              ),
                              className: "rounded-xl",
                              placeholder: "Optional invoice title"
                            }
                          ) }),
                          /* @__PURE__ */ jsx(Field, { label: "Reference", children: /* @__PURE__ */ jsx(
                            Input,
                            {
                              value: form.data.reference,
                              onChange: (e) => form.setData(
                                "reference",
                                e.target.value
                              ),
                              className: "rounded-xl",
                              placeholder: "PO / Reference"
                            }
                          ) })
                        ] }),
                        /* @__PURE__ */ jsx(Separator, { className: "my-6" }),
                        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between rounded-2xl border p-4", children: [
                          /* @__PURE__ */ jsxs("div", { children: [
                            /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Delivery note" }),
                            /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Enable if you want a delivery note option later." })
                          ] }),
                          /* @__PURE__ */ jsx(
                            Switch,
                            {
                              checked: !!form.data.has_delivery_note,
                              onCheckedChange: (v) => form.setData(
                                "has_delivery_note",
                                !!v
                              )
                            }
                          )
                        ] }),
                        /* @__PURE__ */ jsx(Separator, { className: "my-6" }),
                        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4", children: [
                          /* @__PURE__ */ jsx(Field, { label: "Notes", children: /* @__PURE__ */ jsx(
                            Textarea,
                            {
                              value: form.data.notes,
                              onChange: (e) => form.setData(
                                "notes",
                                e.target.value
                              ),
                              className: "min-h-[90px] rounded-xl"
                            }
                          ) }),
                          /* @__PURE__ */ jsx(Field, { label: "Terms", children: /* @__PURE__ */ jsx(
                            Textarea,
                            {
                              value: form.data.terms,
                              onChange: (e) => form.setData(
                                "terms",
                                e.target.value
                              ),
                              className: "min-h-[90px] rounded-xl"
                            }
                          ) })
                        ] })
                      ] }),
                      /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-5", children: [
                        /* @__PURE__ */ jsx(
                          SectionTitle,
                          {
                            icon: CalendarClock,
                            title: "Recurrence"
                          }
                        ),
                        /* @__PURE__ */ jsxs("div", { className: "mt-4 flex items-center justify-between rounded-2xl border p-4", children: [
                          /* @__PURE__ */ jsxs("div", { children: [
                            /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Recurring invoice" }),
                            /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Leave room for cron jobs later." })
                          ] }),
                          /* @__PURE__ */ jsx(
                            Switch,
                            {
                              checked: !!form.data.is_recurring,
                              onCheckedChange: (v) => form.setData(
                                "is_recurring",
                                !!v
                              )
                            }
                          )
                        ] }),
                        form.data.is_recurring && /* @__PURE__ */ jsxs("div", { className: "mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                          /* @__PURE__ */ jsx(
                            Field,
                            {
                              label: "Frequency *",
                              className: "sm:col-span-2",
                              children: /* @__PURE__ */ jsxs(
                                Select,
                                {
                                  value: form.data.recurrence_frequency,
                                  onValueChange: (v) => form.setData(
                                    "recurrence_frequency",
                                    v
                                  ),
                                  children: [
                                    /* @__PURE__ */ jsx(SelectTrigger, { className: "rounded-xl", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                                    /* @__PURE__ */ jsxs(SelectContent, { children: [
                                      /* @__PURE__ */ jsx(SelectItem, { value: "daily", children: "Daily" }),
                                      /* @__PURE__ */ jsx(SelectItem, { value: "weekly", children: "Weekly" }),
                                      /* @__PURE__ */ jsx(SelectItem, { value: "monthly", children: "Monthly" }),
                                      /* @__PURE__ */ jsx(SelectItem, { value: "yearly", children: "Yearly" })
                                    ] })
                                  ]
                                }
                              )
                            }
                          ),
                          /* @__PURE__ */ jsx(Field, { label: "Interval *", children: /* @__PURE__ */ jsx(
                            Input,
                            {
                              type: "number",
                              min: 1,
                              value: form.data.recurrence_interval,
                              onChange: (e) => form.setData(
                                "recurrence_interval",
                                Number(
                                  e.target.value
                                )
                              ),
                              className: "rounded-xl"
                            }
                          ) }),
                          /* @__PURE__ */ jsx(Field, { label: "Start date", children: /* @__PURE__ */ jsx(
                            Input,
                            {
                              type: "date",
                              value: form.data.recurrence_start_date,
                              onChange: (e) => form.setData(
                                "recurrence_start_date",
                                e.target.value
                              ),
                              className: "rounded-xl"
                            }
                          ) }),
                          /* @__PURE__ */ jsx(Field, { label: "End date", children: /* @__PURE__ */ jsx(
                            Input,
                            {
                              type: "date",
                              value: form.data.recurrence_end_date,
                              onChange: (e) => form.setData(
                                "recurrence_end_date",
                                e.target.value
                              ),
                              className: "rounded-xl"
                            }
                          ) })
                        ] })
                      ] })
                    ]
                  },
                  "details"
                ),
                step === "items" && /* @__PURE__ */ jsxs(
                  motion.div,
                  {
                    initial: { opacity: 0, y: 10 },
                    animate: { opacity: 1, y: 0 },
                    exit: { opacity: 0, y: 10 },
                    transition: { duration: 0.22 },
                    className: "grid grid-cols-1 gap-6 lg:grid-cols-12",
                    children: [
                      /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-8", children: [
                        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3", children: [
                          /* @__PURE__ */ jsx(
                            SectionTitle,
                            {
                              icon: Receipt,
                              title: "Line items"
                            }
                          ),
                          /* @__PURE__ */ jsxs(
                            Button,
                            {
                              type: "button",
                              variant: "outline",
                              onClick: addItem,
                              className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                              children: [
                                /* @__PURE__ */ jsx(Plus, { className: "mr-2 h-4 w-4" }),
                                "Add item"
                              ]
                            }
                          )
                        ] }),
                        /* @__PURE__ */ jsx("div", { className: "mt-4 space-y-4", children: form.data.items.map((it, idx) => /* @__PURE__ */ jsxs(
                          motion.div,
                          {
                            initial: { opacity: 0, y: 10 },
                            animate: { opacity: 1, y: 0 },
                            transition: { duration: 0.18 },
                            className: "rounded-2xl border p-4",
                            children: [
                              /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-2", children: [
                                /* @__PURE__ */ jsxs("div", { className: "text-sm font-semibold", children: [
                                  "Item ",
                                  idx + 1
                                ] }),
                                /* @__PURE__ */ jsx(
                                  Button,
                                  {
                                    type: "button",
                                    variant: "ghost",
                                    size: "sm",
                                    onClick: () => removeItem(idx),
                                    className: "rounded-xl",
                                    children: /* @__PURE__ */ jsx(Trash2, { className: "h-4 w-4" })
                                  }
                                )
                              ] }),
                              /* @__PURE__ */ jsxs("div", { className: "mt-3 space-y-3", children: [
                                /* @__PURE__ */ jsx(Field, { label: "Description *", children: /* @__PURE__ */ jsx(
                                  Input,
                                  {
                                    value: it.description,
                                    onChange: (e) => updateItem(
                                      idx,
                                      "description",
                                      e.target.value
                                    ),
                                    className: "rounded-xl",
                                    required: true
                                  }
                                ) }),
                                /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
                                  /* @__PURE__ */ jsx(Field, { label: "Qty *", children: /* @__PURE__ */ jsx(
                                    Input,
                                    {
                                      type: "number",
                                      min: 0.01,
                                      step: 0.01,
                                      value: it.quantity,
                                      onChange: (e) => updateItem(
                                        idx,
                                        "quantity",
                                        Number(
                                          e.target.value
                                        )
                                      ),
                                      className: "rounded-xl"
                                    }
                                  ) }),
                                  /* @__PURE__ */ jsx(Field, { label: "Unit price *", children: /* @__PURE__ */ jsx(
                                    Input,
                                    {
                                      type: "number",
                                      min: 0,
                                      step: 0.01,
                                      value: it.unit_price,
                                      onChange: (e) => updateItem(
                                        idx,
                                        "unit_price",
                                        Number(
                                          e.target.value
                                        )
                                      ),
                                      className: "rounded-xl"
                                    }
                                  ) }),
                                  /* @__PURE__ */ jsx(Field, { label: "Discount", children: /* @__PURE__ */ jsx(
                                    Input,
                                    {
                                      type: "number",
                                      min: 0,
                                      step: 0.01,
                                      value: it.discount,
                                      onChange: (e) => updateItem(
                                        idx,
                                        "discount",
                                        Number(
                                          e.target.value
                                        )
                                      ),
                                      className: "rounded-xl"
                                    }
                                  ) }),
                                  /* @__PURE__ */ jsx(Field, { label: "Tax", children: /* @__PURE__ */ jsx(
                                    Input,
                                    {
                                      type: "number",
                                      min: 0,
                                      step: 0.01,
                                      value: it.tax,
                                      onChange: (e) => updateItem(
                                        idx,
                                        "tax",
                                        Number(
                                          e.target.value
                                        )
                                      ),
                                      className: "rounded-xl"
                                    }
                                  ) })
                                ] })
                              ] })
                            ]
                          },
                          idx
                        )) })
                      ] }),
                      /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-4", children: [
                        /* @__PURE__ */ jsx(
                          SectionTitle,
                          {
                            icon: BadgePercent,
                            title: "Totals (preview)"
                          }
                        ),
                        /* @__PURE__ */ jsxs("div", { className: "mt-4 space-y-2 rounded-2xl border bg-muted/20 p-4", children: [
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Subtotal",
                              value: computed.subtotal,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Line discount",
                              value: computed.lineDiscount,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Tax",
                              value: computed.tax,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(Separator, { className: "my-2" }),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Total",
                              value: computed.total,
                              precision,
                              strong: true
                            }
                          )
                        ] }),
                        /* @__PURE__ */ jsx("div", { className: "mt-4 text-xs text-muted-foreground", children: "Overall invoice discount is applied on the review step." })
                      ] })
                    ]
                  },
                  "items"
                ),
                step === "review" && /* @__PURE__ */ jsxs(
                  motion.div,
                  {
                    initial: { opacity: 0, y: 10 },
                    animate: { opacity: 1, y: 0 },
                    exit: { opacity: 0, y: 10 },
                    transition: { duration: 0.22 },
                    className: "grid grid-cols-1 gap-6 lg:grid-cols-12",
                    children: [
                      /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-8", children: [
                        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3", children: [
                          /* @__PURE__ */ jsx(
                            SectionTitle,
                            {
                              icon: CheckCircle2,
                              title: "Review"
                            }
                          ),
                          /* @__PURE__ */ jsxs(
                            Button,
                            {
                              type: "button",
                              variant: "outline",
                              onClick: openPreview,
                              disabled: !canCreateInvoice,
                              className: "gap-2 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                              children: [
                                /* @__PURE__ */ jsx(Eye, { className: "h-4 w-4" }),
                                "Preview invoice"
                              ]
                            }
                          )
                        ] }),
                        /* @__PURE__ */ jsxs("div", { className: "mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Client",
                              value: clientLabel(
                                clients,
                                form.data.client_id
                              )
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Template",
                              value: templateLabel(
                                templates,
                                form.data.invoice_template_id
                              )
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Issue date",
                              value: form.data.issue_date || "—"
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Due date",
                              value: form.data.due_date || "—"
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Currency",
                              value: form.data.currency_code || "Not set"
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Delivery note",
                              value: form.data.has_delivery_note ? "Yes" : "No"
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Recurring",
                              value: form.data.is_recurring ? "Yes" : "No"
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            ReviewField,
                            {
                              label: "Status",
                              value: form.data.status
                            }
                          )
                        ] }),
                        /* @__PURE__ */ jsx(Separator, { className: "my-6" }),
                        /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border p-4", children: [
                          /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
                            /* @__PURE__ */ jsx("div", { className: "grid h-10 w-10 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(BadgePercent, { className: "h-5 w-5 opacity-80" }) }),
                            /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
                              /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Final adjustments" }),
                              /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Overall discount + invoice status." })
                            ] })
                          ] }),
                          /* @__PURE__ */ jsxs("div", { className: "mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                            /* @__PURE__ */ jsx(Field, { label: "Overall discount", children: /* @__PURE__ */ jsx(
                              Input,
                              {
                                type: "number",
                                min: 0,
                                step: 0.01,
                                value: form.data.invoice_discount,
                                onChange: (e) => form.setData(
                                  "invoice_discount",
                                  Number(
                                    e.target.value
                                  )
                                ),
                                className: "rounded-xl"
                              }
                            ) }),
                            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                              /* @__PURE__ */ jsx(Label, { children: "Status" }),
                              /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
                                /* @__PURE__ */ jsx(
                                  StatusPill,
                                  {
                                    active: form.data.status === "pending",
                                    onClick: () => form.setData(
                                      "status",
                                      "pending"
                                    ),
                                    label: "Pending"
                                  }
                                ),
                                /* @__PURE__ */ jsx(
                                  StatusPill,
                                  {
                                    active: form.data.status === "paid",
                                    onClick: () => form.setData(
                                      "status",
                                      "paid"
                                    ),
                                    label: "Paid"
                                  }
                                )
                              ] }),
                              /* @__PURE__ */ jsx("div", { className: "hidden", children: /* @__PURE__ */ jsxs(
                                Select,
                                {
                                  value: form.data.status,
                                  onValueChange: (v) => form.setData(
                                    "status",
                                    v
                                  ),
                                  children: [
                                    /* @__PURE__ */ jsx(SelectTrigger, {}),
                                    /* @__PURE__ */ jsxs(SelectContent, { children: [
                                      /* @__PURE__ */ jsx(SelectItem, { value: "pending", children: "Pending" }),
                                      /* @__PURE__ */ jsx(SelectItem, { value: "paid", children: "Paid" })
                                    ] })
                                  ]
                                }
                              ) }),
                              form.errors.status && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.status })
                            ] })
                          ] })
                        ] }),
                        /* @__PURE__ */ jsx(Separator, { className: "my-6" }),
                        /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Items" }),
                        /* @__PURE__ */ jsxs("div", { className: "mt-3 rounded-2xl border", children: [
                          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-12 gap-2 border-b bg-muted/40 px-4 py-3 text-xs font-semibold text-muted-foreground", children: [
                            /* @__PURE__ */ jsx("div", { className: "col-span-6", children: "Description" }),
                            /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: "Qty" }),
                            /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: "Price" }),
                            /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: "Line" })
                          ] }),
                          /* @__PURE__ */ jsx("div", { className: "divide-y", children: form.data.items.map((it, idx) => {
                            const qty = Number(
                              it.quantity || 0
                            );
                            const price = Number(
                              it.unit_price || 0
                            );
                            const disc = Number(
                              it.discount || 0
                            );
                            const tax = Number(it.tax || 0);
                            const base = qty * price;
                            const line = Math.max(
                              0,
                              base - disc + tax
                            );
                            return /* @__PURE__ */ jsxs(
                              "div",
                              {
                                className: "grid grid-cols-12 gap-2 px-4 py-3 text-sm",
                                children: [
                                  /* @__PURE__ */ jsx("div", { className: "col-span-6 min-w-0", children: /* @__PURE__ */ jsx("div", { className: "truncate font-medium", children: it.description || "—" }) }),
                                  /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: fmt(qty) }),
                                  /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: fmt(price) }),
                                  /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right font-semibold", children: fmt(line) })
                                ]
                              },
                              idx
                            );
                          }) })
                        ] })
                      ] }),
                      /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-4", children: [
                        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                          /* @__PURE__ */ jsx(
                            SectionTitle,
                            {
                              icon: BadgePercent,
                              title: "Final totals"
                            }
                          ),
                          /* @__PURE__ */ jsxs(
                            Button,
                            {
                              type: "button",
                              variant: "outline",
                              onClick: openPreview,
                              disabled: !canCreateInvoice,
                              className: "gap-2 rounded-xl",
                              children: [
                                /* @__PURE__ */ jsx(Eye, { className: "h-4 w-4" }),
                                "Preview"
                              ]
                            }
                          )
                        ] }),
                        /* @__PURE__ */ jsxs("div", { className: "mt-4 space-y-2 rounded-2xl border bg-muted/20 p-4", children: [
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Subtotal",
                              value: computed.subtotal,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Line discount",
                              value: computed.lineDiscount,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Invoice discount",
                              value: computed.invoiceDiscount,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Tax",
                              value: computed.tax,
                              precision
                            }
                          ),
                          /* @__PURE__ */ jsx(Separator, { className: "my-2" }),
                          /* @__PURE__ */ jsx(
                            Row,
                            {
                              label: "Total",
                              value: computed.total,
                              precision,
                              strong: true
                            }
                          )
                        ] }),
                        /* @__PURE__ */ jsxs(
                          Button,
                          {
                            type: "button",
                            onClick: submit,
                            disabled: form.processing || !canCreateInvoice,
                            className: "mt-4 w-full gap-2 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                            children: [
                              "Create invoice",
                              /* @__PURE__ */ jsx(CheckCircle2, { className: "h-4 w-4" })
                            ]
                          }
                        )
                      ] })
                    ]
                  },
                  "review"
                )
              ] })
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsx(Dialog, { open: previewOpen, onOpenChange: setPreviewOpen, children: /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-6xl rounded-2xl p-0", children: [
      /* @__PURE__ */ jsx(DialogHeader, { className: "px-5 pt-5", children: /* @__PURE__ */ jsxs(DialogTitle, { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Eye, { className: "h-5 w-5 opacity-80" }),
        "Invoice preview"
      ] }) }),
      /* @__PURE__ */ jsx("div", { className: "h-[78vh] px-5 pb-5", children: /* @__PURE__ */ jsx(
        "iframe",
        {
          title: "Invoice preview",
          className: "h-full w-full rounded-2xl border bg-white",
          srcDoc: previewHtml
        }
      ) })
    ] }) })
  ] });
}
function SectionTitle({ icon: Icon, title }) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ jsx(Icon, { className: "h-5 w-5 opacity-80" }),
    /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: title })
  ] });
}
function Field({
  label,
  children,
  className
}) {
  return /* @__PURE__ */ jsxs("div", { className: cn("space-y-2", className), children: [
    /* @__PURE__ */ jsx(Label, { children: label }),
    children
  ] });
}
function MiniStat({
  label,
  value,
  strong
}) {
  return /* @__PURE__ */ jsxs("div", { className: "rounded-xl border bg-background p-3", children: [
    /* @__PURE__ */ jsx("div", { className: "text-[11px] text-muted-foreground", children: label }),
    /* @__PURE__ */ jsx(
      "div",
      {
        className: cn(
          "mt-1 text-sm font-semibold",
          strong && "text-base"
        ),
        children: value
      }
    )
  ] });
}
function Row({
  label,
  value,
  precision,
  strong
}) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
    /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground", children: label }),
    /* @__PURE__ */ jsx(
      "span",
      {
        className: cn("text-sm", strong && "text-base font-semibold"),
        children: Number.isFinite(value) ? value.toFixed(precision) : 0 .toFixed(precision)
      }
    )
  ] });
}
function ReviewField({ label, value }) {
  return /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border p-4", children: [
    /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: label }),
    /* @__PURE__ */ jsx("div", { className: "mt-1 text-sm font-semibold capitalize", children: value })
  ] });
}
function StatusPill({
  active,
  onClick,
  label
}) {
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      onClick,
      className: cn(
        "rounded-full border px-3 py-2 text-xs font-semibold transition",
        active ? "border-foreground bg-foreground text-background" : "bg-background hover:bg-muted/40"
      ),
      children: label
    }
  );
}
function clientLabel(clients, id) {
  const c = clients.find((x) => String(x.id) === String(id));
  return c ? c.name : "—";
}
function templateLabel(templates, id) {
  const t = templates.find((x) => String(x.id) === String(id));
  return t ? t.name : "—";
}
export {
  InvoicesCreate as default
};
