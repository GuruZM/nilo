import { jsxs, jsx } from "react/jsx-runtime";
import { A as AppLayout } from "./app-layout-JvxHjkrs.js";
import { Head, Link } from "@inertiajs/react";
import { motion, AnimatePresence } from "framer-motion";
import { FileSignature, Plus, Clock, ArrowUpRight, CheckCircle2, BadgeDollarSign, Search, Filter, Calendar, RefreshCw, AlertTriangle, XCircle } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";
import { B as Badge } from "./badge-CfxidL8Q.js";
import { B as Button, c as cn } from "./button-DMGEFYrU.js";
import { C as Card } from "./card-MypPWj87.js";
import { D as DropdownMenu, a as DropdownMenuTrigger, b as DropdownMenuContent, c as DropdownMenuLabel, d as DropdownMenuSeparator, e as DropdownMenuItem } from "./app-sidebar-layout-BGzXXcN9.js";
import { I as Input } from "./input-nVyaPHpJ.js";
import { S as Separator } from "./separator-Bcia5PKZ.js";
import "./Chatbot-yoo4250k.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "@radix-ui/react-separator";
const breadcrumbs = [
  { title: "Quotations", href: "/quotations" }
];
function statusBadgeVariant(status) {
  const value = (status || "").toLowerCase();
  if (value === "accepted") {
    return "secondary";
  }
  if (value === "expired") {
    return "destructive";
  }
  if (value === "sent") {
    return "outline";
  }
  return "outline";
}
function statusIcon(status) {
  const value = (status || "").toLowerCase();
  if (value === "accepted") {
    return CheckCircle2;
  }
  if (value === "expired") {
    return AlertTriangle;
  }
  if (value === "sent") {
    return ArrowUpRight;
  }
  if (value === "void") {
    return XCircle;
  }
  return Clock;
}
function formatMoney(value, opts) {
  const precision = opts?.precision ?? 2;
  const symbol = opts?.symbol ?? null;
  const code = opts?.code ?? null;
  const amount = Number.isFinite(value) ? value : 0;
  const prefix = symbol ? `${symbol} ` : code ? `${code} ` : "";
  return `${prefix}${amount.toFixed(precision)}`;
}
function QuotationsIndex({
  quotations,
  hasActiveCompany = true,
  currencies
}) {
  const [query, setQuery] = React.useState("");
  const [status, setStatus] = React.useState("all");
  const [sort, setSort] = React.useState("newest");
  const activeCurrency = currencies?.current;
  const filtered = React.useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    let rows = quotations;
    if (status !== "all") {
      rows = rows.filter(
        (quotation) => (quotation.status || "").toLowerCase() === String(status).toLowerCase()
      );
    }
    if (normalizedQuery) {
      rows = rows.filter((quotation) => {
        const haystack = `${quotation.number ?? ""} ${quotation.client_name ?? ""} ${quotation.status ?? ""}`.toLowerCase();
        return haystack.includes(normalizedQuery);
      });
    }
    rows = [...rows].sort((left, right) => {
      const leftDate = new Date(left.created_at).getTime();
      const rightDate = new Date(right.created_at).getTime();
      if (sort === "newest") {
        return rightDate - leftDate;
      }
      if (sort === "oldest") {
        return leftDate - rightDate;
      }
      const leftAmount = Number(left.total ?? 0);
      const rightAmount = Number(right.total ?? 0);
      if (sort === "amount_desc") {
        return rightAmount - leftAmount;
      }
      if (sort === "amount_asc") {
        return leftAmount - rightAmount;
      }
      return 0;
    });
    return rows;
  }, [quotations, query, sort, status]);
  const stats = React.useMemo(() => {
    const all = quotations.length;
    const draft = quotations.filter(
      (quotation) => (quotation.status || "").toLowerCase() === "draft"
    ).length;
    const sent = quotations.filter(
      (quotation) => (quotation.status || "").toLowerCase() === "sent"
    ).length;
    const accepted = quotations.filter(
      (quotation) => (quotation.status || "").toLowerCase() === "accepted"
    ).length;
    const expired = quotations.filter(
      (quotation) => (quotation.status || "").toLowerCase() === "expired"
    ).length;
    const totalValue = quotations.reduce(
      (sum, quotation) => sum + Number(quotation.total ?? 0),
      0
    );
    return { all, draft, sent, accepted, expired, totalValue };
  }, [quotations]);
  const resetFilters = () => {
    setQuery("");
    setStatus("all");
    setSort("newest");
    toast.success("Filters cleared.");
  };
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Quotations" }),
    /* @__PURE__ */ jsxs(
      motion.div,
      {
        initial: { opacity: 0, y: 14 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.3, ease: "easeOut" },
        className: "mx-auto w-full px-4 py-10 sm:px-6",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "grid h-11 w-11 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(FileSignature, { className: "h-6 w-6 text-foreground/80" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight sm:text-3xl", children: "Quotations" }),
                /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "Track drafts, sent quotations, and accepted offers for your active company." })
              ] })
            ] }),
            hasActiveCompany ? /* @__PURE__ */ jsx(
              Button,
              {
                asChild: true,
                className: "gap-2 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                children: /* @__PURE__ */ jsxs(Link, { href: "/quotations/create", children: [
                  /* @__PURE__ */ jsx(Plus, { className: "h-4 w-4" }),
                  "Add quotation"
                ] })
              }
            ) : /* @__PURE__ */ jsxs(
              Button,
              {
                type: "button",
                disabled: true,
                className: "gap-2 rounded-xl",
                children: [
                  /* @__PURE__ */ jsx(Plus, { className: "h-4 w-4" }),
                  "Add quotation"
                ]
              }
            )
          ] }),
          !hasActiveCompany && /* @__PURE__ */ jsx(Card, { className: "mb-6 rounded-2xl border-dashed bg-muted/20 p-5 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
            /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Add or select a company to use quotations" }),
            /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "The quotations module is available, but you need an active company before quotations can be listed or created." }),
            /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(Button, { asChild: true, className: "rounded-xl", children: /* @__PURE__ */ jsx(Link, { href: "/companies", children: "Manage companies" }) }) })
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5", children: [
            /* @__PURE__ */ jsx(
              StatCard,
              {
                title: "Total quotations",
                value: String(stats.all),
                icon: FileSignature
              }
            ),
            /* @__PURE__ */ jsx(
              StatCard,
              {
                title: "Drafts",
                value: String(stats.draft),
                icon: Clock
              }
            ),
            /* @__PURE__ */ jsx(
              StatCard,
              {
                title: "Sent",
                value: String(stats.sent),
                icon: ArrowUpRight
              }
            ),
            /* @__PURE__ */ jsx(
              StatCard,
              {
                title: "Accepted",
                value: String(stats.accepted),
                icon: CheckCircle2
              }
            ),
            /* @__PURE__ */ jsx(
              StatCard,
              {
                title: "Total value",
                value: formatMoney(stats.totalValue, activeCurrency),
                icon: BadgeDollarSign
              }
            )
          ] }),
          /* @__PURE__ */ jsx(Separator, { className: "my-6" }),
          /* @__PURE__ */ jsx(Card, { className: "rounded-2xl border bg-background p-4 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "relative w-full lg:max-w-md", children: [
              /* @__PURE__ */ jsx(Search, { className: "pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  value: query,
                  onChange: (event) => setQuery(event.target.value),
                  placeholder: "Search by number, client, status...",
                  className: "rounded-xl pl-9"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2 sm:flex-row sm:items-center", children: [
              /* @__PURE__ */ jsxs(DropdownMenu, { children: [
                /* @__PURE__ */ jsx(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(
                  Button,
                  {
                    variant: "outline",
                    className: "gap-2 rounded-xl",
                    children: [
                      /* @__PURE__ */ jsx(Filter, { className: "h-4 w-4" }),
                      "Status:",
                      " ",
                      status === "all" ? "All" : status
                    ]
                  }
                ) }),
                /* @__PURE__ */ jsxs(
                  DropdownMenuContent,
                  {
                    align: "end",
                    className: "w-56 rounded-xl",
                    children: [
                      /* @__PURE__ */ jsx(DropdownMenuLabel, { className: "text-xs text-muted-foreground", children: "Filter by status" }),
                      /* @__PURE__ */ jsx(DropdownMenuSeparator, {}),
                      [
                        "all",
                        "draft",
                        "sent",
                        "accepted",
                        "expired"
                      ].map((value) => /* @__PURE__ */ jsx(
                        DropdownMenuItem,
                        {
                          onClick: () => setStatus(value),
                          className: "rounded-lg",
                          children: value === "all" ? "All" : value
                        },
                        value
                      ))
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs(DropdownMenu, { children: [
                /* @__PURE__ */ jsx(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(
                  Button,
                  {
                    variant: "outline",
                    className: "gap-2 rounded-xl",
                    children: [
                      /* @__PURE__ */ jsx(Calendar, { className: "h-4 w-4" }),
                      "Sort"
                    ]
                  }
                ) }),
                /* @__PURE__ */ jsxs(
                  DropdownMenuContent,
                  {
                    align: "end",
                    className: "w-56 rounded-xl",
                    children: [
                      /* @__PURE__ */ jsx(DropdownMenuLabel, { className: "text-xs text-muted-foreground", children: "Sort quotations" }),
                      /* @__PURE__ */ jsx(DropdownMenuSeparator, {}),
                      /* @__PURE__ */ jsx(
                        DropdownMenuItem,
                        {
                          onClick: () => setSort("newest"),
                          className: "rounded-lg",
                          children: "Newest first"
                        }
                      ),
                      /* @__PURE__ */ jsx(
                        DropdownMenuItem,
                        {
                          onClick: () => setSort("oldest"),
                          className: "rounded-lg",
                          children: "Oldest first"
                        }
                      ),
                      /* @__PURE__ */ jsx(DropdownMenuSeparator, {}),
                      /* @__PURE__ */ jsx(
                        DropdownMenuItem,
                        {
                          onClick: () => setSort("amount_desc"),
                          className: "rounded-lg",
                          children: "Amount (high → low)"
                        }
                      ),
                      /* @__PURE__ */ jsx(
                        DropdownMenuItem,
                        {
                          onClick: () => setSort("amount_asc"),
                          className: "rounded-lg",
                          children: "Amount (low → high)"
                        }
                      )
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs(
                Button,
                {
                  variant: "ghost",
                  onClick: resetFilters,
                  className: "gap-2 rounded-xl",
                  children: [
                    /* @__PURE__ */ jsx(RefreshCw, { className: "h-4 w-4" }),
                    "Reset"
                  ]
                }
              )
            ] })
          ] }) }),
          /* @__PURE__ */ jsx(Card, { className: "mt-4 overflow-hidden rounded-2xl border bg-background shadow-sm", children: /* @__PURE__ */ jsx("div", { className: "w-full overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "min-w-full", children: [
            /* @__PURE__ */ jsx("thead", { className: "bg-muted/40", children: /* @__PURE__ */ jsxs("tr", { className: "text-left text-xs text-muted-foreground", children: [
              /* @__PURE__ */ jsx("th", { className: "px-6 py-3 font-semibold", children: "Quotation" }),
              /* @__PURE__ */ jsx("th", { className: "px-6 py-3 font-semibold", children: "Amount" }),
              /* @__PURE__ */ jsx("th", { className: "px-6 py-3 font-semibold", children: "Status" }),
              /* @__PURE__ */ jsx("th", { className: "px-6 py-3 font-semibold", children: "Created" })
            ] }) }),
            /* @__PURE__ */ jsx("tbody", { className: "divide-y", children: /* @__PURE__ */ jsx(AnimatePresence, { mode: "popLayout", children: filtered.length === 0 ? /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx(
              "td",
              {
                colSpan: 4,
                className: "px-6 py-14 text-center",
                children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-sm", children: [
                  /* @__PURE__ */ jsx("div", { className: "mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(FileSignature, { className: "h-6 w-6 text-foreground/70" }) }),
                  /* @__PURE__ */ jsx("div", { className: "text-sm font-medium", children: "No quotations found" }),
                  /* @__PURE__ */ jsx("div", { className: "mt-1 text-sm text-muted-foreground", children: "Try changing your filters or create your first quotation." }),
                  /* @__PURE__ */ jsx("div", { className: "mt-4", children: hasActiveCompany ? /* @__PURE__ */ jsx(
                    Button,
                    {
                      asChild: true,
                      className: "rounded-xl",
                      children: /* @__PURE__ */ jsxs(Link, { href: "/quotations/create", children: [
                        /* @__PURE__ */ jsx(Plus, { className: "mr-2 h-4 w-4" }),
                        "Add quotation"
                      ] })
                    }
                  ) : /* @__PURE__ */ jsxs(
                    Button,
                    {
                      type: "button",
                      disabled: true,
                      className: "rounded-xl",
                      children: [
                        /* @__PURE__ */ jsx(Plus, { className: "mr-2 h-4 w-4" }),
                        "Add quotation"
                      ]
                    }
                  ) })
                ] })
              }
            ) }) : filtered.map((quotation, index) => {
              const StatusIcon = statusIcon(
                quotation.status
              );
              const money = formatMoney(
                Number(quotation.total ?? 0),
                {
                  code: quotation.currency_code ?? activeCurrency?.code ?? null,
                  symbol: activeCurrency?.symbol ?? null,
                  precision: activeCurrency?.precision ?? 2
                }
              );
              return /* @__PURE__ */ jsxs(
                motion.tr,
                {
                  initial: { opacity: 0, y: 8 },
                  animate: { opacity: 1, y: 0 },
                  exit: { opacity: 0, y: 8 },
                  transition: {
                    duration: 0.18,
                    delay: Math.min(
                      index * 0.02,
                      0.14
                    )
                  },
                  children: [
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
                      /* @__PURE__ */ jsx("div", { className: "grid h-9 w-9 place-items-center rounded-xl bg-muted/60", children: /* @__PURE__ */ jsx(StatusIcon, { className: "h-4 w-4 opacity-80" }) }),
                      /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
                        /* @__PURE__ */ jsx("div", { className: "truncate text-sm font-semibold", children: quotation.number ?? `Quotation #${quotation.id}` }),
                        /* @__PURE__ */ jsxs("div", { className: "truncate text-xs text-muted-foreground", children: [
                          quotation.client_name ?? "Client",
                          " ",
                          "•",
                          " ",
                          quotation.currency_code ?? activeCurrency?.code ?? "—"
                        ] })
                      ] })
                    ] }) }),
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: money }) }),
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsxs(
                      Badge,
                      {
                        variant: statusBadgeVariant(
                          quotation.status
                        ),
                        className: cn(
                          "rounded-xl capitalize",
                          String(
                            quotation.status
                          ).toLowerCase() === "expired" && "gap-1"
                        ),
                        children: [
                          quotation.status,
                          String(
                            quotation.status
                          ).toLowerCase() === "expired" && /* @__PURE__ */ jsx(AlertTriangle, { className: "ml-1 h-3.5 w-3.5" })
                        ]
                      }
                    ) }),
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-4 text-sm text-muted-foreground", children: new Date(
                      quotation.created_at
                    ).toLocaleDateString() })
                  ]
                },
                quotation.id
              );
            }) }) })
          ] }) }) })
        ]
      }
    )
  ] });
}
function StatCard({
  title,
  value,
  icon: Icon
}) {
  return /* @__PURE__ */ jsx(
    motion.div,
    {
      initial: { opacity: 0, y: 10 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.22, ease: "easeOut" },
      children: /* @__PURE__ */ jsx(Card, { className: "rounded-2xl border bg-background p-4 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsx("div", { className: "grid h-10 w-10 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(Icon, { className: "h-5 w-5 text-foreground/80" }) }),
        /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: title }),
          /* @__PURE__ */ jsx("div", { className: "truncate text-lg font-semibold", children: value })
        ] })
      ] }) })
    }
  );
}
export {
  QuotationsIndex as default
};
