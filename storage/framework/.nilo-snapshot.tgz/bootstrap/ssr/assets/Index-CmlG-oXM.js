import { jsxs, jsx } from "react/jsx-runtime";
import { A as AppLayout } from "./app-layout-JvxHjkrs.js";
import { Head, Link } from "@inertiajs/react";
import { motion, AnimatePresence } from "framer-motion";
import { FileText, Plus, Clock, ArrowUpRight, CheckCircle2, BadgeDollarSign, Search, Filter, Calendar, RefreshCw, AlertTriangle, XCircle } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";
import { B as Badge } from "./badge-CfxidL8Q.js";
import { B as Button, c as cn } from "./button-DMGEFYrU.js";
import { C as Card } from "./card-MypPWj87.js";
import { D as DropdownMenu, a as DropdownMenuTrigger, b as DropdownMenuContent, c as DropdownMenuLabel, d as DropdownMenuSeparator, e as DropdownMenuItem } from "./app-sidebar-layout-BGzXXcN9.js";
import { I as Input } from "./input-nVyaPHpJ.js";
import { S as Separator } from "./separator-Bcia5PKZ.js";
import "./Chatbot-yoo4250k.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "@radix-ui/react-separator";
const breadcrumbs = [
  { title: "Invoices", href: "/invoices" }
];
function statusBadgeVariant(status) {
  const s = (status || "").toLowerCase();
  if (s === "paid") return "secondary";
  if (s === "overdue") return "destructive";
  if (s === "sent") return "outline";
  if (s === "void") return "destructive";
  return "outline";
}
function statusIcon(status) {
  const s = (status || "").toLowerCase();
  if (s === "paid") return CheckCircle2;
  if (s === "overdue") return AlertTriangle;
  if (s === "void") return XCircle;
  if (s === "sent") return Clock;
  return FileText;
}
function formatMoney(value, opts) {
  const precision = opts?.precision ?? 2;
  const symbol = opts?.symbol ?? null;
  const code = opts?.code ?? null;
  const n = Number.isFinite(value) ? value : 0;
  const prefix = symbol ? `${symbol} ` : code ? `${code} ` : "";
  return `${prefix}${n.toFixed(precision)}`;
}
function InvoicesIndex({
  invoices,
  hasActiveCompany = true,
  currencies
}) {
  const [query, setQuery] = React.useState("");
  const [status, setStatus] = React.useState("all");
  const [sort, setSort] = React.useState("newest");
  const activeCurrency = currencies?.current;
  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    let rows = invoices;
    if (status !== "all") {
      rows = rows.filter(
        (i) => (i.status || "").toLowerCase() === String(status).toLowerCase()
      );
    }
    if (q) {
      rows = rows.filter((i) => {
        const hay = `${i.number ?? ""} ${i.client_name ?? ""} ${i.status ?? ""}`.toLowerCase();
        return hay.includes(q);
      });
    }
    rows = [...rows].sort((a, b) => {
      const aDate = new Date(a.created_at).getTime();
      const bDate = new Date(b.created_at).getTime();
      if (sort === "newest") return bDate - aDate;
      if (sort === "oldest") return aDate - bDate;
      const aAmt = Number(a.total ?? 0);
      const bAmt = Number(b.total ?? 0);
      if (sort === "amount_desc") return bAmt - aAmt;
      if (sort === "amount_asc") return aAmt - bAmt;
      return 0;
    });
    return rows;
  }, [invoices, query, status, sort]);
  const stats = React.useMemo(() => {
    const all = invoices.length;
    const draft = invoices.filter(
      (i) => (i.status || "").toLowerCase() === "draft"
    ).length;
    const sent = invoices.filter(
      (i) => (i.status || "").toLowerCase() === "sent"
    ).length;
    const paid = invoices.filter(
      (i) => (i.status || "").toLowerCase() === "paid"
    ).length;
    const overdue = invoices.filter(
      (i) => (i.status || "").toLowerCase() === "overdue"
    ).length;
    const totalValue = invoices.reduce(
      (sum, i) => sum + Number(i.total ?? 0),
      0
    );
    return { all, draft, sent, paid, overdue, totalValue };
  }, [invoices]);
  const resetFilters = () => {
    setQuery("");
    setStatus("all");
    setSort("newest");
    toast.success("Filters cleared.");
  };
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Invoices" }),
    /* @__PURE__ */ jsxs(
      motion.div,
      {
        initial: { opacity: 0, y: 14 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.3, ease: "easeOut" },
        className: "mx-auto w-full px-4 py-10 sm:px-6",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "grid h-11 w-11 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(FileText, { className: "h-6 w-6 text-foreground/80" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight sm:text-3xl", children: "Invoices" }),
                /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "Track drafts, sent invoices, and payments — all scoped to your active company." })
              ] })
            ] }),
            /* @__PURE__ */ jsx(
              Button,
              {
                asChild: true,
                disabled: !hasActiveCompany,
                className: "gap-2 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                children: /* @__PURE__ */ jsxs(Link, { href: "/invoices/create", children: [
                  /* @__PURE__ */ jsx(Plus, { className: "h-4 w-4" }),
                  "Add invoice"
                ] })
              }
            )
          ] }),
          !hasActiveCompany && /* @__PURE__ */ jsx(Card, { className: "mb-6 rounded-2xl border-dashed bg-muted/20 p-5 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
            /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Add or select a company to use invoices" }),
            /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "The invoices module is available, but you need an active company before invoices can be listed or created." }),
            /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(Button, { asChild: true, className: "rounded-xl", children: /* @__PURE__ */ jsx(Link, { href: "/companies", children: "Manage companies" }) }) })
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5", children: [
            /* @__PURE__ */ jsx(
              StatCard,
              {
                title: "Total invoices",
                value: String(stats.all),
                icon: FileText
              }
            ),
            /* @__PURE__ */ jsx(
              StatCard,
              {
                title: "Drafts",
                value: String(stats.draft),
                icon: Clock
              }
            ),
            /* @__PURE__ */ jsx(
              StatCard,
              {
                title: "Sent",
                value: String(stats.sent),
                icon: ArrowUpRight
              }
            ),
            /* @__PURE__ */ jsx(
              StatCard,
              {
                title: "Paid",
                value: String(stats.paid),
                icon: CheckCircle2
              }
            ),
            /* @__PURE__ */ jsx(
              StatCard,
              {
                title: "Total value",
                value: formatMoney(stats.totalValue, activeCurrency),
                icon: BadgeDollarSign
              }
            )
          ] }),
          /* @__PURE__ */ jsx(Separator, { className: "my-6" }),
          /* @__PURE__ */ jsx(Card, { className: "rounded-2xl border bg-background p-4 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "relative w-full lg:max-w-md", children: [
              /* @__PURE__ */ jsx(Search, { className: "pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  value: query,
                  onChange: (e) => setQuery(e.target.value),
                  placeholder: "Search by number, client, status...",
                  className: "rounded-xl pl-9"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2 sm:flex-row sm:items-center", children: [
              /* @__PURE__ */ jsxs(DropdownMenu, { children: [
                /* @__PURE__ */ jsx(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(
                  Button,
                  {
                    variant: "outline",
                    className: "gap-2 rounded-xl",
                    children: [
                      /* @__PURE__ */ jsx(Filter, { className: "h-4 w-4" }),
                      "Status:",
                      " ",
                      status === "all" ? "All" : status
                    ]
                  }
                ) }),
                /* @__PURE__ */ jsxs(
                  DropdownMenuContent,
                  {
                    align: "end",
                    className: "w-56 rounded-xl",
                    children: [
                      /* @__PURE__ */ jsx(DropdownMenuLabel, { className: "text-xs text-muted-foreground", children: "Filter by status" }),
                      /* @__PURE__ */ jsx(DropdownMenuSeparator, {}),
                      [
                        "all",
                        "draft",
                        "sent",
                        "paid",
                        "overdue",
                        "void"
                      ].map((s) => /* @__PURE__ */ jsx(
                        DropdownMenuItem,
                        {
                          onClick: () => setStatus(s),
                          className: "rounded-lg",
                          children: s === "all" ? "All" : s
                        },
                        s
                      ))
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs(DropdownMenu, { children: [
                /* @__PURE__ */ jsx(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(
                  Button,
                  {
                    variant: "outline",
                    className: "gap-2 rounded-xl",
                    children: [
                      /* @__PURE__ */ jsx(Calendar, { className: "h-4 w-4" }),
                      "Sort"
                    ]
                  }
                ) }),
                /* @__PURE__ */ jsxs(
                  DropdownMenuContent,
                  {
                    align: "end",
                    className: "w-56 rounded-xl",
                    children: [
                      /* @__PURE__ */ jsx(DropdownMenuLabel, { className: "text-xs text-muted-foreground", children: "Sort invoices" }),
                      /* @__PURE__ */ jsx(DropdownMenuSeparator, {}),
                      /* @__PURE__ */ jsx(
                        DropdownMenuItem,
                        {
                          onClick: () => setSort("newest"),
                          className: "rounded-lg",
                          children: "Newest first"
                        }
                      ),
                      /* @__PURE__ */ jsx(
                        DropdownMenuItem,
                        {
                          onClick: () => setSort("oldest"),
                          className: "rounded-lg",
                          children: "Oldest first"
                        }
                      ),
                      /* @__PURE__ */ jsx(DropdownMenuSeparator, {}),
                      /* @__PURE__ */ jsx(
                        DropdownMenuItem,
                        {
                          onClick: () => setSort("amount_desc"),
                          className: "rounded-lg",
                          children: "Amount (high → low)"
                        }
                      ),
                      /* @__PURE__ */ jsx(
                        DropdownMenuItem,
                        {
                          onClick: () => setSort("amount_asc"),
                          className: "rounded-lg",
                          children: "Amount (low → high)"
                        }
                      )
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs(
                Button,
                {
                  variant: "ghost",
                  onClick: resetFilters,
                  className: "gap-2 rounded-xl",
                  children: [
                    /* @__PURE__ */ jsx(RefreshCw, { className: "h-4 w-4" }),
                    "Reset"
                  ]
                }
              )
            ] })
          ] }) }),
          /* @__PURE__ */ jsx(Card, { className: "mt-4 overflow-hidden rounded-2xl border bg-background shadow-sm", children: /* @__PURE__ */ jsx("div", { className: "w-full overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "min-w-full", children: [
            /* @__PURE__ */ jsx("thead", { className: "bg-muted/40", children: /* @__PURE__ */ jsxs("tr", { className: "text-left text-xs text-muted-foreground", children: [
              /* @__PURE__ */ jsx("th", { className: "px-6 py-3 font-semibold", children: "Invoice" }),
              /* @__PURE__ */ jsx("th", { className: "px-6 py-3 font-semibold", children: "Amount" }),
              /* @__PURE__ */ jsx("th", { className: "px-6 py-3 font-semibold", children: "Status" }),
              /* @__PURE__ */ jsx("th", { className: "px-6 py-3 font-semibold", children: "Created" }),
              /* @__PURE__ */ jsx("th", { className: "px-6 py-3 text-right font-semibold", children: "Action" })
            ] }) }),
            /* @__PURE__ */ jsx("tbody", { className: "divide-y", children: /* @__PURE__ */ jsx(AnimatePresence, { mode: "popLayout", children: filtered.length === 0 ? /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx(
              "td",
              {
                colSpan: 5,
                className: "px-6 py-14 text-center",
                children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-sm", children: [
                  /* @__PURE__ */ jsx("div", { className: "mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(FileText, { className: "h-6 w-6 text-foreground/70" }) }),
                  /* @__PURE__ */ jsx("div", { className: "text-sm font-medium", children: "No invoices found" }),
                  /* @__PURE__ */ jsx("div", { className: "mt-1 text-sm text-muted-foreground", children: "Try changing your filters or create your first invoice." }),
                  /* @__PURE__ */ jsx("div", { className: "mt-4", children: /* @__PURE__ */ jsx(
                    Button,
                    {
                      asChild: true,
                      className: "rounded-xl",
                      children: /* @__PURE__ */ jsxs(Link, { href: "/invoices/create", children: [
                        /* @__PURE__ */ jsx(Plus, { className: "mr-2 h-4 w-4" }),
                        "Add invoice"
                      ] })
                    }
                  ) })
                ] })
              }
            ) }) : filtered.map((invoice, i) => {
              const StatusIcon = statusIcon(
                invoice.status
              );
              const money = formatMoney(
                Number(invoice.total ?? 0),
                {
                  code: invoice.currency_code ?? activeCurrency?.code ?? null,
                  symbol: activeCurrency?.symbol ?? null,
                  precision: activeCurrency?.precision ?? 2
                }
              );
              return /* @__PURE__ */ jsxs(
                motion.tr,
                {
                  initial: {
                    opacity: 0,
                    y: 8
                  },
                  animate: {
                    opacity: 1,
                    y: 0
                  },
                  exit: { opacity: 0, y: 8 },
                  transition: {
                    duration: 0.18,
                    delay: Math.min(
                      i * 0.02,
                      0.14
                    )
                  },
                  className: "group",
                  children: [
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
                      /* @__PURE__ */ jsx("div", { className: "grid h-9 w-9 place-items-center rounded-xl bg-muted/60", children: /* @__PURE__ */ jsx(StatusIcon, { className: "h-4 w-4 opacity-80" }) }),
                      /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
                        /* @__PURE__ */ jsx("div", { className: "truncate text-sm font-semibold", children: invoice.number ?? `Invoice #${invoice.id}` }),
                        /* @__PURE__ */ jsxs("div", { className: "truncate text-xs text-muted-foreground", children: [
                          invoice.client_name ?? "Client",
                          " ",
                          "•",
                          " ",
                          invoice.currency_code ?? activeCurrency?.code ?? "—"
                        ] })
                      ] })
                    ] }) }),
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: money }) }),
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsxs(
                      Badge,
                      {
                        variant: statusBadgeVariant(
                          invoice.status
                        ),
                        className: cn(
                          "rounded-xl capitalize",
                          invoice.status === "overdue" && "gap-1"
                        ),
                        children: [
                          invoice.status,
                          String(
                            invoice.status
                          ).toLowerCase() === "overdue" && /* @__PURE__ */ jsx(AlertTriangle, { className: "ml-1 h-3.5 w-3.5" })
                        ]
                      }
                    ) }),
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-4 text-sm text-muted-foreground", children: new Date(
                      invoice.created_at
                    ).toLocaleDateString() }),
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-4 text-right", children: /* @__PURE__ */ jsx(
                      Button,
                      {
                        variant: "outline",
                        size: "sm",
                        className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                        asChild: true,
                        children: /* @__PURE__ */ jsxs(
                          Link,
                          {
                            href: `/invoices/${invoice.id}`,
                            children: [
                              "View",
                              /* @__PURE__ */ jsx(ArrowUpRight, { className: "ml-2 h-4 w-4 opacity-80" })
                            ]
                          }
                        )
                      }
                    ) })
                  ]
                },
                invoice.id
              );
            }) }) })
          ] }) }) })
        ]
      }
    )
  ] });
}
function StatCard({
  title,
  value,
  icon: Icon
}) {
  return /* @__PURE__ */ jsx(
    motion.div,
    {
      initial: { opacity: 0, y: 10 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.22, ease: "easeOut" },
      children: /* @__PURE__ */ jsx(Card, { className: "rounded-2xl border bg-background p-4 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsx("div", { className: "grid h-10 w-10 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(Icon, { className: "h-5 w-5 text-foreground/80" }) }),
        /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: title }),
          /* @__PURE__ */ jsx("div", { className: "truncate text-lg font-semibold", children: value })
        ] })
      ] }) })
    }
  );
}
export {
  InvoicesIndex as default
};
