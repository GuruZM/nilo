import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { A as AppLayout } from "./app-layout-JvxHjkrs.js";
import { Head, Link, router, useForm } from "@inertiajs/react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, Building2, Plus, X, Loader2, Image, Pencil, Trash2, UploadCloud } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";
import { B as Badge } from "./badge-CfxidL8Q.js";
import { B as Button, c as cn } from "./button-DMGEFYrU.js";
import { C as Card } from "./card-MypPWj87.js";
import { D as Dialog, a as DialogTrigger, b as DialogContent, c as DialogHeader, d as DialogTitle, e as DialogDescription } from "./dialog-Md5slGnn.js";
import { I as Input } from "./input-nVyaPHpJ.js";
import { L as Label } from "./label-BjflLCFy.js";
import { S as Separator } from "./separator-Bcia5PKZ.js";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell } from "./table-CSQbiUuL.js";
import "./Chatbot-yoo4250k.js";
import "./app-sidebar-layout-BGzXXcN9.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
import "@radix-ui/react-separator";
const breadcrumbs = [
  { title: "Companies", href: "/companies" }
];
const getCsrfHeaders = () => {
  const token = document.querySelector('meta[name="csrf-token"]')?.content;
  if (!token) {
    return {};
  }
  return {
    "X-CSRF-TOKEN": token
  };
};
function CompaniesIndex({
  companies,
  active_company_id
}) {
  const activeCompany = React.useMemo(
    () => companies.find((c) => c.id === active_company_id) || null,
    [companies, active_company_id]
  );
  const money = (n) => {
    const v = Number(n ?? 0);
    return `ZMW ${Number.isFinite(v) ? v.toFixed(2) : "0.00"}`;
  };
  const allTotals = React.useMemo(() => {
    const paid = companies.reduce(
      (a, c) => a + Number(c.paid_revenue ?? 0),
      0
    );
    const pending = companies.reduce(
      (a, c) => a + Number(c.pending_revenue ?? 0),
      0
    );
    const clients = companies.reduce(
      (a, c) => a + Number(c.clients_count ?? 0),
      0
    );
    const invoices = companies.reduce(
      (a, c) => a + Number(c.total_invoices ?? 0),
      0
    );
    return { paid, pending, clients, invoices };
  }, [companies]);
  const activeTotals = React.useMemo(() => {
    const c = activeCompany;
    return {
      paid: Number(c?.paid_revenue ?? 0),
      pending: Number(c?.pending_revenue ?? 0),
      clients: Number(c?.clients_count ?? 0),
      invoices: Number(c?.total_invoices ?? 0)
    };
  }, [activeCompany]);
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Companies" }),
    /* @__PURE__ */ jsxs("div", { className: "mx-auto w-full px-4 py-10 sm:px-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between", children: [
        /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsx(
            motion.h1,
            {
              initial: { opacity: 0, y: 8 },
              animate: { opacity: 1, y: 0 },
              transition: { duration: 0.35, ease: "easeOut" },
              className: "text-2xl font-semibold tracking-tight sm:text-3xl",
              children: "Companies"
            }
          ),
          /* @__PURE__ */ jsx(
            motion.p,
            {
              initial: { opacity: 0, y: 8 },
              animate: { opacity: 1, y: 0 },
              transition: {
                duration: 0.35,
                delay: 0.05,
                ease: "easeOut"
              },
              className: "mt-1 text-sm text-muted-foreground",
              children: "Manage businesses on your account. Upload a logo, brand color, and switch active company anytime."
            }
          ),
          activeCompany ? /* @__PURE__ */ jsx("div", { className: "mt-3 flex items-center gap-2", children: /* @__PURE__ */ jsxs(Badge, { variant: "secondary", className: "gap-1", children: [
            /* @__PURE__ */ jsx(CheckCircle2, { className: "h-3.5 w-3.5" }),
            "Active:",
            " ",
            /* @__PURE__ */ jsx("span", { className: "font-medium", children: activeCompany.name })
          ] }) }) : /* @__PURE__ */ jsx("div", { className: "mt-3 text-sm text-muted-foreground", children: "No active company selected." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsx(
            Button,
            {
              asChild: true,
              variant: "outline",
              className: "h-9 rounded-xl",
              children: /* @__PURE__ */ jsx(Link, { href: "/dashboard", children: "Back to dashboard" })
            }
          ),
          /* @__PURE__ */ jsx(AddCompanyModal, {})
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-6 grid grid-cols-1 gap-4 md:grid-cols-3", children: [
        /* @__PURE__ */ jsx(
          SummaryStat,
          {
            title: activeCompany ? `Paid revenue • ${activeCompany.name}` : "Paid revenue",
            value: money(activeTotals.paid),
            tone: "emerald",
            sub: activeCompany ? `All companies: ${money(allTotals.paid)}` : void 0
          }
        ),
        /* @__PURE__ */ jsx(
          SummaryStat,
          {
            title: activeCompany ? `Pending revenue • ${activeCompany.name}` : "Pending revenue",
            value: money(activeTotals.pending),
            tone: "amber",
            sub: activeCompany ? `All companies: ${money(allTotals.pending)}` : void 0
          }
        ),
        /* @__PURE__ */ jsx(
          SummaryStat,
          {
            title: activeCompany ? `Clients • ${activeCompany.name}` : "Clients",
            value: `${activeTotals.clients}`,
            tone: "slate",
            sub: activeCompany ? `Invoices: ${activeTotals.invoices} • All companies: ${allTotals.clients} clients` : `All companies: ${allTotals.clients} clients • ${allTotals.invoices} invoices`
          }
        )
      ] }),
      /* @__PURE__ */ jsx(Separator, { className: "mb-6" }),
      /* @__PURE__ */ jsxs(Card, { className: "overflow-hidden rounded-2xl border bg-background shadow-sm", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3 px-5 py-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("div", { className: "grid h-9 w-9 place-items-center rounded-xl bg-muted", children: /* @__PURE__ */ jsx(Building2, { className: "h-5 w-5 text-foreground/80" }) }),
            /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Your companies" }),
              /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground", children: [
                companies.length,
                " total"
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsx(
            Button,
            {
              asChild: true,
              variant: "secondary",
              className: "hidden h-9 rounded-xl sm:inline-flex",
              children: /* @__PURE__ */ jsx(Link, { href: "/companies", children: "Refresh" })
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "w-full overflow-x-auto", children: /* @__PURE__ */ jsxs(Table, { children: [
          /* @__PURE__ */ jsx(TableHeader, { children: /* @__PURE__ */ jsxs(TableRow, { children: [
            /* @__PURE__ */ jsx(TableHead, { className: "min-w-[340px]", children: "Company" }),
            /* @__PURE__ */ jsx(TableHead, { className: "min-w-[130px]", children: "Clients" }),
            /* @__PURE__ */ jsx(TableHead, { className: "min-w-[170px]", children: "Paid revenue" }),
            /* @__PURE__ */ jsx(TableHead, { className: "min-w-[170px]", children: "Pending revenue" }),
            /* @__PURE__ */ jsx(TableHead, { className: "min-w-[120px]", children: "Status" }),
            /* @__PURE__ */ jsx(TableHead, { className: "min-w-[280px] text-right", children: "Actions" })
          ] }) }),
          /* @__PURE__ */ jsx(TableBody, { children: companies.length === 0 ? /* @__PURE__ */ jsx(TableRow, { children: /* @__PURE__ */ jsx(
            TableCell,
            {
              colSpan: 6,
              className: "py-14 text-center",
              children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-sm", children: [
                /* @__PURE__ */ jsx("div", { className: "mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(Building2, { className: "h-6 w-6 text-foreground/70" }) }),
                /* @__PURE__ */ jsx("div", { className: "text-sm font-medium", children: "No companies yet" }),
                /* @__PURE__ */ jsx("div", { className: "mt-1 text-sm text-muted-foreground", children: "Create your first company to start issuing invoices and tracking revenue." }),
                /* @__PURE__ */ jsx("div", { className: "mt-4", children: /* @__PURE__ */ jsx(AddCompanyModal, { triggerVariant: "outline" }) })
              ] })
            }
          ) }) : companies.map((company, index) => {
            const isActive = company.id === active_company_id;
            const logoUrl = company.logo_url ?? null;
            return /* @__PURE__ */ jsxs(
              motion.tr,
              {
                initial: { opacity: 0, y: 10 },
                animate: { opacity: 1, y: 0 },
                transition: {
                  duration: 0.25,
                  delay: Math.min(
                    0.03 * index,
                    0.18
                  )
                },
                className: cn(
                  "group",
                  isActive && "bg-muted/60"
                ),
                children: [
                  /* @__PURE__ */ jsx(TableCell, { className: "py-4", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsx(
                      "div",
                      {
                        className: cn(
                          "grid h-11 w-11 place-items-center overflow-hidden rounded-2xl border bg-background",
                          isActive && "border-primary/30 bg-primary/5"
                        ),
                        children: logoUrl ? /* @__PURE__ */ jsx(
                          "img",
                          {
                            src: logoUrl,
                            className: "h-full w-full object-cover",
                            alt: `${company.name} logo`
                          }
                        ) : /* @__PURE__ */ jsx(
                          Building2,
                          {
                            className: cn(
                              "h-5 w-5 text-foreground/70",
                              isActive && "text-primary"
                            )
                          }
                        )
                      }
                    ),
                    /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsx("div", { className: "truncate text-sm font-semibold", children: company.name }),
                      /* @__PURE__ */ jsxs("div", { className: "mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground", children: [
                        /* @__PURE__ */ jsxs("span", { children: [
                          "ID:",
                          " ",
                          company.id
                        ] }),
                        company.primary_color ? /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 rounded-full border bg-background px-2 py-0.5", children: [
                          /* @__PURE__ */ jsx(
                            "span",
                            {
                              className: "h-2.5 w-2.5 rounded-full",
                              style: {
                                backgroundColor: company.primary_color ?? void 0
                              }
                            }
                          ),
                          company.primary_color
                        ] }) : null
                      ] })
                    ] })
                  ] }) }),
                  /* @__PURE__ */ jsxs(TableCell, { className: "py-4", children: [
                    /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: company.clients_count ?? 0 }),
                    /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground", children: [
                      company.total_invoices ?? 0,
                      " ",
                      "invoices"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs(TableCell, { className: "py-4", children: [
                    /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold text-emerald-700", children: money(
                      company.paid_revenue
                    ) }),
                    /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Collected" })
                  ] }),
                  /* @__PURE__ */ jsxs(TableCell, { className: "py-4", children: [
                    /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold text-amber-700", children: money(
                      company.pending_revenue
                    ) }),
                    /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Outstanding" })
                  ] }),
                  /* @__PURE__ */ jsx(TableCell, { className: "py-4", children: isActive ? /* @__PURE__ */ jsxs(
                    Badge,
                    {
                      className: "gap-1",
                      variant: "default",
                      children: [
                        /* @__PURE__ */ jsx(CheckCircle2, { className: "h-3.5 w-3.5" }),
                        "Active"
                      ]
                    }
                  ) : /* @__PURE__ */ jsx(Badge, { variant: "secondary", children: "Inactive" }) }),
                  /* @__PURE__ */ jsx(TableCell, { className: "py-4 text-right", children: /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-2", children: [
                    /* @__PURE__ */ jsx(
                      EditCompanyModal,
                      {
                        company
                      }
                    ),
                    isActive ? /* @__PURE__ */ jsx(
                      Button,
                      {
                        variant: "secondary",
                        size: "sm",
                        disabled: true,
                        className: "h-9 rounded-xl",
                        children: "Current"
                      }
                    ) : /* @__PURE__ */ jsx(
                      Button,
                      {
                        variant: "outline",
                        size: "sm",
                        className: "h-9 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                        onClick: () => {
                          router.post(
                            "/companies/switch",
                            {
                              company_id: company.id
                            },
                            {
                              preserveScroll: true,
                              onSuccess: () => toast.success(
                                "Company switched."
                              ),
                              onError: (errors) => {
                                const msg = errors?.company_id || "Failed to switch company.";
                                toast.error(
                                  msg
                                );
                              }
                            }
                          );
                        },
                        children: "Set active"
                      }
                    )
                  ] }) })
                ]
              },
              company.id
            );
          }) })
        ] }) })
      ] })
    ] })
  ] });
}
function SummaryStat({
  title,
  value,
  tone,
  sub
}) {
  const toneCls = tone === "emerald" ? "bg-emerald-500/10 text-emerald-700" : tone === "amber" ? "bg-amber-500/10 text-amber-700" : "bg-slate-500/10 text-slate-700";
  const Icon = tone === "emerald" ? CheckCircle2 : tone === "amber" ? Image : Building2;
  return /* @__PURE__ */ jsx(Card, { className: "rounded-2xl border bg-background p-5 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
    /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
      /* @__PURE__ */ jsx("div", { className: "text-xs font-semibold text-muted-foreground", children: title }),
      /* @__PURE__ */ jsx("div", { className: "mt-1 truncate text-2xl font-semibold tracking-tight", children: value }),
      sub ? /* @__PURE__ */ jsx("div", { className: "mt-1 text-xs text-muted-foreground", children: sub }) : null
    ] }),
    /* @__PURE__ */ jsx(
      "div",
      {
        className: cn(
          "grid h-10 w-10 place-items-center rounded-2xl",
          toneCls
        ),
        children: /* @__PURE__ */ jsx(Icon, { className: "h-5 w-5" })
      }
    )
  ] }) });
}
function LogoUpload({
  label = "Logo",
  value,
  existingUrl,
  onChange,
  onClear,
  hint = "PNG/JPG/WebP/SVG • Recommended: square image"
}) {
  const inputRef = React.useRef(null);
  const [preview, setPreview] = React.useState(null);
  const [isOver, setIsOver] = React.useState(false);
  React.useEffect(() => {
    if (!value) {
      setPreview(null);
      return;
    }
    const url = URL.createObjectURL(value);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [value]);
  const shown = preview || existingUrl || null;
  const pick = () => inputRef.current?.click();
  const onDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsOver(false);
    const f = e.dataTransfer.files?.[0];
    if (f) onChange(f);
  };
  return /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
    /* @__PURE__ */ jsxs(Label, { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx(Image, { className: "h-4 w-4" }),
      label
    ] }),
    /* @__PURE__ */ jsxs(
      "button",
      {
        type: "button",
        className: cn(
          "group flex w-full items-center gap-4 rounded-2xl border bg-muted/20 p-4 text-left transition",
          "hover:bg-muted/30",
          isOver && "ring-2 ring-primary/30"
        ),
        onClick: pick,
        onDragEnter: (e) => {
          e.preventDefault();
          setIsOver(true);
        },
        onDragOver: (e) => {
          e.preventDefault();
          setIsOver(true);
        },
        onDragLeave: (e) => {
          e.preventDefault();
          setIsOver(false);
        },
        onDrop,
        children: [
          /* @__PURE__ */ jsx("div", { className: "grid h-14 w-14 place-items-center overflow-hidden rounded-2xl border bg-background", children: shown ? /* @__PURE__ */ jsx(
            "img",
            {
              src: shown,
              alt: "logo preview",
              className: "h-full w-full object-cover"
            }
          ) : /* @__PURE__ */ jsx(UploadCloud, { className: "h-6 w-6 text-foreground/70" }) }),
          /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1", children: [
            /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: value ? value.name : shown ? "Current logo (click to replace)" : "Upload company logo" }),
            /* @__PURE__ */ jsx("div", { className: "mt-1 text-xs text-muted-foreground", children: isOver ? "Drop image to upload" : hint })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2", children: value || shown ? /* @__PURE__ */ jsx(
            Button,
            {
              type: "button",
              variant: "secondary",
              size: "sm",
              className: "h-9 rounded-xl",
              onClick: (e) => {
                e.stopPropagation();
                if (onClear) {
                  onClear();
                  return;
                }
                onChange(null);
              },
              children: "Remove"
            }
          ) : /* @__PURE__ */ jsx(
            Button,
            {
              type: "button",
              variant: "secondary",
              size: "sm",
              className: "h-9 rounded-xl",
              onClick: (e) => {
                e.stopPropagation();
                pick();
              },
              children: "Browse"
            }
          ) })
        ]
      }
    ),
    /* @__PURE__ */ jsx(
      "input",
      {
        ref: inputRef,
        type: "file",
        className: "hidden",
        accept: ".jpg,.jpeg,.png,.webp,.svg",
        onChange: (e) => onChange(e.target.files?.[0] ?? null)
      }
    )
  ] });
}
function AddCompanyModal({ triggerVariant = "default" }) {
  const [open, setOpen] = React.useState(false);
  const form = useForm({
    name: "",
    email: "",
    phone: "",
    tpin: "",
    address: "",
    primary_color: "",
    logo: null
  });
  const closeAndReset = () => {
    setOpen(false);
    form.reset();
    form.clearErrors();
  };
  const submit = (e) => {
    e.preventDefault();
    const toastId = toast.loading("Creating company...");
    form.post("/companies", {
      preserveScroll: true,
      forceFormData: true,
      // ✅ for logo upload
      headers: getCsrfHeaders(),
      onSuccess: () => {
        toast.success("Company created successfully.", { id: toastId });
        closeAndReset();
      },
      onError: (errors) => {
        const firstError = errors?.name || errors?.email || errors?.phone || errors?.tpin || errors?.address || errors?.primary_color || errors?.logo;
        toast.error(firstError ?? "Failed to create company.", {
          id: toastId
        });
      }
    });
  };
  return /* @__PURE__ */ jsxs(
    Dialog,
    {
      open,
      onOpenChange: (v) => v ? setOpen(true) : closeAndReset(),
      children: [
        /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(
          Button,
          {
            variant: triggerVariant,
            className: "h-9 gap-2 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
            children: [
              /* @__PURE__ */ jsx(Plus, { className: "h-4 w-4" }),
              "Add company"
            ]
          }
        ) }),
        /* @__PURE__ */ jsx(DialogContent, { className: "overflow-hidden rounded-2xl p-0 sm:max-w-lg", children: /* @__PURE__ */ jsx(AnimatePresence, { mode: "wait", children: /* @__PURE__ */ jsx(
          motion.div,
          {
            initial: { opacity: 0, y: 14, scale: 0.99 },
            animate: { opacity: 1, y: 0, scale: 1 },
            exit: { opacity: 0, y: 10, scale: 0.99 },
            transition: { duration: 0.22, ease: "easeOut" },
            children: /* @__PURE__ */ jsxs("div", { className: "px-6 pt-6 pb-5", children: [
              /* @__PURE__ */ jsxs(DialogHeader, { children: [
                /* @__PURE__ */ jsxs(DialogTitle, { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx("span", { className: "grid h-9 w-9 place-items-center rounded-xl bg-muted", children: /* @__PURE__ */ jsx(Building2, { className: "h-5 w-5 text-foreground/80" }) }),
                  "Create company"
                ] }),
                /* @__PURE__ */ jsx(DialogDescription, { children: "Add a company and upload a logo to make it feel branded from day one." })
              ] }),
              /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "mt-6 space-y-4", children: [
                /* @__PURE__ */ jsx(
                  LogoUpload,
                  {
                    label: "Company logo (optional)",
                    value: form.data.logo,
                    onChange: (f) => form.setData("logo", f),
                    onClear: () => form.setData("logo", null)
                  }
                ),
                form.errors.logo ? /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.logo }) : null,
                /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsx(Label, { htmlFor: "company_name", children: "Company name *" }),
                  /* @__PURE__ */ jsx(
                    Input,
                    {
                      id: "company_name",
                      placeholder: "e.g. Resonant Technologies",
                      value: form.data.name,
                      onChange: (e) => form.setData("name", e.target.value),
                      autoFocus: true,
                      required: true
                    }
                  ),
                  form.errors.name ? /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.name }) : null
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsx(Label, { children: "Email (optional)" }),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        type: "email",
                        placeholder: "billing@company.com",
                        value: form.data.email ?? "",
                        onChange: (e) => form.setData(
                          "email",
                          e.target.value
                        )
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsx(Label, { children: "Phone (optional)" }),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        placeholder: "+260...",
                        value: form.data.phone ?? "",
                        onChange: (e) => form.setData(
                          "phone",
                          e.target.value
                        )
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsx(Label, { children: "TPIN (optional)" }),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        placeholder: "e.g. 100XXXXXXX",
                        value: form.data.tpin ?? "",
                        onChange: (e) => form.setData(
                          "tpin",
                          e.target.value
                        )
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsx(Label, { children: "Primary color (optional)" }),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        placeholder: "#00417d",
                        value: form.data.primary_color ?? "",
                        onChange: (e) => form.setData(
                          "primary_color",
                          e.target.value
                        )
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2 sm:col-span-2", children: [
                    /* @__PURE__ */ jsx(Label, { children: "Address (optional)" }),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        placeholder: "Lusaka, Zambia",
                        value: form.data.address ?? "",
                        onChange: (e) => form.setData(
                          "address",
                          e.target.value
                        )
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsx(Separator, { className: "my-4" }),
                /* @__PURE__ */ jsxs("div", { className: "flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-end", children: [
                  /* @__PURE__ */ jsxs(
                    Button,
                    {
                      type: "button",
                      variant: "ghost",
                      onClick: closeAndReset,
                      disabled: form.processing,
                      className: "h-9 rounded-xl",
                      children: [
                        /* @__PURE__ */ jsx(X, { className: "mr-2 h-4 w-4" }),
                        "Cancel"
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    Button,
                    {
                      type: "submit",
                      disabled: form.processing || !form.data.name.trim(),
                      className: "h-9 rounded-xl",
                      children: form.processing ? /* @__PURE__ */ jsxs(Fragment, { children: [
                        /* @__PURE__ */ jsx(Loader2, { className: "mr-2 h-4 w-4 animate-spin" }),
                        "Creating..."
                      ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
                        /* @__PURE__ */ jsx(Plus, { className: "mr-2 h-4 w-4" }),
                        "Create company"
                      ] })
                    }
                  )
                ] })
              ] })
            ] })
          },
          open ? "open" : "closed"
        ) }) })
      ]
    }
  );
}
function EditCompanyModal({ company }) {
  const [open, setOpen] = React.useState(false);
  const form = useForm({
    name: "",
    email: "",
    phone: "",
    tpin: "",
    address: "",
    primary_color: "",
    logo: null,
    remove_logo: false
  });
  React.useEffect(() => {
    if (!open) return;
    form.setData({
      name: company.name ?? "",
      email: company.email ?? "",
      phone: company.phone ?? "",
      tpin: company.tpin ?? "",
      address: company.address ?? "",
      primary_color: company.primary_color ?? "",
      logo: null,
      remove_logo: false
    });
    form.clearErrors();
  }, [open, company.id]);
  const existingLogoUrl = company.logo_url ?? null;
  const showExistingLogo = !form.data.remove_logo;
  const submit = (e) => {
    e.preventDefault();
    const toastId = toast.loading("Updating company...");
    router.post(
      `/companies/${company.id}`,
      {
        _method: "PUT",
        // ✅ spoof PUT
        name: form.data.name,
        email: form.data.email ?? "",
        phone: form.data.phone ?? "",
        tpin: form.data.tpin ?? "",
        address: form.data.address ?? "",
        primary_color: form.data.primary_color ?? "",
        logo: form.data.logo,
        // ✅ File | null
        remove_logo: form.data.remove_logo ? 1 : 0
      },
      {
        preserveScroll: true,
        forceFormData: true,
        // ✅ converts payload to FormData
        headers: getCsrfHeaders(),
        onSuccess: () => {
          toast.success("Company updated.", { id: toastId });
          setOpen(false);
        },
        onError: (errors) => {
          const first = errors?.name || errors?.email || errors?.phone || errors?.tpin || errors?.address || errors?.primary_color || errors?.logo || errors?.company;
          toast.error(first ?? "Failed to update company.", {
            id: toastId
          });
        }
      }
    );
  };
  return /* @__PURE__ */ jsxs(Dialog, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(
      Button,
      {
        variant: "secondary",
        size: "sm",
        className: "h-9 gap-2 rounded-xl",
        children: [
          /* @__PURE__ */ jsx(Pencil, { className: "h-4 w-4" }),
          "Edit"
        ]
      }
    ) }),
    /* @__PURE__ */ jsx(DialogContent, { className: "overflow-hidden rounded-2xl p-0 sm:max-w-lg", children: /* @__PURE__ */ jsxs("div", { className: "px-6 pt-6 pb-5", children: [
      /* @__PURE__ */ jsxs(DialogHeader, { children: [
        /* @__PURE__ */ jsxs(DialogTitle, { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx("span", { className: "grid h-9 w-9 place-items-center overflow-hidden rounded-xl bg-muted", children: existingLogoUrl ? /* @__PURE__ */ jsx(
            "img",
            {
              src: existingLogoUrl,
              alt: "logo",
              className: "h-full w-full object-cover"
            }
          ) : /* @__PURE__ */ jsx(Building2, { className: "h-5 w-5 text-foreground/80" }) }),
          "Edit company"
        ] }),
        /* @__PURE__ */ jsxs(DialogDescription, { children: [
          "Update details and logo. Logo is stored in",
          " ",
          /* @__PURE__ */ jsx("span", { className: "font-medium", children: "logo_path" }),
          "."
        ] })
      ] }),
      /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "mt-6 space-y-4", children: [
        /* @__PURE__ */ jsx(
          LogoUpload,
          {
            label: "Company logo",
            value: form.data.logo,
            existingUrl: showExistingLogo ? existingLogoUrl : null,
            onChange: (f) => {
              form.setData("logo", f);
              if (f) form.setData("remove_logo", false);
            },
            onClear: () => {
              if (form.data.logo) {
                form.setData("logo", null);
                return;
              }
              if (existingLogoUrl) {
                form.setData("remove_logo", true);
              }
            }
          }
        ),
        existingLogoUrl ? /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-xs text-muted-foreground", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "checkbox",
              checked: form.data.remove_logo,
              onChange: (e) => form.setData(
                "remove_logo",
                e.target.checked
              )
            }
          ),
          /* @__PURE__ */ jsx(Trash2, { className: "h-3.5 w-3.5" }),
          "Remove current logo"
        ] }) : null,
        form.errors.logo ? /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.logo }) : null,
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Company name *" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              value: form.data.name,
              onChange: (e) => form.setData("name", e.target.value),
              required: true
            }
          ),
          form.errors.name ? /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.name }) : null
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx(Label, { children: "Email" }),
            /* @__PURE__ */ jsx(
              Input,
              {
                type: "email",
                value: form.data.email ?? "",
                onChange: (e) => form.setData("email", e.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx(Label, { children: "Phone" }),
            /* @__PURE__ */ jsx(
              Input,
              {
                value: form.data.phone ?? "",
                onChange: (e) => form.setData("phone", e.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx(Label, { children: "TPIN" }),
            /* @__PURE__ */ jsx(
              Input,
              {
                value: form.data.tpin ?? "",
                onChange: (e) => form.setData("tpin", e.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx(Label, { children: "Primary color" }),
            /* @__PURE__ */ jsx(
              Input,
              {
                placeholder: "#00417d",
                value: form.data.primary_color ?? "",
                onChange: (e) => form.setData(
                  "primary_color",
                  e.target.value
                )
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2 sm:col-span-2", children: [
            /* @__PURE__ */ jsx(Label, { children: "Address" }),
            /* @__PURE__ */ jsx(
              Input,
              {
                value: form.data.address ?? "",
                onChange: (e) => form.setData("address", e.target.value)
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsx(Separator, { className: "my-4" }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-end", children: [
          /* @__PURE__ */ jsxs(
            Button,
            {
              type: "button",
              variant: "ghost",
              onClick: () => setOpen(false),
              disabled: form.processing,
              className: "h-9 rounded-xl",
              children: [
                /* @__PURE__ */ jsx(X, { className: "mr-2 h-4 w-4" }),
                "Cancel"
              ]
            }
          ),
          /* @__PURE__ */ jsx(
            Button,
            {
              type: "submit",
              disabled: form.processing || !form.data.name.trim(),
              className: "h-9 rounded-xl",
              children: form.processing ? /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsx(Loader2, { className: "mr-2 h-4 w-4 animate-spin" }),
                "Saving..."
              ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsx(CheckCircle2, { className: "mr-2 h-4 w-4" }),
                "Save changes"
              ] })
            }
          )
        ] })
      ] })
    ] }) })
  ] });
}
export {
  CompaniesIndex as default
};
