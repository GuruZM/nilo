import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { A as AppLayout } from "./app-layout-JvxHjkrs.js";
import { Head, useForm, router } from "@inertiajs/react";
import { motion, AnimatePresence } from "framer-motion";
import { Users, Search, Pencil, UserPlus, Contact, Mail, Phone, IdCard, MapPin, StickyNote, X, Loader2, Trash2 } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import { A as AlertDialog, a as AlertDialogTrigger, b as AlertDialogContent, c as AlertDialogHeader, d as AlertDialogTitle, e as AlertDialogDescription, f as AlertDialogFooter, g as AlertDialogCancel, h as AlertDialogAction } from "./alert-dialog-DSahW8tb.js";
import { B as Badge } from "./badge-CfxidL8Q.js";
import { B as Button, c as cn } from "./button-DMGEFYrU.js";
import { C as Card } from "./card-MypPWj87.js";
import { D as Dialog, a as DialogTrigger, b as DialogContent, c as DialogHeader, d as DialogTitle, e as DialogDescription } from "./dialog-Md5slGnn.js";
import { I as Input } from "./input-nVyaPHpJ.js";
import { L as Label } from "./label-BjflLCFy.js";
import { S as Separator } from "./separator-Bcia5PKZ.js";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell } from "./table-CSQbiUuL.js";
import { T as Textarea } from "./textarea-B2f7VE2B.js";
import "./Chatbot-yoo4250k.js";
import "./app-sidebar-layout-BGzXXcN9.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "@radix-ui/react-alert-dialog";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
import "@radix-ui/react-separator";
const breadcrumbs = [
  { title: "Clients", href: "/clients" }
];
const staggerRow = (i) => ({
  hidden: { opacity: 0, y: 10 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.22, delay: Math.min(i * 0.03, 0.18) }
  }
});
const fmtDate = (iso) => {
  try {
    return new Date(iso).toLocaleDateString();
  } catch {
    return iso;
  }
};
const ClientsIndex = ({ clients }) => {
  const [q, setQ] = useState("");
  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return clients;
    return clients.filter((c) => {
      const hay = [
        c.name,
        c.contact_person ?? "",
        c.email ?? "",
        c.phone ?? "",
        c.tpin ?? "",
        c.city ?? "",
        c.country ?? ""
      ].join(" ").toLowerCase();
      return hay.includes(needle);
    });
  }, [clients, q]);
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Clients" }),
    /* @__PURE__ */ jsxs(
      motion.div,
      {
        initial: "hidden",
        animate: "show",
        className: "mx-auto w-full px-4 py-10 sm:px-6",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "grid h-11 w-11 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(Users, { className: "h-6 w-6 text-foreground/80" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight sm:text-3xl", children: "Clients" }),
                  /* @__PURE__ */ jsx(
                    Badge,
                    {
                      variant: "secondary",
                      className: "hidden sm:inline-flex",
                      children: "One place. Full control."
                    }
                  )
                ] }),
                /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "Create and manage clients for your active company. Attach them to invoices and quotations." })
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsx(AddOrEditClientModal, { mode: "create" }) })
          ] }),
          /* @__PURE__ */ jsx(Separator, { className: "mb-6" }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-6 lg:grid-cols-12", children: [
            /* @__PURE__ */ jsxs(Card, { className: "overflow-hidden rounded-2xl border bg-background shadow-sm lg:col-span-8", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx("div", { className: "grid h-9 w-9 place-items-center rounded-xl bg-muted", children: /* @__PURE__ */ jsx(Users, { className: "h-5 w-5 text-foreground/80" }) }),
                  /* @__PURE__ */ jsxs("div", { children: [
                    /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Client list" }),
                    /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground", children: [
                      filtered.length,
                      " shown •",
                      " ",
                      clients.length,
                      " total"
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "relative w-full sm:w-80", children: [
                  /* @__PURE__ */ jsx(Search, { className: "pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
                  /* @__PURE__ */ jsx(
                    Input,
                    {
                      value: q,
                      onChange: (e) => setQ(e.target.value),
                      placeholder: "Search name, contact, email, phone, TPIN...",
                      className: "pl-9"
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "w-full overflow-x-auto", children: /* @__PURE__ */ jsxs(Table, { children: [
                /* @__PURE__ */ jsx(TableHeader, { children: /* @__PURE__ */ jsxs(TableRow, { children: [
                  /* @__PURE__ */ jsx(TableHead, { className: "w-[38%]", children: "Client" }),
                  /* @__PURE__ */ jsx(TableHead, { children: "Email" }),
                  /* @__PURE__ */ jsx(TableHead, { children: "Phone" }),
                  /* @__PURE__ */ jsx(TableHead, { className: "text-right", children: "Actions" })
                ] }) }),
                /* @__PURE__ */ jsx(TableBody, { children: filtered.length === 0 ? /* @__PURE__ */ jsx(TableRow, { children: /* @__PURE__ */ jsx(
                  TableCell,
                  {
                    colSpan: 4,
                    className: "py-14 text-center",
                    children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-sm", children: [
                      /* @__PURE__ */ jsx("div", { className: "mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(Users, { className: "h-6 w-6 text-foreground/70" }) }),
                      /* @__PURE__ */ jsx("div", { className: "text-sm font-medium", children: "No matching clients" }),
                      /* @__PURE__ */ jsx("div", { className: "mt-1 text-sm text-muted-foreground", children: "Try a different search, or add a new client." }),
                      /* @__PURE__ */ jsx("div", { className: "mt-4", children: /* @__PURE__ */ jsx(
                        AddOrEditClientModal,
                        {
                          mode: "create",
                          triggerVariant: "outline"
                        }
                      ) })
                    ] })
                  }
                ) }) : filtered.map((client, i) => /* @__PURE__ */ jsxs(
                  motion.tr,
                  {
                    variants: staggerRow(i),
                    initial: "hidden",
                    animate: "show",
                    className: "group",
                    children: [
                      /* @__PURE__ */ jsx(TableCell, { className: "py-4", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
                        /* @__PURE__ */ jsx("div", { className: "grid h-9 w-9 place-items-center rounded-xl border bg-background", children: /* @__PURE__ */ jsx(Users, { className: "h-4.5 w-4.5 text-foreground/70" }) }),
                        /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
                          /* @__PURE__ */ jsx("div", { className: "truncate text-sm font-semibold", children: client.name }),
                          client.contact_person ? /* @__PURE__ */ jsxs("div", { className: "mt-0.5 truncate text-xs text-muted-foreground", children: [
                            "Contact:",
                            " ",
                            client.contact_person
                          ] }) : /* @__PURE__ */ jsx("div", { className: "mt-0.5 text-xs text-muted-foreground/60", children: "Contact: —" }),
                          /* @__PURE__ */ jsxs("div", { className: "mt-0.5 text-xs text-muted-foreground", children: [
                            "Added:",
                            " ",
                            fmtDate(
                              client.created_at
                            )
                          ] })
                        ] })
                      ] }) }),
                      /* @__PURE__ */ jsx(TableCell, { className: "py-4", children: client.email ? /* @__PURE__ */ jsx("span", { className: "text-sm", children: client.email }) : /* @__PURE__ */ jsx("span", { className: "text-sm text-muted-foreground", children: "—" }) }),
                      /* @__PURE__ */ jsx(TableCell, { className: "py-4", children: client.phone ? /* @__PURE__ */ jsx("span", { className: "text-sm", children: client.phone }) : /* @__PURE__ */ jsx("span", { className: "text-sm text-muted-foreground", children: "—" }) }),
                      /* @__PURE__ */ jsx(TableCell, { className: "py-4 text-right", children: /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-2", children: [
                        /* @__PURE__ */ jsx(
                          AddOrEditClientModal,
                          {
                            mode: "edit",
                            client,
                            trigger: /* @__PURE__ */ jsxs(
                              Button,
                              {
                                variant: "outline",
                                size: "sm",
                                className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                                children: [
                                  /* @__PURE__ */ jsx(Pencil, { className: "mr-2 h-4 w-4" }),
                                  "Edit"
                                ]
                              }
                            )
                          }
                        ),
                        /* @__PURE__ */ jsx(
                          DeleteClientButton,
                          {
                            client
                          }
                        )
                      ] }) })
                    ]
                  },
                  client.id
                )) })
              ] }) })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-6 lg:col-span-4", children: [
              /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                  /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Quick stats" }),
                  /* @__PURE__ */ jsx(Badge, { variant: "outline", children: "Clients" })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "mt-4 grid grid-cols-2 gap-3", children: [
                  /* @__PURE__ */ jsxs("div", { className: "rounded-xl border bg-background p-4", children: [
                    /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Total" }),
                    /* @__PURE__ */ jsx("div", { className: "mt-1 text-2xl font-semibold", children: clients.length })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "rounded-xl border bg-background p-4", children: [
                    /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Shown" }),
                    /* @__PURE__ */ jsx("div", { className: "mt-1 text-2xl font-semibold", children: filtered.length })
                  ] })
                ] }),
                /* @__PURE__ */ jsx(Separator, { className: "my-5" }),
                /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Tips" }),
                /* @__PURE__ */ jsxs("ul", { className: "mt-3 space-y-2 text-sm text-muted-foreground", children: [
                  /* @__PURE__ */ jsx("li", { children: "• Add email to send invoices directly." }),
                  /* @__PURE__ */ jsx("li", { children: "• TPIN keeps your invoices clean & compliant." }),
                  /* @__PURE__ */ jsx("li", { children: "• Use notes for billing instructions." })
                ] })
              ] }),
              /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm", children: [
                /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Why contact person?" }),
                /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Makes follow-ups easy when you’re chasing approvals or payments. No more “who do I talk to?” moments 😄" })
              ] })
            ] })
          ] })
        ]
      }
    )
  ] });
};
function AddOrEditClientModal({
  mode,
  client,
  triggerVariant = "default",
  trigger
}) {
  const [open, setOpen] = useState(false);
  const form = useForm({
    name: client?.name ?? "",
    contact_person: client?.contact_person ?? "",
    email: client?.email ?? "",
    phone: client?.phone ?? "",
    tpin: client?.tpin ?? "",
    address: client?.address ?? "",
    city: client?.city ?? "",
    country: client?.country ?? "",
    notes: client?.notes ?? ""
  });
  const closeAndReset = () => {
    setOpen(false);
    form.clearErrors();
    if (mode === "create") form.reset();
  };
  const submit = (e) => {
    e.preventDefault();
    if (mode === "create") {
      form.post("/clients", {
        preserveScroll: true,
        onSuccess: () => {
          toast.success("Client created.");
          closeAndReset();
        },
        onError: (errors) => {
          toast.error(
            errors?.name || errors?.contact_person || errors?.email || errors?.phone || errors?.tpin || "Failed to create client."
          );
        }
      });
      return;
    }
    form.put(`/clients/${client.id}`, {
      preserveScroll: true,
      onSuccess: () => {
        toast.success("Client updated.");
        closeAndReset();
      },
      onError: (errors) => {
        toast.error(
          errors?.name || errors?.contact_person || errors?.email || errors?.phone || errors?.tpin || "Failed to update client."
        );
      }
    });
  };
  const Title = mode === "create" ? "Add client" : "Edit client";
  const Desc = mode === "create" ? "Create a client for the active company." : "Update client details.";
  return /* @__PURE__ */ jsxs(
    Dialog,
    {
      open,
      onOpenChange: (v) => v ? setOpen(true) : closeAndReset(),
      children: [
        /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: trigger ?? /* @__PURE__ */ jsxs(
          Button,
          {
            variant: triggerVariant,
            className: "gap-2 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
            children: [
              /* @__PURE__ */ jsx(UserPlus, { className: "h-4 w-4" }),
              "Add client"
            ]
          }
        ) }),
        /* @__PURE__ */ jsx(DialogContent, { className: "overflow-hidden rounded-2xl p-0 sm:max-w-2xl", children: /* @__PURE__ */ jsx(AnimatePresence, { mode: "wait", children: /* @__PURE__ */ jsx(
          motion.div,
          {
            initial: { opacity: 0, y: 14, scale: 0.99 },
            animate: { opacity: 1, y: 0, scale: 1 },
            exit: { opacity: 0, y: 10, scale: 0.99 },
            transition: { duration: 0.22, ease: "easeOut" },
            children: /* @__PURE__ */ jsxs("div", { className: "px-6 pt-6 pb-5", children: [
              /* @__PURE__ */ jsxs(DialogHeader, { children: [
                /* @__PURE__ */ jsxs(DialogTitle, { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx("span", { className: "grid h-9 w-9 place-items-center rounded-xl bg-muted", children: mode === "create" ? /* @__PURE__ */ jsx(UserPlus, { className: "h-5 w-5 text-foreground/80" }) : /* @__PURE__ */ jsx(Users, { className: "h-5 w-5 text-foreground/80" }) }),
                  Title
                ] }),
                /* @__PURE__ */ jsx(DialogDescription, { children: Desc })
              ] }),
              /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "mt-6 space-y-5", children: [
                /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsx(Label, { htmlFor: "name", children: "Client name *" }),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        id: "name",
                        placeholder: "e.g. Cozyhouse Interiors",
                        value: form.data.name,
                        onChange: (e) => form.setData(
                          "name",
                          e.target.value
                        ),
                        required: true
                      }
                    ),
                    form.errors.name && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.name })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsxs(
                      Label,
                      {
                        htmlFor: "contact_person",
                        className: "flex items-center gap-2",
                        children: [
                          /* @__PURE__ */ jsx(Contact, { className: "h-4 w-4 text-muted-foreground" }),
                          "Contact person"
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        id: "contact_person",
                        placeholder: "e.g. Mary Zulu",
                        value: form.data.contact_person ?? "",
                        onChange: (e) => form.setData(
                          "contact_person",
                          e.target.value
                        )
                      }
                    ),
                    form.errors.contact_person && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.contact_person })
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsxs(
                      Label,
                      {
                        htmlFor: "email",
                        className: "flex items-center gap-2",
                        children: [
                          /* @__PURE__ */ jsx(Mail, { className: "h-4 w-4 text-muted-foreground" }),
                          "Email"
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        id: "email",
                        type: "email",
                        placeholder: "billing@client.com",
                        value: form.data.email ?? "",
                        onChange: (e) => form.setData(
                          "email",
                          e.target.value
                        )
                      }
                    ),
                    form.errors.email && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.email })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsxs(
                      Label,
                      {
                        htmlFor: "phone",
                        className: "flex items-center gap-2",
                        children: [
                          /* @__PURE__ */ jsx(Phone, { className: "h-4 w-4 text-muted-foreground" }),
                          "Phone"
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        id: "phone",
                        placeholder: "+260...",
                        value: form.data.phone ?? "",
                        onChange: (e) => form.setData(
                          "phone",
                          e.target.value
                        )
                      }
                    ),
                    form.errors.phone && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.phone })
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsxs(
                      Label,
                      {
                        htmlFor: "tpin",
                        className: "flex items-center gap-2",
                        children: [
                          /* @__PURE__ */ jsx(IdCard, { className: "h-4 w-4 text-muted-foreground" }),
                          "TPIN"
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        id: "tpin",
                        placeholder: "e.g. 100XXXXXXX",
                        value: form.data.tpin ?? "",
                        onChange: (e) => form.setData(
                          "tpin",
                          e.target.value
                        )
                      }
                    ),
                    form.errors.tpin && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.tpin })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsxs(
                      Label,
                      {
                        htmlFor: "address",
                        className: "flex items-center gap-2",
                        children: [
                          /* @__PURE__ */ jsx(MapPin, { className: "h-4 w-4 text-muted-foreground" }),
                          "Address"
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        id: "address",
                        placeholder: "Street, Area",
                        value: form.data.address ?? "",
                        onChange: (e) => form.setData(
                          "address",
                          e.target.value
                        )
                      }
                    ),
                    form.errors.address && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.address })
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsx(Label, { htmlFor: "city", children: "City" }),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        id: "city",
                        placeholder: "e.g. Lusaka",
                        value: form.data.city ?? "",
                        onChange: (e) => form.setData(
                          "city",
                          e.target.value
                        )
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsx(Label, { htmlFor: "country", children: "Country" }),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        id: "country",
                        placeholder: "e.g. Zambia",
                        value: form.data.country ?? "",
                        onChange: (e) => form.setData(
                          "country",
                          e.target.value
                        )
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxs(
                    Label,
                    {
                      htmlFor: "notes",
                      className: "flex items-center gap-2",
                      children: [
                        /* @__PURE__ */ jsx(StickyNote, { className: "h-4 w-4 text-muted-foreground" }),
                        "Notes"
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    Textarea,
                    {
                      id: "notes",
                      placeholder: "Billing instructions, delivery notes, etc.",
                      value: form.data.notes ?? "",
                      onChange: (e) => form.setData(
                        "notes",
                        e.target.value
                      ),
                      rows: 4
                    }
                  ),
                  form.errors.notes && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.notes })
                ] }),
                /* @__PURE__ */ jsx(Separator, {}),
                /* @__PURE__ */ jsxs("div", { className: "flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-end", children: [
                  /* @__PURE__ */ jsxs(
                    Button,
                    {
                      type: "button",
                      variant: "ghost",
                      onClick: closeAndReset,
                      disabled: form.processing,
                      className: "rounded-xl",
                      children: [
                        /* @__PURE__ */ jsx(X, { className: "mr-2 h-4 w-4" }),
                        "Cancel"
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    Button,
                    {
                      type: "submit",
                      disabled: form.processing || !form.data.name.trim(),
                      className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                      children: form.processing ? /* @__PURE__ */ jsxs(Fragment, { children: [
                        /* @__PURE__ */ jsx(Loader2, { className: "mr-2 h-4 w-4 animate-spin" }),
                        "Saving..."
                      ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
                        /* @__PURE__ */ jsx(UserPlus, { className: "mr-2 h-4 w-4" }),
                        "Save client"
                      ] })
                    }
                  )
                ] })
              ] })
            ] })
          },
          open ? "open" : "closed"
        ) }) })
      ]
    }
  );
}
function DeleteClientButton({ client }) {
  const [open, setOpen] = useState(false);
  const del = () => {
    router.delete(`/clients/${client.id}`, {
      preserveScroll: true,
      onSuccess: () => {
        toast.success("Client deleted.");
        setOpen(false);
      },
      onError: (errors) => {
        toast.error(errors?.client || "Failed to delete client.");
      }
    });
  };
  return /* @__PURE__ */ jsxs(AlertDialog, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsx(AlertDialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(
      Button,
      {
        variant: "destructive",
        size: "sm",
        className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
        children: [
          /* @__PURE__ */ jsx(Trash2, { className: "mr-2 h-4 w-4" }),
          "Delete"
        ]
      }
    ) }),
    /* @__PURE__ */ jsxs(AlertDialogContent, { className: "rounded-2xl", children: [
      /* @__PURE__ */ jsxs(AlertDialogHeader, { children: [
        /* @__PURE__ */ jsx(AlertDialogTitle, { children: "Delete client?" }),
        /* @__PURE__ */ jsxs(AlertDialogDescription, { children: [
          "This will permanently remove",
          " ",
          /* @__PURE__ */ jsx("span", { className: "font-medium", children: client.name }),
          "."
        ] })
      ] }),
      /* @__PURE__ */ jsxs(AlertDialogFooter, { children: [
        /* @__PURE__ */ jsx(AlertDialogCancel, { className: "rounded-xl", children: "Cancel" }),
        /* @__PURE__ */ jsx(
          AlertDialogAction,
          {
            onClick: del,
            className: cn(
              "rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90"
            ),
            children: "Delete"
          }
        )
      ] })
    ] })
  ] });
}
export {
  ClientsIndex as default
};
