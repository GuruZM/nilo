import { jsxs, jsx } from "react/jsx-runtime";
import { C as Chatbot } from "./Chatbot-yoo4250k.js";
import { A as AppSidebarLayout } from "./app-sidebar-layout-BGzXXcN9.js";
import { Toaster } from "sonner";
const AppLayout = ({ children, breadcrumbs, ...props }) => /* @__PURE__ */ jsxs(AppSidebarLayout, { breadcrumbs, ...props, children: [
  /* @__PURE__ */ jsx(Toaster, { richColors: true, position: "top-right" }),
  children,
  /* @__PURE__ */ jsx(Chatbot, {})
] });
export {
  AppLayout as A
};
