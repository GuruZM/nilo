import { jsx } from "react/jsx-runtime";
function AppLogoIcon({ className }) {
  return /* @__PURE__ */ jsx("img", { src: "/logo.svg", alt: "Nilo", className, style: { objectFit: "contain" } });
}
export {
  AppLogoIcon as A
};
