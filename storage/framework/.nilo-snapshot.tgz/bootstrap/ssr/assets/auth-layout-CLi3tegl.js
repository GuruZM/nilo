import { jsxs, jsx } from "react/jsx-runtime";
import { A as AppLogoIcon } from "./app-logo-icon-B5cAnkkG.js";
import { P as PaperSheet, C as CheckedDocument } from "./PaperGlyphs-ClQ5oP_s.js";
import { h as home } from "./index-NXMefbOa.js";
import { Link } from "@inertiajs/react";
import { Bot, Building2, FileText } from "lucide-react";
const facts = [
  { icon: Bot, label: "AI assistant drafts your documents" },
  { icon: Building2, label: "Nothing to install or manage" },
  { icon: FileText, label: "Request features on paid plans" }
];
function AuthSplitLayout({
  children,
  title,
  description
}) {
  return /* @__PURE__ */ jsxs("div", { className: "grid min-h-dvh lg:grid-cols-2", children: [
    /* @__PURE__ */ jsxs("div", { className: "relative hidden flex-col justify-between overflow-hidden bg-gradient-to-br from-brand-800 via-brand-900 to-brand-950 p-10 text-white lg:flex", children: [
      /* @__PURE__ */ jsx(
        "div",
        {
          "aria-hidden": true,
          className: "absolute -top-24 right-[-6rem] h-96 w-96 rounded-full bg-brand-500/20 blur-3xl"
        }
      ),
      /* @__PURE__ */ jsx(
        "div",
        {
          "aria-hidden": true,
          className: "absolute bottom-[-8rem] left-[-4rem] h-80 w-80 rounded-full bg-brand-400/10 blur-3xl"
        }
      ),
      /* @__PURE__ */ jsx("div", { "aria-hidden": true, className: "absolute top-[16%] right-[14%] rotate-[20deg] opacity-30", children: /* @__PURE__ */ jsx(PaperSheet, { className: "h-20 w-16" }) }),
      /* @__PURE__ */ jsx("div", { "aria-hidden": true, className: "absolute top-[30%] right-[30%] -rotate-12 opacity-45", children: /* @__PURE__ */ jsx(PaperSheet, { className: "h-24 w-20" }) }),
      /* @__PURE__ */ jsx("div", { "aria-hidden": true, className: "absolute top-[42%] right-[10%] drop-shadow-[0_20px_40px_rgba(0,18,38,0.5)]", children: /* @__PURE__ */ jsx(CheckedDocument, { className: "h-44 w-36" }) }),
      /* @__PURE__ */ jsx(
        "div",
        {
          "aria-hidden": true,
          className: "absolute inset-0 bg-[repeating-linear-gradient(115deg,transparent_0px,transparent_56px,rgba(255,255,255,0.03)_56px,rgba(255,255,255,0.03)_58px)]"
        }
      ),
      /* @__PURE__ */ jsx(Link, { href: home(), "aria-label": "Nilo home", className: "relative z-10", children: /* @__PURE__ */ jsx(AppLogoIcon, { className: "h-10 w-auto brightness-0 invert" }) }),
      /* @__PURE__ */ jsxs("div", { className: "relative z-10", children: [
        /* @__PURE__ */ jsxs("p", { className: "max-w-md text-4xl leading-tight font-bold xl:text-5xl", children: [
          "Send the invoice.",
          " ",
          /* @__PURE__ */ jsx("span", { className: "text-brand-300", children: "Win the day." })
        ] }),
        /* @__PURE__ */ jsx("ul", { className: "mt-10 space-y-3", children: facts.map((fact) => /* @__PURE__ */ jsxs(
          "li",
          {
            className: "flex items-center gap-3 text-sm text-brand-100",
            children: [
              /* @__PURE__ */ jsx(fact.icon, { className: "h-4 w-4 shrink-0 text-brand-300" }),
              fact.label
            ]
          },
          fact.label
        )) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "relative z-10 text-xs text-white/50", children: [
        "© ",
        (/* @__PURE__ */ new Date()).getFullYear(),
        " Nilo"
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col", children: [
      /* @__PURE__ */ jsx("div", { className: "bg-gradient-to-r from-brand-800 to-brand-900 p-6 lg:hidden", children: /* @__PURE__ */ jsx(Link, { href: home(), "aria-label": "Nilo home", children: /* @__PURE__ */ jsx(AppLogoIcon, { className: "h-9 w-auto brightness-0 invert" }) }) }),
      /* @__PURE__ */ jsx("div", { className: "flex flex-1 items-center justify-center px-6 py-12", children: /* @__PURE__ */ jsxs("div", { className: "flex w-full flex-col gap-6 sm:w-[380px]", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
          /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold", children: title }),
          /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: description })
        ] }),
        children
      ] }) })
    ] })
  ] });
}
function AuthLayout({
  children,
  title,
  description,
  ...props
}) {
  return /* @__PURE__ */ jsx(AuthSplitLayout, { title, description, ...props, children });
}
export {
  AuthLayout as A
};
