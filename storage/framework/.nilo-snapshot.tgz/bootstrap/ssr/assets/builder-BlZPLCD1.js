import { jsxs, jsx } from "react/jsx-runtime";
import { usePage, useForm, Head, router } from "@inertiajs/react";
import { motion, AnimatePresence } from "framer-motion";
import { LayoutTemplate, ArrowLeft, Save, Check, CheckCircle2, Eye, Sparkles, Palette, Settings2, Type } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";
import { A as AppLayout } from "./app-layout-JvxHjkrs.js";
import { B as Badge } from "./badge-CfxidL8Q.js";
import { B as Button, c as cn } from "./button-DMGEFYrU.js";
import { C as Card } from "./card-MypPWj87.js";
import { I as Input } from "./input-nVyaPHpJ.js";
import { L as Label } from "./label-BjflLCFy.js";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-DesEnXXV.js";
import { S as Separator } from "./separator-Bcia5PKZ.js";
import { S as Switch } from "./switch-4h1eh9fE.js";
import { T as Textarea } from "./textarea-B2f7VE2B.js";
import "./Chatbot-yoo4250k.js";
import "./app-sidebar-layout-BGzXXcN9.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
import "@radix-ui/react-select";
import "@radix-ui/react-separator";
import "@radix-ui/react-switch";
const STEPS = [
  { key: "preset", title: "Preset", icon: Sparkles },
  { key: "style", title: "Style", icon: Palette },
  { key: "layout", title: "Layout", icon: Settings2 },
  { key: "content", title: "Content", icon: Type },
  { key: "review", title: "Review", icon: Eye }
];
const PRESETS = [
  {
    id: "wave_premium",
    name: "Wave Premium",
    description: "Bold header with wave + accent table + grand total.",
    defaults: {
      brand: { primary: "#111827", accent: "#F59E0B", font: "Inter" },
      layout: { header: "split", table: "striped", density: "normal" }
    }
  },
  {
    id: "modern_minimal",
    name: "Modern Minimal",
    description: "Clean, modern look. Great default.",
    defaults: {
      brand: { primary: "#0F172A", accent: "#22C55E", font: "Inter" },
      layout: { header: "split", table: "striped", density: "normal" }
    }
  },
  {
    id: "classic_business",
    name: "Classic Business",
    description: "Traditional layout, lined table, corporate safe.",
    defaults: {
      brand: { primary: "#111827", accent: "#2563EB", font: "Arial" },
      layout: { header: "left", table: "lined", density: "normal" }
    }
  },
  {
    id: "bold_header",
    name: "Bold Header",
    description: "Strong title + airy spacing for premium brands.",
    defaults: {
      brand: { primary: "#111827", accent: "#F97316", font: "Inter" },
      layout: { header: "center", table: "clean", density: "airy" }
    }
  }
];
const DEFAULT_SETTINGS = {
  preset: "wave_premium",
  brand: { primary: "#111827", accent: "#F59E0B", font: "Inter" },
  layout: { header: "split", table: "striped", density: "normal" },
  visibility: {
    show_logo: true,
    show_client_email: true,
    show_contact_person: true,
    show_terms: true,
    show_notes: true,
    show_bank_details: false,
    show_signature: false
  }
};
const SAMPLE = {
  company: {
    name: "Nilo Labs Ltd",
    address: "Lusaka, Zambia",
    phone: "+260 97X XXX XXX",
    email: "billing@nilo.ai",
    tpin: "TPIN: 1234567890",
    bank: {
      name: "Zanaco",
      account_name: "Nilo Labs Ltd",
      account_number: "00123456789",
      branch: "Cairo Road"
    }
  },
  client: {
    name: "Resonant Technologies",
    email: "accounts@resonant.tech",
    contact_person: "Charles Ngalasa",
    address: "Ibex Hill, Lusaka"
  },
  document: {
    issue_date: "2026-01-03",
    due_date: "2026-01-10",
    notes: "Thank you for your business. Kindly settle within due date.",
    items: [
      { desc: "Prime POS Setup & Configuration", qty: 1, price: 2500 },
      { desc: "ZRA Smart Tax Integration", qty: 1, price: 1800 },
      { desc: "Training Session (2 hours)", qty: 1, price: 650 }
    ],
    signature: {
      name: "Thomas Daney",
      title: "Accounting Manager",
      label: "Signature"
    }
  }
};
function InvoiceTemplateBuilder({
  mode,
  template,
  module
}) {
  const page = usePage();
  const singularLabel = module.singularTitle.toLowerCase();
  const documentTitle = module.type === "quotation" ? "QUOTATION" : "INVOICE";
  const documentNumberLabel = module.type === "quotation" ? "Quote No" : "Invoice No";
  const documentNumberValue = module.type === "quotation" ? "QUO-000123" : "INV-000123";
  const sampleLabel = module.type === "quotation" ? "A4 preview (sample quotation)" : "A4 preview (sample invoice)";
  const breadcrumbs = [
    { title: "Settings", href: "/settings/profile" },
    { title: module.pluralTitle, href: module.basePath },
    { title: "Builder", href: module.createPath }
  ];
  React.useEffect(() => {
    const s = page.props.flash?.success;
    const e = page.props.flash?.error;
    const i = page.props.flash?.info;
    if (s) toast.success(s);
    if (e) toast.error(e);
    if (i) toast.message(i);
  }, [
    page.props.flash?.success,
    page.props.flash?.error,
    page.props.flash?.info
  ]);
  const [step, setStep] = React.useState("preset");
  const initialSettings = React.useMemo(() => {
    const s = template?.settings ?? null;
    if (!s) return DEFAULT_SETTINGS;
    return {
      ...DEFAULT_SETTINGS,
      ...s,
      brand: { ...DEFAULT_SETTINGS.brand, ...s.brand ?? {} },
      layout: { ...DEFAULT_SETTINGS.layout, ...s.layout ?? {} },
      visibility: {
        ...DEFAULT_SETTINGS.visibility,
        ...s.visibility ?? {}
      }
    };
  }, [template]);
  const form = useForm({
    name: template?.name ?? "",
    is_default: template?.is_default ?? false,
    settings: initialSettings,
    terms_html: template?.terms_html ?? (module.type === "quotation" ? "Quotation valid for 7 days." : "Payment due within 7 days."),
    footer_html: template?.footer_html ?? "Powered by Nilo"
  });
  const settings = form.data.settings;
  const applyPreset = (presetId) => {
    const preset = PRESETS.find((p) => p.id === presetId);
    const next = {
      ...DEFAULT_SETTINGS,
      ...settings,
      preset: presetId,
      brand: {
        ...DEFAULT_SETTINGS.brand,
        ...preset?.defaults.brand ?? {},
        ...settings.brand
      },
      layout: {
        ...DEFAULT_SETTINGS.layout,
        ...preset?.defaults.layout ?? {},
        ...settings.layout
      },
      visibility: {
        ...DEFAULT_SETTINGS.visibility,
        ...settings.visibility
      }
    };
    form.setData("settings", next);
  };
  const setBrand = (key, v) => {
    form.setData("settings", {
      ...settings,
      brand: { ...settings.brand, [key]: v }
    });
  };
  const setLayout = (key, v) => {
    form.setData("settings", {
      ...settings,
      layout: { ...settings.layout, [key]: v }
    });
  };
  const setVisibility = (key, v) => {
    form.setData("settings", {
      ...settings,
      visibility: { ...settings.visibility, [key]: v }
    });
  };
  const order = [
    "preset",
    "style",
    "layout",
    "content",
    "review"
  ];
  const validateStep = (s) => {
    if (s === "preset" && !form.data.name.trim()) {
      toast.error("Template name is required.");
      return false;
    }
    if (s === "style" && (!settings.brand.primary || !settings.brand.accent)) {
      toast.error("Pick primary and accent colors.");
      return false;
    }
    return true;
  };
  const goNext = () => {
    if (!validateStep(step)) return;
    setStep(order[Math.min(order.indexOf(step) + 1, order.length - 1)]);
  };
  const goBack = () => {
    setStep(order[Math.max(order.indexOf(step) - 1, 0)]);
  };
  const save = () => {
    if (!form.data.name.trim()) {
      toast.error("Template name is required.");
      setStep("preset");
      return;
    }
    const payload = {
      name: form.data.name,
      is_default: !!form.data.is_default,
      settings: form.data.settings,
      terms_html: form.data.terms_html,
      footer_html: form.data.footer_html
    };
    const onError = (errors) => {
      toast.error(
        errors?.template || errors?.name || errors?.settings || "Failed to save template."
      );
    };
    if (mode === "create") {
      router.post(module.basePath, payload, {
        preserveScroll: true,
        preserveState: false,
        onSuccess: () => toast.success(`${module.singularTitle} created.`),
        onError
      });
    } else {
      router.put(`${module.basePath}/${template?.id}`, payload, {
        preserveScroll: true,
        preserveState: false,
        onSuccess: () => toast.success(`${module.singularTitle} updated.`),
        onError
      });
    }
  };
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsxs(Head, { title: `${module.singularTitle} builder`, children: [
      /* @__PURE__ */ jsx("link", { rel: "preconnect", href: "https://fonts.googleapis.com" }),
      /* @__PURE__ */ jsx(
        "link",
        {
          rel: "preconnect",
          href: "https://fonts.gstatic.com",
          crossOrigin: ""
        }
      ),
      /* @__PURE__ */ jsx(
        "link",
        {
          href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Roboto:wght@400;500;700&display=swap",
          rel: "stylesheet"
        }
      )
    ] }),
    /* @__PURE__ */ jsxs(
      motion.div,
      {
        initial: { opacity: 0, y: 14 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.25, ease: "easeOut" },
        className: "space-y-6",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "grid h-11 w-11 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(LayoutTemplate, { className: "h-6 w-6 opacity-80" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-semibold tracking-tight", children: [
                    module.singularTitle,
                    " builder"
                  ] }),
                  /* @__PURE__ */ jsx(
                    Badge,
                    {
                      variant: "secondary",
                      className: "rounded-full",
                      children: mode === "create" ? "Create" : "Edit"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "Premium presets + styling + layout controls with a designer-grade live preview." })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxs(
                Button,
                {
                  variant: "outline",
                  className: "gap-2 rounded-xl",
                  onClick: () => router.visit(module.basePath),
                  children: [
                    /* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }),
                    "Back"
                  ]
                }
              ),
              /* @__PURE__ */ jsxs(
                Button,
                {
                  className: "gap-2 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                  onClick: save,
                  disabled: form.processing,
                  children: [
                    /* @__PURE__ */ jsx(Save, { className: "h-4 w-4" }),
                    mode === "create" ? "Save template" : "Update template"
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-6 lg:grid-cols-12", children: [
            /* @__PURE__ */ jsxs(Card, { className: "flex flex-col rounded-2xl border bg-background p-6 shadow-sm lg:col-span-5", children: [
              /* @__PURE__ */ jsx(Stepper, { step, onStep: setStep }),
              /* @__PURE__ */ jsx(Separator, { className: "my-4" }),
              /* @__PURE__ */ jsx("div", { className: "flex-1", children: /* @__PURE__ */ jsxs(AnimatePresence, { mode: "wait", children: [
                step === "preset" && /* @__PURE__ */ jsxs(
                  motion.div,
                  {
                    initial: { opacity: 0, y: 10 },
                    animate: { opacity: 1, y: 0 },
                    exit: { opacity: 0, y: 10 },
                    transition: { duration: 0.2 },
                    className: "space-y-4",
                    children: [
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx(Label, { children: "Template name *" }),
                        /* @__PURE__ */ jsx(
                          Input,
                          {
                            value: form.data.name,
                            onChange: (e) => form.setData(
                              "name",
                              e.target.value
                            ),
                            className: "rounded-xl",
                            placeholder: `e.g. Wave Premium (${module.type === "quotation" ? "Quotation" : "Invoice"})`
                          }
                        ),
                        form.errors.name && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.name })
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between rounded-xl border p-4", children: [
                        /* @__PURE__ */ jsxs("div", { children: [
                          /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Default template" }),
                          /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground", children: [
                            "Make this the default",
                            " ",
                            singularLabel,
                            " for this company."
                          ] })
                        ] }),
                        /* @__PURE__ */ jsx(
                          Switch,
                          {
                            checked: !!form.data.is_default,
                            onCheckedChange: (v) => form.setData(
                              "is_default",
                              !!v
                            )
                          }
                        )
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx(Label, { children: "Preset" }),
                        /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 gap-3", children: PRESETS.map((p) => {
                          const selected = settings.preset === p.id;
                          return /* @__PURE__ */ jsx(
                            "button",
                            {
                              type: "button",
                              onClick: () => applyPreset(
                                p.id
                              ),
                              className: cn(
                                "w-full rounded-2xl border p-4 text-left transition",
                                "hover:bg-muted/30",
                                selected && "border-foreground/30 bg-muted/40"
                              ),
                              children: /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-2", children: [
                                /* @__PURE__ */ jsxs("div", { children: [
                                  /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: p.name }),
                                  /* @__PURE__ */ jsx("div", { className: "mt-1 text-xs text-muted-foreground", children: p.description })
                                ] }),
                                selected && /* @__PURE__ */ jsx(Check, { className: "h-4 w-4 opacity-80" })
                              ] })
                            },
                            p.id
                          );
                        }) })
                      ] })
                    ]
                  },
                  "preset"
                ),
                step === "style" && /* @__PURE__ */ jsxs(
                  motion.div,
                  {
                    initial: { opacity: 0, y: 10 },
                    animate: { opacity: 1, y: 0 },
                    exit: { opacity: 0, y: 10 },
                    transition: { duration: 0.2 },
                    className: "space-y-4",
                    children: [
                      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
                        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                          /* @__PURE__ */ jsx(Label, { children: "Primary color" }),
                          /* @__PURE__ */ jsx(
                            Input,
                            {
                              type: "color",
                              value: settings.brand.primary,
                              onChange: (e) => setBrand(
                                "primary",
                                e.target.value
                              ),
                              className: "h-10 rounded-xl p-1"
                            }
                          )
                        ] }),
                        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                          /* @__PURE__ */ jsx(Label, { children: "Accent color" }),
                          /* @__PURE__ */ jsx(
                            Input,
                            {
                              type: "color",
                              value: settings.brand.accent,
                              onChange: (e) => setBrand(
                                "accent",
                                e.target.value
                              ),
                              className: "h-10 rounded-xl p-1"
                            }
                          )
                        ] })
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx(Label, { children: "Font" }),
                        /* @__PURE__ */ jsxs(
                          Select,
                          {
                            value: settings.brand.font,
                            onValueChange: (v) => setBrand("font", v),
                            children: [
                              /* @__PURE__ */ jsx(SelectTrigger, { className: "rounded-xl", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                              /* @__PURE__ */ jsxs(SelectContent, { children: [
                                /* @__PURE__ */ jsx(SelectItem, { value: "Inter", children: "Inter" }),
                                /* @__PURE__ */ jsx(SelectItem, { value: "Roboto", children: "Roboto" }),
                                /* @__PURE__ */ jsx(SelectItem, { value: "Arial", children: "Arial" })
                              ] })
                            ]
                          }
                        )
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx(Label, { children: "Density" }),
                        /* @__PURE__ */ jsxs(
                          Select,
                          {
                            value: settings.layout.density,
                            onValueChange: (v) => setLayout("density", v),
                            children: [
                              /* @__PURE__ */ jsx(SelectTrigger, { className: "rounded-xl", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                              /* @__PURE__ */ jsxs(SelectContent, { children: [
                                /* @__PURE__ */ jsx(SelectItem, { value: "compact", children: "Compact" }),
                                /* @__PURE__ */ jsx(SelectItem, { value: "normal", children: "Normal" }),
                                /* @__PURE__ */ jsx(SelectItem, { value: "airy", children: "Airy" })
                              ] })
                            ]
                          }
                        )
                      ] })
                    ]
                  },
                  "style"
                ),
                step === "layout" && /* @__PURE__ */ jsxs(
                  motion.div,
                  {
                    initial: { opacity: 0, y: 10 },
                    animate: { opacity: 1, y: 0 },
                    exit: { opacity: 0, y: 10 },
                    transition: { duration: 0.2 },
                    className: "space-y-4",
                    children: [
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx(Label, { children: "Header layout" }),
                        /* @__PURE__ */ jsxs(
                          Select,
                          {
                            value: settings.layout.header,
                            onValueChange: (v) => setLayout("header", v),
                            children: [
                              /* @__PURE__ */ jsx(SelectTrigger, { className: "rounded-xl", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                              /* @__PURE__ */ jsxs(SelectContent, { children: [
                                /* @__PURE__ */ jsx(SelectItem, { value: "split", children: "Split (logo left, meta right)" }),
                                /* @__PURE__ */ jsx(SelectItem, { value: "left", children: "Left aligned" }),
                                /* @__PURE__ */ jsx(SelectItem, { value: "center", children: "Centered" })
                              ] })
                            ]
                          }
                        )
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx(Label, { children: "Table style" }),
                        /* @__PURE__ */ jsxs(
                          Select,
                          {
                            value: settings.layout.table,
                            onValueChange: (v) => setLayout("table", v),
                            children: [
                              /* @__PURE__ */ jsx(SelectTrigger, { className: "rounded-xl", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                              /* @__PURE__ */ jsxs(SelectContent, { children: [
                                /* @__PURE__ */ jsx(SelectItem, { value: "striped", children: "Striped" }),
                                /* @__PURE__ */ jsx(SelectItem, { value: "lined", children: "Lined" }),
                                /* @__PURE__ */ jsx(SelectItem, { value: "clean", children: "Clean" })
                              ] })
                            ]
                          }
                        )
                      ] }),
                      /* @__PURE__ */ jsx(Separator, {}),
                      /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
                        /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Visibility (layout)" }),
                        /* @__PURE__ */ jsx(
                          ToggleRow,
                          {
                            label: "Show logo",
                            checked: settings.visibility.show_logo,
                            onChange: (v) => setVisibility(
                              "show_logo",
                              v
                            )
                          }
                        ),
                        /* @__PURE__ */ jsx(
                          ToggleRow,
                          {
                            label: "Show client email",
                            checked: settings.visibility.show_client_email,
                            onChange: (v) => setVisibility(
                              "show_client_email",
                              v
                            )
                          }
                        ),
                        /* @__PURE__ */ jsx(
                          ToggleRow,
                          {
                            label: "Show contact person",
                            checked: settings.visibility.show_contact_person,
                            onChange: (v) => setVisibility(
                              "show_contact_person",
                              v
                            )
                          }
                        )
                      ] })
                    ]
                  },
                  "layout"
                ),
                step === "content" && /* @__PURE__ */ jsxs(
                  motion.div,
                  {
                    initial: { opacity: 0, y: 10 },
                    animate: { opacity: 1, y: 0 },
                    exit: { opacity: 0, y: 10 },
                    transition: { duration: 0.2 },
                    className: "space-y-4",
                    children: [
                      /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
                        /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Content blocks" }),
                        /* @__PURE__ */ jsx(
                          ToggleRow,
                          {
                            label: "Show notes",
                            checked: settings.visibility.show_notes,
                            onChange: (v) => setVisibility(
                              "show_notes",
                              v
                            )
                          }
                        ),
                        /* @__PURE__ */ jsx(
                          ToggleRow,
                          {
                            label: "Show terms",
                            checked: settings.visibility.show_terms,
                            onChange: (v) => setVisibility(
                              "show_terms",
                              v
                            )
                          }
                        ),
                        /* @__PURE__ */ jsx(
                          ToggleRow,
                          {
                            label: "Show bank details",
                            checked: settings.visibility.show_bank_details,
                            onChange: (v) => setVisibility(
                              "show_bank_details",
                              v
                            )
                          }
                        ),
                        /* @__PURE__ */ jsx(
                          ToggleRow,
                          {
                            label: "Show signature",
                            checked: settings.visibility.show_signature,
                            onChange: (v) => setVisibility(
                              "show_signature",
                              v
                            )
                          }
                        )
                      ] }),
                      /* @__PURE__ */ jsx(Separator, {}),
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx(Label, { children: "Default terms" }),
                        /* @__PURE__ */ jsx(
                          Textarea,
                          {
                            value: form.data.terms_html,
                            onChange: (e) => form.setData(
                              "terms_html",
                              e.target.value
                            ),
                            className: "min-h-[120px] rounded-xl",
                            placeholder: "Payment terms..."
                          }
                        )
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx(Label, { children: "Footer text" }),
                        /* @__PURE__ */ jsx(
                          Textarea,
                          {
                            value: form.data.footer_html,
                            onChange: (e) => form.setData(
                              "footer_html",
                              e.target.value
                            ),
                            className: "min-h-[90px] rounded-xl",
                            placeholder: "Footer..."
                          }
                        )
                      ] })
                    ]
                  },
                  "content"
                ),
                step === "review" && /* @__PURE__ */ jsxs(
                  motion.div,
                  {
                    initial: { opacity: 0, y: 10 },
                    animate: { opacity: 1, y: 0 },
                    exit: { opacity: 0, y: 10 },
                    transition: { duration: 0.2 },
                    className: "space-y-4",
                    children: [
                      /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border p-4", children: [
                        /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Summary" }),
                        /* @__PURE__ */ jsxs("div", { className: "mt-3 space-y-2 text-sm text-muted-foreground", children: [
                          /* @__PURE__ */ jsxs("div", { children: [
                            /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: "Name:" }),
                            " ",
                            form.data.name || "—"
                          ] }),
                          /* @__PURE__ */ jsxs("div", { children: [
                            /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: "Preset:" }),
                            " ",
                            settings.preset
                          ] }),
                          /* @__PURE__ */ jsxs("div", { children: [
                            /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: "Font:" }),
                            " ",
                            settings.brand.font
                          ] }),
                          /* @__PURE__ */ jsxs("div", { children: [
                            /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: "Header:" }),
                            " ",
                            settings.layout.header
                          ] }),
                          /* @__PURE__ */ jsxs("div", { children: [
                            /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: "Table:" }),
                            " ",
                            settings.layout.table
                          ] }),
                          /* @__PURE__ */ jsxs("div", { children: [
                            /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: "Default:" }),
                            " ",
                            form.data.is_default ? "Yes" : "No"
                          ] })
                        ] })
                      ] }),
                      /* @__PURE__ */ jsxs(
                        Button,
                        {
                          type: "button",
                          className: "w-full gap-2 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                          onClick: save,
                          disabled: form.processing,
                          children: [
                            /* @__PURE__ */ jsx(CheckCircle2, { className: "h-4 w-4" }),
                            mode === "create" ? "Save template" : "Update template"
                          ]
                        }
                      ),
                      form.errors && form.errors.template && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.template })
                    ]
                  },
                  "review"
                )
              ] }) }),
              /* @__PURE__ */ jsx(Separator, { className: "my-4" }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsx(
                  Button,
                  {
                    type: "button",
                    variant: "outline",
                    onClick: goBack,
                    disabled: step === "preset" || form.processing,
                    className: "rounded-xl",
                    children: "Back"
                  }
                ),
                step !== "review" ? /* @__PURE__ */ jsx(
                  Button,
                  {
                    type: "button",
                    onClick: goNext,
                    disabled: form.processing,
                    className: "rounded-xl",
                    children: "Next"
                  }
                ) : /* @__PURE__ */ jsx(
                  Button,
                  {
                    type: "button",
                    onClick: save,
                    disabled: form.processing,
                    className: "rounded-xl",
                    children: "Save"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs(Card, { className: "flex flex-col rounded-2xl border bg-background p-6 shadow-sm lg:col-span-7", children: [
              /* @__PURE__ */ jsxs("div", { className: "mb-4 flex items-center justify-between", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx(Eye, { className: "h-5 w-5 opacity-80" }),
                  /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Live preview" })
                ] }),
                /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: sampleLabel })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "flex-1", children: /* @__PURE__ */ jsx(
                A4PreviewPremium,
                {
                  documentNumberLabel,
                  documentNumberValue,
                  documentTitle,
                  documentType: module.type,
                  settings,
                  terms: form.data.terms_html,
                  footer: form.data.footer_html
                }
              ) })
            ] })
          ] })
        ]
      }
    )
  ] });
}
function Stepper({
  step,
  onStep
}) {
  return /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2", children: STEPS.map((s) => {
    const active = s.key === step;
    const Icon = s.icon;
    return /* @__PURE__ */ jsxs(
      "button",
      {
        type: "button",
        onClick: () => onStep(s.key),
        className: cn(
          "flex items-center gap-2 rounded-xl border px-3 py-2 text-sm transition",
          "hover:bg-muted/30",
          active && "bg-muted/50"
        ),
        children: [
          /* @__PURE__ */ jsx(Icon, { className: "h-4 w-4 opacity-80" }),
          s.title
        ]
      },
      s.key
    );
  }) });
}
function ToggleRow({
  label,
  checked,
  onChange
}) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between rounded-xl border p-3", children: [
    /* @__PURE__ */ jsx("div", { className: "text-sm", children: label }),
    /* @__PURE__ */ jsx(Switch, { checked, onCheckedChange: (v) => onChange(!!v) })
  ] });
}
function A4PreviewPremium({
  documentNumberLabel,
  documentNumberValue,
  documentTitle,
  documentType,
  settings,
  terms,
  footer
}) {
  const accent = settings.brand.accent;
  const primary = settings.brand.primary;
  const fontMap = {
    Inter: "Inter, ui-sans-serif, system-ui, -apple-system, Segoe UI, sans-serif",
    Roboto: "Roboto, ui-sans-serif, system-ui, -apple-system, Segoe UI, sans-serif",
    Arial: "Arial, Helvetica, ui-sans-serif, system-ui, sans-serif"
  };
  const fontFamily = fontMap[settings.brand.font] ?? fontMap.Inter;
  const items = SAMPLE.document.items.map((it) => ({
    ...it,
    total: it.qty * it.price
  }));
  const subtotal = items.reduce((a, b) => a + b.total, 0);
  const vat = subtotal * 0.16;
  const grand = subtotal + vat;
  const density = settings.layout.density;
  const pad = density === "compact" ? "px-7 pt-7 pb-7" : density === "airy" ? "px-10 pt-10 pb-10" : "px-8 pt-8 pb-8";
  const table = settings.layout.table;
  const isCenter = settings.layout.header === "center";
  return /* @__PURE__ */ jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ jsxs(
    "div",
    {
      className: "relative w-full max-w-[760px] overflow-hidden rounded-2xl bg-white shadow-xl",
      style: { fontFamily },
      children: [
        /* @__PURE__ */ jsxs(
          "div",
          {
            className: cn(
              "relative text-white",
              isCenter ? "text-center" : "text-left"
            ),
            style: { backgroundColor: primary },
            children: [
              /* @__PURE__ */ jsx("div", { className: cn(pad, "relative z-10 pb-16"), children: /* @__PURE__ */ jsxs(
                "div",
                {
                  className: cn(
                    "flex items-start justify-between gap-6",
                    isCenter && "flex-col items-center"
                  ),
                  children: [
                    /* @__PURE__ */ jsxs(
                      "div",
                      {
                        className: cn(
                          "flex items-center gap-4",
                          isCenter && "justify-center"
                        ),
                        children: [
                          settings.visibility.show_logo && /* @__PURE__ */ jsx(
                            "div",
                            {
                              className: "grid h-12 w-12 place-items-center rounded-xl text-[11px] font-bold",
                              style: {
                                backgroundColor: accent,
                                color: primary
                              },
                              children: "LOGO"
                            }
                          ),
                          /* @__PURE__ */ jsxs(
                            "div",
                            {
                              className: cn(
                                "min-w-0",
                                isCenter && "text-center"
                              ),
                              children: [
                                /* @__PURE__ */ jsx("div", { className: "text-lg leading-tight font-semibold", children: SAMPLE.company.name }),
                                /* @__PURE__ */ jsx("div", { className: "mt-1 text-xs opacity-80", children: SAMPLE.company.address }),
                                /* @__PURE__ */ jsxs("div", { className: "text-xs opacity-80", children: [
                                  SAMPLE.company.phone,
                                  " •",
                                  " ",
                                  SAMPLE.company.email
                                ] }),
                                /* @__PURE__ */ jsx("div", { className: "text-xs opacity-80", children: SAMPLE.company.tpin })
                              ]
                            }
                          )
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxs(
                      "div",
                      {
                        className: cn(
                          "shrink-0",
                          isCenter ? "text-center" : "text-right"
                        ),
                        children: [
                          /* @__PURE__ */ jsx("div", { className: "text-3xl font-extrabold tracking-[0.18em]", children: documentTitle }),
                          /* @__PURE__ */ jsxs("div", { className: "mt-3 space-y-1 text-xs opacity-80", children: [
                            /* @__PURE__ */ jsxs("div", { children: [
                              documentNumberLabel,
                              ":",
                              " ",
                              documentNumberValue
                            ] }),
                            /* @__PURE__ */ jsxs("div", { children: [
                              "Date: ",
                              SAMPLE.document.issue_date
                            ] }),
                            /* @__PURE__ */ jsxs("div", { children: [
                              "Due: ",
                              SAMPLE.document.due_date
                            ] })
                          ] })
                        ]
                      }
                    )
                  ]
                }
              ) }),
              /* @__PURE__ */ jsx(
                "svg",
                {
                  viewBox: "0 0 1440 140",
                  className: "absolute bottom-0 left-0 w-full",
                  preserveAspectRatio: "none",
                  children: /* @__PURE__ */ jsx(
                    "path",
                    {
                      fill: "#ffffff",
                      d: "M0,96L60,90.7C120,85,240,75,360,74.7C480,75,600,85,720,96C840,107,960,117,1080,117.3C1200,117,1320,107,1380,101.3L1440,96L1440,140L1380,140C1320,140,1200,140,1080,140C960,140,840,140,720,140C600,140,480,140,360,140C240,140,120,140,60,140L0,140Z"
                    }
                  )
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: cn(pad, "pt-8"), children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-8 flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsx(
                "div",
                {
                  className: "text-xs font-semibold uppercase",
                  style: { color: accent },
                  children: "To:"
                }
              ),
              /* @__PURE__ */ jsx("div", { className: "mt-1 text-sm font-semibold", children: SAMPLE.client.name }),
              /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: SAMPLE.client.address }),
              settings.visibility.show_client_email && /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: SAMPLE.client.email }),
              settings.visibility.show_contact_person && /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground", children: [
                "Attn: ",
                SAMPLE.client.contact_person
              ] })
            ] }),
            /* @__PURE__ */ jsxs(
              "div",
              {
                className: "w-full rounded-xl px-5 py-3 sm:w-[260px]",
                style: { backgroundColor: accent + "22" },
                children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between text-xs text-muted-foreground", children: [
                    /* @__PURE__ */ jsx("span", { children: "Sub Total" }),
                    /* @__PURE__ */ jsxs("span", { className: "font-semibold text-foreground", children: [
                      "K ",
                      subtotal.toFixed(2)
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "mt-2 flex items-center justify-between text-xs text-muted-foreground", children: [
                    /* @__PURE__ */ jsx("span", { children: "VAT (16%)" }),
                    /* @__PURE__ */ jsxs("span", { className: "font-semibold text-foreground", children: [
                      "K ",
                      vat.toFixed(2)
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs(
                    "div",
                    {
                      className: "mt-3 flex items-center justify-between rounded-lg px-3 py-2 text-sm font-bold",
                      style: {
                        backgroundColor: accent,
                        color: primary
                      },
                      children: [
                        /* @__PURE__ */ jsx("span", { children: "GRAND TOTAL" }),
                        /* @__PURE__ */ jsxs("span", { children: [
                          "K ",
                          grand.toFixed(2)
                        ] })
                      ]
                    }
                  )
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "overflow-hidden rounded-xl border", children: [
            /* @__PURE__ */ jsxs(
              "div",
              {
                className: "grid grid-cols-12 gap-2 px-4 py-3 text-xs font-semibold uppercase",
                style: { backgroundColor: accent, color: primary },
                children: [
                  /* @__PURE__ */ jsx("div", { className: "col-span-6", children: "Item Description" }),
                  /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: "Price" }),
                  /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: "Qty" }),
                  /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: "Total" })
                ]
              }
            ),
            items.map((it, idx) => /* @__PURE__ */ jsxs(
              "div",
              {
                className: cn(
                  "grid grid-cols-12 gap-2 px-4 py-3 text-sm",
                  table === "lined" && "border-t",
                  table === "striped" && idx % 2 === 1 && "bg-black/[0.03]",
                  table === "clean" && "border-t border-black/[0.04]"
                ),
                children: [
                  /* @__PURE__ */ jsxs("div", { className: "col-span-6", children: [
                    /* @__PURE__ */ jsx("div", { className: "font-semibold", children: it.desc }),
                    /* @__PURE__ */ jsx("div", { className: "mt-0.5 text-xs text-muted-foreground", children: "Contrary to popular belief Lorem ipsum simply random." })
                  ] }),
                  /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: it.price.toFixed(2) }),
                  /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: it.qty }),
                  /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right font-semibold", children: it.total.toFixed(2) })
                ]
              },
              idx
            ))
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
            /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
              settings.visibility.show_notes && /* @__PURE__ */ jsxs("div", { className: "rounded-xl border p-4", children: [
                /* @__PURE__ */ jsx("div", { className: "text-xs font-semibold text-muted-foreground uppercase", children: "Payment Info" }),
                /* @__PURE__ */ jsxs("div", { className: "mt-2 text-sm text-muted-foreground", children: [
                  "Paypal: paypal@company.com ",
                  /* @__PURE__ */ jsx("br", {}),
                  "Payment: Visa, Master Card ",
                  /* @__PURE__ */ jsx("br", {}),
                  "We accept Cheque"
                ] })
              ] }),
              settings.visibility.show_bank_details && /* @__PURE__ */ jsxs("div", { className: "rounded-xl border p-4", children: [
                /* @__PURE__ */ jsx("div", { className: "text-xs font-semibold text-muted-foreground uppercase", children: "Bank Details" }),
                /* @__PURE__ */ jsxs("div", { className: "mt-2 text-sm text-muted-foreground", children: [
                  "Bank: ",
                  SAMPLE.company.bank.name,
                  /* @__PURE__ */ jsx("br", {}),
                  "Account Name:",
                  " ",
                  SAMPLE.company.bank.account_name,
                  /* @__PURE__ */ jsx("br", {}),
                  "Account No:",
                  " ",
                  SAMPLE.company.bank.account_number,
                  /* @__PURE__ */ jsx("br", {}),
                  "Branch: ",
                  SAMPLE.company.bank.branch
                ] })
              ] }),
              settings.visibility.show_terms && /* @__PURE__ */ jsxs("div", { className: "rounded-xl border p-4", children: [
                /* @__PURE__ */ jsx("div", { className: "text-xs font-semibold text-muted-foreground uppercase", children: "Terms" }),
                /* @__PURE__ */ jsx("div", { className: "mt-2 text-sm whitespace-pre-wrap text-muted-foreground", children: terms || "—" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "rounded-xl border p-4", children: [
              /* @__PURE__ */ jsx("div", { className: "text-xs font-semibold text-muted-foreground uppercase", children: "Thank you for your business!" }),
              /* @__PURE__ */ jsx("div", { className: "mt-2 text-sm text-muted-foreground", children: documentType === "quotation" ? "Thanks for considering this quotation. We are ready to proceed once approved." : SAMPLE.document.notes }),
              settings.visibility.show_signature && /* @__PURE__ */ jsx("div", { className: "mt-6 flex items-end justify-end", children: /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
                /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: SAMPLE.document.signature.name }),
                /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: SAMPLE.document.signature.title }),
                /* @__PURE__ */ jsx("div", { className: "mt-3 text-sm font-semibold italic opacity-70", children: SAMPLE.document.signature.label })
              ] }) })
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "mt-10 text-center text-xs text-muted-foreground", children: footer || "" })
        ] })
      ]
    }
  ) });
}
export {
  InvoiceTemplateBuilder as default
};
