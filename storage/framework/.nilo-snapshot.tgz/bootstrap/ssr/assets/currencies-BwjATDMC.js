import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { Head, useForm, router } from "@inertiajs/react";
import { motion, AnimatePresence } from "framer-motion";
import { Coins, Search, Pencil, Plus, X, Loader2, Trash2 } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import { H as HeadingSmall } from "./heading-small-CT3emyQQ.js";
import { A as AppLayout } from "./app-layout-JvxHjkrs.js";
import { A as AlertDialog, a as AlertDialogTrigger, b as AlertDialogContent, c as AlertDialogHeader, d as AlertDialogTitle, e as AlertDialogDescription, f as AlertDialogFooter, g as AlertDialogCancel, h as AlertDialogAction } from "./alert-dialog-DSahW8tb.js";
import { B as Badge } from "./badge-CfxidL8Q.js";
import { B as Button, c as cn } from "./button-DMGEFYrU.js";
import { C as Card } from "./card-MypPWj87.js";
import { D as Dialog, a as DialogTrigger, b as DialogContent, c as DialogHeader, d as DialogTitle, e as DialogDescription } from "./dialog-Md5slGnn.js";
import { I as Input } from "./input-nVyaPHpJ.js";
import { L as Label } from "./label-BjflLCFy.js";
import { S as Separator } from "./separator-Bcia5PKZ.js";
import { S as Switch } from "./switch-4h1eh9fE.js";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell } from "./table-CSQbiUuL.js";
import "./Chatbot-yoo4250k.js";
import "./app-sidebar-layout-BGzXXcN9.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "@radix-ui/react-alert-dialog";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
import "@radix-ui/react-separator";
import "@radix-ui/react-switch";
const breadcrumbs = [
  {
    title: "Currencies",
    href: "/settings/currencies"
  }
];
function Currencies({ currencies }) {
  const [q, setQ] = useState("");
  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return currencies;
    return currencies.filter(
      (c) => `${c.code} ${c.name} ${c.symbol ?? ""}`.toLowerCase().includes(needle)
    );
  }, [currencies, q]);
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Currencies" }),
    /* @__PURE__ */ jsxs("div", { className: "w-full space-y-6 px-4 py-6", children: [
      /* @__PURE__ */ jsx(
        HeadingSmall,
        {
          title: "Currencies",
          description: "Manage your system currencies (add, edit, activate/deactivate, delete)"
        }
      ),
      /* @__PURE__ */ jsx(
        motion.div,
        {
          initial: { opacity: 0, y: 10 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.25, ease: "easeOut" },
          className: "space-y-4",
          children: /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl bg-background p-4 shadow-sm", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsx("div", { className: "grid h-9 w-9 place-items-center rounded-xl bg-muted", children: /* @__PURE__ */ jsx(Coins, { className: "h-5 w-5 text-foreground/80" }) }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Currency list" }),
                  /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground", children: [
                    filtered.length,
                    " shown •",
                    " ",
                    currencies.length,
                    " total"
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex w-full flex-col gap-2 sm:w-auto sm:flex-row sm:items-center", children: [
                /* @__PURE__ */ jsxs("div", { className: "relative w-full sm:w-72", children: [
                  /* @__PURE__ */ jsx(Search, { className: "pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
                  /* @__PURE__ */ jsx(
                    Input,
                    {
                      value: q,
                      onChange: (e) => setQ(e.target.value),
                      placeholder: "Search code, name, symbol...",
                      className: "pl-9"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsx(CurrencyModal, { mode: "create" })
              ] })
            ] }),
            /* @__PURE__ */ jsx(Separator, { className: "my-4" }),
            /* @__PURE__ */ jsx("div", { className: "w-full overflow-x-auto", children: /* @__PURE__ */ jsxs(Table, { children: [
              /* @__PURE__ */ jsx(TableHeader, { children: /* @__PURE__ */ jsxs(TableRow, { children: [
                /* @__PURE__ */ jsx(TableHead, { className: "w-[18%]", children: "Code" }),
                /* @__PURE__ */ jsx(TableHead, { children: "Name" }),
                /* @__PURE__ */ jsx(TableHead, { className: "w-[12%]", children: "Symbol" }),
                /* @__PURE__ */ jsx(TableHead, { className: "w-[14%]", children: "Precision" }),
                /* @__PURE__ */ jsx(TableHead, { className: "w-[14%]", children: "Status" }),
                /* @__PURE__ */ jsx(TableHead, { className: "w-[22%] text-right", children: "Actions" })
              ] }) }),
              /* @__PURE__ */ jsx(TableBody, { children: filtered.length === 0 ? /* @__PURE__ */ jsx(TableRow, { children: /* @__PURE__ */ jsx(
                TableCell,
                {
                  colSpan: 6,
                  className: "py-12 text-center",
                  children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-sm", children: [
                    /* @__PURE__ */ jsx("div", { className: "mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(Coins, { className: "h-6 w-6 text-foreground/70" }) }),
                    /* @__PURE__ */ jsx("div", { className: "text-sm font-medium", children: "No currencies found" }),
                    /* @__PURE__ */ jsx("div", { className: "mt-1 text-sm text-muted-foreground", children: "Try a different search or add one." }),
                    /* @__PURE__ */ jsx("div", { className: "mt-4 flex justify-center", children: /* @__PURE__ */ jsx(
                      CurrencyModal,
                      {
                        mode: "create",
                        triggerVariant: "outline"
                      }
                    ) })
                  ] })
                }
              ) }) : filtered.map((c, i) => /* @__PURE__ */ jsxs(
                motion.tr,
                {
                  initial: {
                    opacity: 0,
                    y: 10
                  },
                  animate: {
                    opacity: 1,
                    y: 0
                  },
                  transition: {
                    duration: 0.22,
                    delay: Math.min(
                      i * 0.02,
                      0.15
                    )
                  },
                  className: "group",
                  children: [
                    /* @__PURE__ */ jsx(TableCell, { className: "py-4", children: /* @__PURE__ */ jsx(
                      Badge,
                      {
                        variant: "outline",
                        className: "rounded-xl",
                        children: c.code
                      }
                    ) }),
                    /* @__PURE__ */ jsx(TableCell, { className: "py-4", children: /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: c.name }) }),
                    /* @__PURE__ */ jsx(TableCell, { className: "py-4", children: /* @__PURE__ */ jsx("span", { className: "text-sm", children: c.symbol || "—" }) }),
                    /* @__PURE__ */ jsx(TableCell, { className: "py-4", children: /* @__PURE__ */ jsx("span", { className: "text-sm", children: c.precision }) }),
                    /* @__PURE__ */ jsx(TableCell, { className: "py-4", children: /* @__PURE__ */ jsx(
                      Badge,
                      {
                        variant: c.is_active ? "secondary" : "outline",
                        className: "rounded-xl",
                        children: c.is_active ? "Active" : "Inactive"
                      }
                    ) }),
                    /* @__PURE__ */ jsx(TableCell, { className: "py-4 text-right", children: /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-2", children: [
                      /* @__PURE__ */ jsx(
                        CurrencyModal,
                        {
                          mode: "edit",
                          currency: c,
                          trigger: /* @__PURE__ */ jsxs(
                            Button,
                            {
                              variant: "outline",
                              size: "sm",
                              className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                              children: [
                                /* @__PURE__ */ jsx(Pencil, { className: "mr-2 h-4 w-4" }),
                                "Edit"
                              ]
                            }
                          )
                        }
                      ),
                      /* @__PURE__ */ jsx(
                        DeleteCurrencyButton,
                        {
                          currency: c
                        }
                      )
                    ] }) })
                  ]
                },
                c.id
              )) })
            ] }) })
          ] })
        }
      )
    ] })
  ] });
}
function CurrencyModal({
  mode,
  currency,
  triggerVariant = "default",
  trigger
}) {
  const [open, setOpen] = useState(false);
  const form = useForm({
    code: currency?.code ?? "",
    name: currency?.name ?? "",
    symbol: currency?.symbol ?? "",
    precision: currency?.precision ?? 2,
    is_active: currency?.is_active ?? true
  });
  const closeAndReset = () => {
    setOpen(false);
    form.clearErrors();
    if (mode === "create") form.reset();
  };
  const submit = (e) => {
    e.preventDefault();
    const payload = {
      ...form.data,
      code: form.data.code.trim().toUpperCase()
    };
    form.setData(payload);
    if (mode === "create") {
      form.post("/currencies", {
        preserveScroll: true,
        onSuccess: () => {
          toast.success("Currency added.");
          closeAndReset();
        },
        onError: (errors) => toast.error(
          errors?.code || errors?.name || "Failed to add currency."
        )
      });
      return;
    }
    form.put(`/currencies/${currency.id}`, {
      preserveScroll: true,
      onSuccess: () => {
        toast.success("Currency updated.");
        closeAndReset();
      },
      onError: (errors) => toast.error(
        errors?.code || errors?.name || errors?.is_active || "Failed to update currency."
      )
    });
  };
  return /* @__PURE__ */ jsxs(
    Dialog,
    {
      open,
      onOpenChange: (v) => v ? setOpen(true) : closeAndReset(),
      children: [
        /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: trigger ?? /* @__PURE__ */ jsxs(
          Button,
          {
            variant: triggerVariant,
            className: "gap-2 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
            children: [
              /* @__PURE__ */ jsx(Plus, { className: "h-4 w-4" }),
              "Add currency"
            ]
          }
        ) }),
        /* @__PURE__ */ jsx(DialogContent, { className: "overflow-hidden rounded-2xl p-0 sm:max-w-xl", children: /* @__PURE__ */ jsx(AnimatePresence, { mode: "wait", children: /* @__PURE__ */ jsx(
          motion.div,
          {
            initial: { opacity: 0, y: 14, scale: 0.99 },
            animate: { opacity: 1, y: 0, scale: 1 },
            exit: { opacity: 0, y: 10, scale: 0.99 },
            transition: { duration: 0.22, ease: "easeOut" },
            children: /* @__PURE__ */ jsxs("div", { className: "px-6 pt-6 pb-5", children: [
              /* @__PURE__ */ jsxs(DialogHeader, { children: [
                /* @__PURE__ */ jsx(DialogTitle, { children: mode === "create" ? "Add currency" : "Edit currency" }),
                /* @__PURE__ */ jsx(DialogDescription, { children: "Currency codes are ISO 4217 (e.g. ZMW, USD)." })
              ] }),
              /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "mt-6 space-y-4", children: [
                /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsx(Label, { children: "Code *" }),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        value: form.data.code,
                        onChange: (e) => form.setData(
                          "code",
                          e.target.value
                        ),
                        placeholder: "ZMW",
                        maxLength: 3,
                        required: true
                      }
                    ),
                    form.errors.code && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.code })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsx(Label, { children: "Name *" }),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        value: form.data.name,
                        onChange: (e) => form.setData(
                          "name",
                          e.target.value
                        ),
                        placeholder: "Zambian Kwacha",
                        required: true
                      }
                    ),
                    form.errors.name && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.name })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsx(Label, { children: "Symbol" }),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        value: form.data.symbol ?? "",
                        onChange: (e) => form.setData(
                          "symbol",
                          e.target.value
                        ),
                        placeholder: "K"
                      }
                    ),
                    form.errors.symbol && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.symbol })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsx(Label, { children: "Precision *" }),
                    /* @__PURE__ */ jsx(
                      Input,
                      {
                        type: "number",
                        min: 0,
                        max: 6,
                        value: form.data.precision,
                        onChange: (e) => form.setData(
                          "precision",
                          Number(e.target.value)
                        ),
                        required: true
                      }
                    ),
                    form.errors.precision && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.precision })
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between rounded-xl border p-3", children: [
                  /* @__PURE__ */ jsxs("div", { children: [
                    /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Active" }),
                    /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Only active currencies are selectable in the switcher." })
                  ] }),
                  /* @__PURE__ */ jsx(
                    Switch,
                    {
                      checked: !!form.data.is_active,
                      onCheckedChange: (v) => form.setData("is_active", !!v)
                    }
                  )
                ] }),
                form.errors.is_active && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: form.errors.is_active }),
                /* @__PURE__ */ jsx(Separator, {}),
                /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-2", children: [
                  /* @__PURE__ */ jsxs(
                    Button,
                    {
                      type: "button",
                      variant: "ghost",
                      onClick: closeAndReset,
                      disabled: form.processing,
                      className: "rounded-xl",
                      children: [
                        /* @__PURE__ */ jsx(X, { className: "mr-2 h-4 w-4" }),
                        "Cancel"
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    Button,
                    {
                      type: "submit",
                      disabled: form.processing || !form.data.code.trim() || !form.data.name.trim(),
                      className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                      children: form.processing ? /* @__PURE__ */ jsxs(Fragment, { children: [
                        /* @__PURE__ */ jsx(Loader2, { className: "mr-2 h-4 w-4 animate-spin" }),
                        "Saving..."
                      ] }) : "Save"
                    }
                  )
                ] })
              ] })
            ] })
          },
          open ? "open" : "closed"
        ) }) })
      ]
    }
  );
}
function DeleteCurrencyButton({ currency }) {
  const [open, setOpen] = useState(false);
  const del = () => {
    router.delete(`/currencies/${currency.id}`, {
      preserveScroll: true,
      onSuccess: () => {
        toast.success("Currency deleted.");
        setOpen(false);
      },
      onError: (errors) => toast.error(errors?.currency || "Failed to delete currency.")
    });
  };
  return /* @__PURE__ */ jsxs(AlertDialog, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsx(AlertDialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(
      Button,
      {
        variant: "destructive",
        size: "sm",
        className: "rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
        children: [
          /* @__PURE__ */ jsx(Trash2, { className: "mr-2 h-4 w-4" }),
          "Delete"
        ]
      }
    ) }),
    /* @__PURE__ */ jsxs(AlertDialogContent, { className: "rounded-2xl", children: [
      /* @__PURE__ */ jsxs(AlertDialogHeader, { children: [
        /* @__PURE__ */ jsx(AlertDialogTitle, { children: "Delete currency?" }),
        /* @__PURE__ */ jsxs(AlertDialogDescription, { children: [
          "This will permanently remove",
          " ",
          /* @__PURE__ */ jsx("span", { className: "font-medium", children: currency.code }),
          "."
        ] })
      ] }),
      /* @__PURE__ */ jsxs(AlertDialogFooter, { children: [
        /* @__PURE__ */ jsx(AlertDialogCancel, { className: "rounded-xl", children: "Cancel" }),
        /* @__PURE__ */ jsx(
          AlertDialogAction,
          {
            onClick: del,
            className: cn(
              "rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90"
            ),
            children: "Delete"
          }
        )
      ] })
    ] })
  ] });
}
export {
  Currencies as default
};
