import { jsxs, jsx } from "react/jsx-runtime";
import { A as AppSidebarLayout } from "./app-sidebar-layout-BGzXXcN9.js";
import { B as Button } from "./button-DMGEFYrU.js";
import { Head, Link } from "@inertiajs/react";
import { Crown, ArrowUpRight } from "lucide-react";
import "react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "sonner";
import "clsx";
import "tailwind-merge";
const breadcrumbs = [
  { title: "Subscription", href: "/subscription" }
];
function UsageBar({ label, used, limit }) {
  const isUnlimited = limit === -1;
  const percentage = isUnlimited ? 0 : limit > 0 ? Math.min(used / limit * 100, 100) : 0;
  const isNearLimit = !isUnlimited && percentage >= 80;
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-1 flex items-center justify-between text-sm", children: [
      /* @__PURE__ */ jsx("span", { className: "font-medium text-slate-700 dark:text-slate-300", children: label }),
      /* @__PURE__ */ jsxs("span", { className: "text-slate-500 dark:text-slate-400", children: [
        used,
        " / ",
        isUnlimited ? "∞" : limit
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "h-2 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-700", children: /* @__PURE__ */ jsx(
      "div",
      {
        className: `h-full rounded-full transition-all ${isNearLimit ? "bg-amber-500" : "bg-blue-500"}`,
        style: { width: isUnlimited ? "5%" : `${Math.max(percentage, 2)}%` }
      }
    ) })
  ] });
}
function Current({ subscription, usage, plans }) {
  const plan = subscription?.plan;
  return /* @__PURE__ */ jsxs(AppSidebarLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "My Subscription" }),
    /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-3xl space-y-6 p-6", children: [
      /* @__PURE__ */ jsx("div", { className: "rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold text-slate-900 dark:text-white", children: "Current Plan" }),
          /* @__PURE__ */ jsxs("div", { className: "mt-1 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Crown, { className: "h-5 w-5 text-blue-500" }),
            /* @__PURE__ */ jsx("span", { className: "text-2xl font-bold text-slate-900 dark:text-white", children: plan?.name ?? "No Plan" })
          ] }),
          subscription && /* @__PURE__ */ jsxs("p", { className: "mt-1 text-sm text-slate-500 dark:text-slate-400", children: [
            "Status: ",
            /* @__PURE__ */ jsx("span", { className: "font-medium capitalize", children: subscription.status }),
            subscription.status === "pending_payment" && /* @__PURE__ */ jsxs("span", { className: "ml-2 text-amber-600 dark:text-amber-400", children: [
              "— ",
              /* @__PURE__ */ jsx(Link, { href: "/subscription/payment-status", className: "underline", children: "Check payment status" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx(Button, { asChild: true, variant: "outline", children: /* @__PURE__ */ jsxs(Link, { href: "/subscription/select", children: [
          /* @__PURE__ */ jsx(ArrowUpRight, { className: "mr-1 h-4 w-4" }),
          "Upgrade"
        ] }) })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: [
        /* @__PURE__ */ jsx("h2", { className: "mb-4 text-lg font-semibold text-slate-900 dark:text-white", children: "Usage" }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsx(UsageBar, { label: "Companies", used: usage.companies.used, limit: usage.companies.limit }),
          /* @__PURE__ */ jsx(UsageBar, { label: "Invoices", used: usage.invoices.used, limit: usage.invoices.limit }),
          /* @__PURE__ */ jsx(UsageBar, { label: "Quotations", used: usage.quotations.used, limit: usage.quotations.limit }),
          /* @__PURE__ */ jsx(UsageBar, { label: "Invoice Templates", used: usage.invoice_templates.used, limit: usage.invoice_templates.limit }),
          /* @__PURE__ */ jsx(UsageBar, { label: "Quotation Templates", used: usage.quotation_templates.used, limit: usage.quotation_templates.limit })
        ] })
      ] })
    ] })
  ] });
}
export {
  Current as default
};
