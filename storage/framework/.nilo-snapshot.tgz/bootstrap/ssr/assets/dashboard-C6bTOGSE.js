import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { usePage, Head, Link } from "@inertiajs/react";
import { TrendingUp, CheckCircle2, Clock3, FileText, Users, CalendarDays, Search } from "lucide-react";
import * as React from "react";
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend, LineChart, CartesianGrid, XAxis, YAxis, Line, BarChart, Bar } from "recharts";
import { A as AppLayout } from "./app-layout-JvxHjkrs.js";
import { d as dashboard } from "./index-NXMefbOa.js";
import { B as Button, c as cn } from "./button-DMGEFYrU.js";
import { C as Card } from "./card-MypPWj87.js";
import { I as Input } from "./input-nVyaPHpJ.js";
import "./Chatbot-yoo4250k.js";
import "./app-sidebar-layout-BGzXXcN9.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-DPKrZTLE.js";
import "sonner";
import "clsx";
import "tailwind-merge";
const breadcrumbs = [
  { title: "Dashboard", href: dashboard().url }
];
const PIE_COLORS = ["#0ea5e9", "#f59e0b"];
function Dashboard() {
  const { company, stats, charts, calendar, recent_invoices, top_clients } = usePage().props;
  const baseCurrency = stats?.currency_code ?? "ZMW";
  const precision = Number.isFinite(Number(stats?.precision)) ? Number(stats?.precision) : 2;
  const money = React.useCallback(
    (n, code) => `${code ?? baseCurrency} ${Number.isFinite(n) ? n.toFixed(precision) : 0 .toFixed(precision)}`,
    [baseCurrency, precision]
  );
  const paidPendingPie = React.useMemo(() => {
    if (!charts?.paid_vs_pending) return [];
    return charts.paid_vs_pending.labels.map((name, idx) => ({
      name,
      value: charts.paid_vs_pending.counts[idx] ?? 0,
      revenue: charts.paid_vs_pending.revenue[idx] ?? 0
    }));
  }, [charts?.paid_vs_pending]);
  const monthlyTrend = React.useMemo(() => {
    if (!charts?.monthly_trend) return [];
    return charts.monthly_trend.labels.map((label, idx) => ({
      name: label,
      paid: charts.monthly_trend.paid[idx] ?? 0,
      pending: charts.monthly_trend.pending[idx] ?? 0
    }));
  }, [charts?.monthly_trend]);
  const agingBars = React.useMemo(() => {
    const a = charts?.aging;
    if (!a) return [];
    return [
      {
        name: "Overdue",
        amount: a.overdue.amount,
        count: a.overdue.count
      },
      {
        name: "Due ≤7d",
        amount: a.due_in_7_days.amount,
        count: a.due_in_7_days.count
      },
      {
        name: "Due later",
        amount: a.due_later.amount,
        count: a.due_later.count
      },
      {
        name: "No due",
        amount: a.no_due_date.amount,
        count: a.no_due_date.count
      }
    ];
  }, [charts?.aging]);
  const [tableFilter, setTableFilter] = React.useState("all");
  const [query, setQuery] = React.useState("");
  const [sortKey, setSortKey] = React.useState("due_date");
  const [sortDir, setSortDir] = React.useState("asc");
  const todayIso = React.useMemo(
    () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
    []
  );
  const filteredRecent = React.useMemo(() => {
    const list = recent_invoices ?? [];
    const byStatus = tableFilter === "all" ? list : tableFilter === "overdue" ? list.filter(
      (i) => i.status === "pending" && !!i.due_date && i.due_date < todayIso
    ) : list.filter((i) => i.status === tableFilter);
    const q = query.trim().toLowerCase();
    const byQuery = !q ? byStatus : byStatus.filter((inv) => {
      const num = (inv.number ?? `#${inv.id}`).toLowerCase();
      const client = (inv.client?.name ?? "").toLowerCase();
      return num.includes(q) || client.includes(q);
    });
    const sorted = [...byQuery].sort((a, b) => {
      const dir = sortDir === "asc" ? 1 : -1;
      if (sortKey === "total") {
        return (a.total - b.total) * dir;
      }
      if (sortKey === "status") {
        const av = a.status === "pending" ? 0 : 1;
        const bv = b.status === "pending" ? 0 : 1;
        return (av - bv) * dir;
      }
      const ad = a.due_date ?? "9999-12-31";
      const bd = b.due_date ?? "9999-12-31";
      return ad.localeCompare(bd) * dir;
    });
    return sorted;
  }, [recent_invoices, tableFilter, query, sortKey, sortDir, todayIso]);
  const monthKey = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  const [calMonth, setCalMonth] = React.useState(() => monthKey(/* @__PURE__ */ new Date()));
  const [selectedDay, setSelectedDay] = React.useState(null);
  const monthDays = React.useMemo(() => {
    const [y, m] = calMonth.split("-").map(Number);
    const first = new Date(y, m - 1, 1);
    const last = new Date(y, m, 0);
    const start = new Date(first);
    const day = start.getDay();
    const shift = day === 0 ? 6 : day - 1;
    start.setDate(start.getDate() - shift);
    const days = [];
    const cursor = new Date(start);
    while (cursor <= last || cursor.getDay() !== 1) {
      const iso = cursor.toISOString().slice(0, 10);
      days.push({ date: new Date(cursor), iso });
      cursor.setDate(cursor.getDate() + 1);
      if (days.length > 42) break;
    }
    return days;
  }, [calMonth]);
  const eventsByDate = React.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    (calendar ?? []).forEach((ev) => {
      if (!map.has(ev.date)) map.set(ev.date, []);
      map.get(ev.date).push(ev);
    });
    for (const [k, arr] of map) {
      arr.sort((a, b) => {
        if (a.status !== b.status)
          return a.status === "pending" ? -1 : 1;
        return (b.amount ?? 0) - (a.amount ?? 0);
      });
      map.set(k, arr);
    }
    return map;
  }, [calendar]);
  const monthSummary = React.useMemo(() => {
    const [y, m] = calMonth.split("-").map(Number);
    const start = new Date(y, m - 1, 1).toISOString().slice(0, 10);
    const end = new Date(y, m, 0).toISOString().slice(0, 10);
    let pendingDue = 0;
    (calendar ?? []).forEach((ev) => {
      if (ev.date >= start && ev.date <= end && ev.status === "pending") {
        pendingDue += ev.amount ?? 0;
      }
    });
    return {
      pendingDue,
      overdueInMonth: stats?.overdue_revenue ?? 0
    };
  }, [calMonth, calendar, stats?.overdue_revenue]);
  const goMonth = (dir) => {
    const [y, m] = calMonth.split("-").map(Number);
    const d = new Date(y, m - 1, 1);
    d.setMonth(d.getMonth() + dir);
    setCalMonth(monthKey(d));
    setSelectedDay(null);
  };
  const selectedEvents = React.useMemo(() => {
    if (!selectedDay) return [];
    return eventsByDate.get(selectedDay) ?? [];
  }, [selectedDay, eventsByDate]);
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Dashboard" }),
    /* @__PURE__ */ jsxs("div", { className: "mx-auto w-full px-4 py-8 sm:px-6", children: [
      /* @__PURE__ */ jsx(DashboardHeader, { company, stats }),
      /* @__PURE__ */ jsx(StatsGrid, { stats, money }),
      /* @__PURE__ */ jsxs("div", { className: "mt-6 grid grid-cols-1 gap-6 lg:grid-cols-12", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-6 lg:col-span-7", children: [
          /* @__PURE__ */ jsx(
            PaidPendingCard,
            {
              paidPendingPie,
              stats,
              money
            }
          ),
          /* @__PURE__ */ jsx(
            MonthlyTrendCard,
            {
              monthlyTrend,
              money
            }
          ),
          /* @__PURE__ */ jsx(AgingBucketsCard, { agingBars, money })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-6 lg:col-span-5", children: [
          /* @__PURE__ */ jsx(
            CalendarCard,
            {
              calMonth,
              goMonth,
              monthSummary,
              monthDays,
              eventsByDate,
              selectedDay,
              setSelectedDay,
              selectedEvents,
              money,
              baseCurrency,
              todayIso
            }
          ),
          /* @__PURE__ */ jsx(
            RecentInvoicesCard,
            {
              invoices: filteredRecent,
              tableFilter,
              setTableFilter,
              query,
              setQuery,
              sortKey,
              setSortKey,
              sortDir,
              setSortDir,
              money
            }
          ),
          /* @__PURE__ */ jsx(
            TopClientsCard,
            {
              topClients: top_clients ?? [],
              money
            }
          )
        ] })
      ] })
    ] })
  ] });
}
function DashboardHeader({
  company,
  stats
}) {
  return /* @__PURE__ */ jsxs("div", { className: "mb-6 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
      /* @__PURE__ */ jsx("div", { className: "grid h-11 w-11 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(TrendingUp, { className: "h-6 w-6 text-foreground/80" }) }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight sm:text-3xl", children: "Dashboard" }),
        /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: company ? /* @__PURE__ */ jsxs(Fragment, { children: [
          "Company:",
          " ",
          /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: company.name }),
          stats?.as_of ? /* @__PURE__ */ jsxs("span", { className: "text-muted-foreground", children: [
            " ",
            "• As of ",
            stats.as_of
          ] }) : null
        ] }) : "No active company selected." })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx(Button, { asChild: true, className: "rounded-xl", children: /* @__PURE__ */ jsx(Link, { href: "/invoices/create", children: "Create invoice" }) }),
      /* @__PURE__ */ jsx(Button, { variant: "outline", asChild: true, className: "rounded-xl", children: /* @__PURE__ */ jsx(Link, { href: "/invoices", children: "View invoices" }) })
    ] })
  ] });
}
function StatsGrid({
  stats,
  money
}) {
  return /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 md:grid-cols-4", children: [
    /* @__PURE__ */ jsx(
      StatCard,
      {
        icon: CheckCircle2,
        title: "Paid revenue",
        value: money(stats?.paid_revenue ?? 0),
        sub: `${stats?.paid_count ?? 0} invoices`
      }
    ),
    /* @__PURE__ */ jsx(
      StatCard,
      {
        icon: Clock3,
        title: "Pending revenue",
        value: money(stats?.pending_revenue ?? 0),
        sub: `${stats?.pending_count ?? 0} invoices`,
        tone: "amber"
      }
    ),
    /* @__PURE__ */ jsx(
      StatCard,
      {
        icon: FileText,
        title: "Overdue",
        value: money(stats?.overdue_revenue ?? 0),
        sub: "Pending past due date",
        tone: "rose"
      }
    ),
    /* @__PURE__ */ jsx(
      StatCard,
      {
        icon: Users,
        title: "Clients",
        value: `${stats?.client_count ?? 0}`,
        sub: `${stats?.total_invoices ?? 0} invoices total`
      }
    )
  ] });
}
function PaidPendingCard({
  paidPendingPie,
  stats,
  money
}) {
  return /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-4 flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Paid vs Pending" }),
        /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Counts and revenue split." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground", children: [
        "Paid: ",
        money(stats?.paid_revenue ?? 0),
        " • Pending:",
        " ",
        money(stats?.pending_revenue ?? 0)
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-6 md:grid-cols-2", children: [
      /* @__PURE__ */ jsx("div", { className: "h-[240px]", children: /* @__PURE__ */ jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxs(PieChart, { children: [
        /* @__PURE__ */ jsx(
          Pie,
          {
            data: paidPendingPie,
            dataKey: "value",
            nameKey: "name",
            cx: "50%",
            cy: "50%",
            outerRadius: 80,
            label: true,
            children: paidPendingPie.map((_, idx) => /* @__PURE__ */ jsx(
              Cell,
              {
                fill: PIE_COLORS[idx % PIE_COLORS.length]
              },
              idx
            ))
          }
        ),
        /* @__PURE__ */ jsx(
          Tooltip,
          {
            formatter: (value, name, props) => {
              const rev = props?.payload?.revenue ?? 0;
              return [`${value} • ${money(rev)}`, name];
            }
          }
        ),
        /* @__PURE__ */ jsx(Legend, {})
      ] }) }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex h-[240px] flex-col gap-3 overflow-hidden", children: [
        /* @__PURE__ */ jsx(
          InsightRow,
          {
            label: "Due in 7 days",
            value: money(stats?.due_in_7_revenue ?? 0),
            hint: "Pending invoices due soon"
          }
        ),
        /* @__PURE__ */ jsx(
          InsightRow,
          {
            label: "Overdue",
            value: money(stats?.overdue_revenue ?? 0),
            hint: "Pending invoices past due date",
            danger: true
          }
        ),
        /* @__PURE__ */ jsx(
          InsightRow,
          {
            label: "Pending total",
            value: money(stats?.pending_revenue ?? 0),
            hint: "All pending invoices"
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "mt-auto text-xs text-muted-foreground", children: [
          "Tip: keep invoices",
          " ",
          /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: "pending" }),
          " ",
          "until payment is confirmed."
        ] })
      ] })
    ] })
  ] });
}
function MonthlyTrendCard({
  monthlyTrend,
  money
}) {
  return /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Monthly trend" }),
      /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Last 12 months paid vs pending totals." })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "h-[280px]", children: /* @__PURE__ */ jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxs(LineChart, { data: monthlyTrend, children: [
      /* @__PURE__ */ jsx(CartesianGrid, { strokeDasharray: "3 3" }),
      /* @__PURE__ */ jsx(
        XAxis,
        {
          dataKey: "name",
          tick: { fontSize: 12 },
          interval: 2
        }
      ),
      /* @__PURE__ */ jsx(YAxis, { tick: { fontSize: 12 } }),
      /* @__PURE__ */ jsx(
        Tooltip,
        {
          formatter: (v, k) => [
            money(Number(v)),
            String(k).toUpperCase()
          ]
        }
      ),
      /* @__PURE__ */ jsx(Legend, {}),
      /* @__PURE__ */ jsx(
        Line,
        {
          type: "monotone",
          dataKey: "paid",
          strokeWidth: 2,
          dot: false
        }
      ),
      /* @__PURE__ */ jsx(
        Line,
        {
          type: "monotone",
          dataKey: "pending",
          strokeWidth: 2,
          dot: false
        }
      )
    ] }) }) })
  ] });
}
function AgingBucketsCard({
  agingBars,
  money
}) {
  return /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Aging buckets" }),
      /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Where your receivables are sitting." })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "h-[260px]", children: /* @__PURE__ */ jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxs(BarChart, { data: agingBars, children: [
      /* @__PURE__ */ jsx(CartesianGrid, { strokeDasharray: "3 3" }),
      /* @__PURE__ */ jsx(XAxis, { dataKey: "name", tick: { fontSize: 12 } }),
      /* @__PURE__ */ jsx(YAxis, { tick: { fontSize: 12 } }),
      /* @__PURE__ */ jsx(
        Tooltip,
        {
          formatter: (v, k, props) => {
            const c = props?.payload?.count ?? 0;
            return [
              `${money(Number(v))} • ${c} invoices`,
              k
            ];
          }
        }
      ),
      /* @__PURE__ */ jsx(Legend, {}),
      /* @__PURE__ */ jsx(Bar, { dataKey: "amount" })
    ] }) }) })
  ] });
}
function CalendarCard({
  calMonth,
  goMonth,
  monthSummary,
  monthDays,
  eventsByDate,
  selectedDay,
  setSelectedDay,
  selectedEvents,
  money,
  baseCurrency,
  todayIso
}) {
  return /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-4 flex items-start justify-between gap-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(CalendarDays, { className: "h-5 w-5 opacity-80" }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Due dates calendar" }),
          /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Click a day to see invoices due." })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(
          Button,
          {
            type: "button",
            variant: "outline",
            className: "h-9 rounded-xl px-3",
            onClick: () => goMonth(-1),
            children: "Prev"
          }
        ),
        /* @__PURE__ */ jsx(
          Button,
          {
            type: "button",
            variant: "outline",
            className: "h-9 rounded-xl px-3",
            onClick: () => goMonth(1),
            children: "Next"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mb-4 rounded-2xl border bg-muted/20 p-4", children: [
      /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Selected month" }),
      /* @__PURE__ */ jsx("div", { className: "mt-1 text-sm font-semibold", children: calMonth }),
      /* @__PURE__ */ jsxs("div", { className: "mt-2 grid grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsx(
          MiniInfo,
          {
            label: "Pending due this month",
            value: money(monthSummary.pendingDue, baseCurrency)
          }
        ),
        /* @__PURE__ */ jsx(
          MiniInfo,
          {
            label: "Overdue (overall)",
            value: money(monthSummary.overdueInMonth, baseCurrency),
            danger: true
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "grid grid-cols-7 gap-2 text-xs", children: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => /* @__PURE__ */ jsx("div", { className: "px-1 text-muted-foreground", children: d }, d)) }),
    /* @__PURE__ */ jsxs("div", { className: "mt-2 grid grid-cols-1 gap-4", children: [
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-7 gap-2", children: monthDays.map(({ date, iso }) => {
        const evs = eventsByDate.get(iso) ?? [];
        const [y, m] = calMonth.split("-").map(Number);
        const inMonth = date.getFullYear() === y && date.getMonth() === m - 1;
        const pendingTotal = evs.filter((e) => e.status === "pending").reduce((a, b) => a + (b.amount ?? 0), 0);
        const isToday = iso === todayIso;
        const isSelected = selectedDay === iso;
        return /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            onClick: () => setSelectedDay(isSelected ? null : iso),
            className: cn(
              "min-h-[76px] rounded-xl border p-2 text-left transition",
              !inMonth && "opacity-50",
              isToday && "border-foreground/40",
              isSelected && "bg-muted/40",
              "hover:bg-muted/30"
            ),
            children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsx("div", { className: "text-xs font-semibold", children: date.getDate() }),
                evs.length > 0 ? /* @__PURE__ */ jsx("span", { className: "rounded-full bg-muted px-2 py-0.5 text-[10px] font-semibold text-muted-foreground", children: evs.length }) : null
              ] }),
              pendingTotal > 0 ? /* @__PURE__ */ jsx("div", { className: "mt-2 rounded-lg bg-amber-500/10 px-2 py-1 text-[10px] font-semibold text-amber-700", children: money(
                pendingTotal,
                evs[0]?.currency_code
              ) }) : evs.some((e) => e.status === "paid") ? /* @__PURE__ */ jsx("div", { className: "mt-2 rounded-lg bg-emerald-500/10 px-2 py-1 text-[10px] font-semibold text-emerald-700", children: "Paid due" }) : null,
              evs[0] ? /* @__PURE__ */ jsx("div", { className: "mt-2 truncate text-[10px] text-muted-foreground", children: evs[0].title }) : null
            ]
          },
          iso
        );
      }) }),
      /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border p-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "mb-2 flex items-center justify-between", children: [
          /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: selectedDay ? `Due on ${selectedDay}` : "Select a day" }),
          selectedDay ? /* @__PURE__ */ jsx(
            Button,
            {
              type: "button",
              variant: "outline",
              className: "h-8 rounded-xl px-3 text-xs",
              onClick: () => setSelectedDay(null),
              children: "Clear"
            }
          ) : null
        ] }),
        selectedDay ? /* @__PURE__ */ jsx("div", { className: "max-h-[220px] space-y-2 overflow-auto pr-1", children: selectedEvents.length ? selectedEvents.map((ev) => /* @__PURE__ */ jsxs(
          Link,
          {
            href: ev.url,
            className: "flex items-center justify-between rounded-xl border p-3 transition hover:bg-muted/30",
            children: [
              /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsx("div", { className: "truncate text-sm font-semibold", children: ev.title }),
                /* @__PURE__ */ jsx("div", { className: "mt-1 text-xs text-muted-foreground", children: /* @__PURE__ */ jsx(
                  StatusPill,
                  {
                    status: ev.status
                  }
                ) })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "shrink-0 text-sm font-semibold", children: money(ev.amount, ev.currency_code) })
            ]
          },
          ev.id
        )) : /* @__PURE__ */ jsx("div", { className: "rounded-xl border p-4 text-sm text-muted-foreground", children: "No invoices due on this day." }) }) : /* @__PURE__ */ jsx("div", { className: "text-sm text-muted-foreground", children: "Tip: you can use this to plan collections and spot due spikes." })
      ] })
    ] })
  ] });
}
function RecentInvoicesCard({
  invoices,
  tableFilter,
  setTableFilter,
  query,
  setQuery,
  sortKey,
  setSortKey,
  sortDir,
  setSortDir,
  money
}) {
  const toggleSort = (k) => {
    if (sortKey !== k) {
      setSortKey(k);
      setSortDir("asc");
      return;
    }
    setSortDir(sortDir === "asc" ? "desc" : "asc");
  };
  return /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-4 flex flex-col gap-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Recent invoices" }),
          /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Search, filter, and sort." })
        ] }),
        /* @__PURE__ */ jsx(Button, { variant: "outline", asChild: true, className: "rounded-xl", children: /* @__PURE__ */ jsx(Link, { href: "/invoices", children: "Open invoices" }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between", children: [
        /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2", children: ["all", "paid", "pending", "overdue"].map(
          (k) => /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: () => setTableFilter(k),
              className: cn(
                "rounded-xl border px-3 py-1.5 text-xs font-semibold transition",
                tableFilter === k ? "bg-foreground text-background" : "bg-background hover:bg-muted/40"
              ),
              children: k === "all" ? "All" : k
            },
            k
          )
        ) }),
        /* @__PURE__ */ jsxs("div", { className: "relative w-full sm:w-[260px]", children: [
          /* @__PURE__ */ jsx(Search, { className: "pointer-events-none absolute top-2.5 left-3 h-4 w-4 text-muted-foreground" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              value: query,
              onChange: (e) => setQuery(e.target.value),
              className: "h-9 rounded-xl pl-9",
              placeholder: "Search invoice or client..."
            }
          )
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "max-h-[320px] overflow-auto pr-1", children: /* @__PURE__ */ jsxs("table", { className: "min-w-full text-sm", children: [
      /* @__PURE__ */ jsx("thead", { className: "sticky top-0 bg-background", children: /* @__PURE__ */ jsxs("tr", { className: "border-b text-left text-xs text-muted-foreground", children: [
        /* @__PURE__ */ jsx("th", { className: "py-2 pr-4", children: "Invoice" }),
        /* @__PURE__ */ jsx("th", { className: "py-2 pr-4", children: "Client" }),
        /* @__PURE__ */ jsxs(
          "th",
          {
            className: "cursor-pointer py-2 pr-4 select-none",
            onClick: () => toggleSort("due_date"),
            children: [
              "Due",
              " ",
              sortKey === "due_date" ? sortDir === "asc" ? "↑" : "↓" : ""
            ]
          }
        ),
        /* @__PURE__ */ jsxs(
          "th",
          {
            className: "cursor-pointer py-2 pr-4 text-right select-none",
            onClick: () => toggleSort("total"),
            children: [
              "Total",
              " ",
              sortKey === "total" ? sortDir === "asc" ? "↑" : "↓" : ""
            ]
          }
        ),
        /* @__PURE__ */ jsxs(
          "th",
          {
            className: "cursor-pointer py-2 pr-0 text-right select-none",
            onClick: () => toggleSort("status"),
            children: [
              "Status",
              " ",
              sortKey === "status" ? sortDir === "asc" ? "↑" : "↓" : ""
            ]
          }
        )
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { children: invoices.length ? invoices.map((inv) => /* @__PURE__ */ jsxs(
        "tr",
        {
          className: "border-b last:border-0",
          children: [
            /* @__PURE__ */ jsxs("td", { className: "py-2 pr-4", children: [
              /* @__PURE__ */ jsx(
                Link,
                {
                  href: `/invoices/${inv.id}`,
                  className: "font-semibold underline-offset-2 hover:underline",
                  children: inv.number ?? `#${inv.id}`
                }
              ),
              /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground", children: [
                "Issued ",
                inv.issue_date
              ] })
            ] }),
            /* @__PURE__ */ jsx("td", { className: "py-2 pr-4", children: inv.client?.name ?? "—" }),
            /* @__PURE__ */ jsx("td", { className: "py-2 pr-4", children: inv.due_date ?? "—" }),
            /* @__PURE__ */ jsx("td", { className: "py-2 pr-4 text-right font-semibold", children: money(inv.total, inv.currency_code) }),
            /* @__PURE__ */ jsx("td", { className: "py-2 pr-0 text-right", children: /* @__PURE__ */ jsx(StatusPill, { status: inv.status }) })
          ]
        },
        inv.id
      )) : /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx(
        "td",
        {
          colSpan: 5,
          className: "py-8 text-center text-sm text-muted-foreground",
          children: "No invoices found."
        }
      ) }) })
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "mt-4 text-xs text-muted-foreground", children: [
      "Showing ",
      invoices.length,
      " invoices"
    ] })
  ] });
}
function TopClientsCard({
  topClients,
  money
}) {
  return /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: "Top clients (pending)" }),
      /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Biggest outstanding balances right now." })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "max-h-[260px] space-y-3 overflow-auto pr-1", children: topClients.length ? topClients.map((c) => /* @__PURE__ */ jsxs(
      Link,
      {
        href: `/invoices?client_id=${c.client_id}&status=pending`,
        className: "flex items-center justify-between rounded-xl border p-3 transition hover:bg-muted/30",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsx("div", { className: "truncate text-sm font-semibold", children: c.name }),
            /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Outstanding" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: money(c.pending_total) })
        ]
      },
      c.client_id
    )) : /* @__PURE__ */ jsx("div", { className: "rounded-xl border p-4 text-sm text-muted-foreground", children: "No pending balances yet." }) })
  ] });
}
function StatCard({
  icon: Icon,
  title,
  value,
  sub,
  tone
}) {
  const toneCls = tone === "amber" ? "bg-amber-500/10 text-amber-700" : tone === "rose" ? "bg-rose-500/10 text-rose-700" : "bg-emerald-500/10 text-emerald-700";
  return /* @__PURE__ */ jsx(Card, { className: "rounded-2xl border bg-background p-5 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
    /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
      /* @__PURE__ */ jsx("div", { className: "text-xs font-semibold text-muted-foreground", children: title }),
      /* @__PURE__ */ jsx("div", { className: "mt-1 truncate text-2xl font-semibold tracking-tight", children: value }),
      /* @__PURE__ */ jsx("div", { className: "mt-1 text-xs text-muted-foreground", children: sub })
    ] }),
    /* @__PURE__ */ jsx(
      "div",
      {
        className: cn(
          "grid h-10 w-10 place-items-center rounded-2xl",
          toneCls
        ),
        children: /* @__PURE__ */ jsx(Icon, { className: "h-5 w-5" })
      }
    )
  ] }) });
}
function StatusPill({ status }) {
  const isPaid = status === "paid";
  return /* @__PURE__ */ jsxs(
    "span",
    {
      className: cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold capitalize",
        isPaid ? "bg-emerald-500/10 text-emerald-700" : "bg-amber-500/10 text-amber-700"
      ),
      children: [
        isPaid ? /* @__PURE__ */ jsx(CheckCircle2, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ jsx(Clock3, { className: "h-3.5 w-3.5" }),
        status
      ]
    }
  );
}
function InsightRow({
  label,
  value,
  hint,
  danger
}) {
  return /* @__PURE__ */ jsxs("div", { className: "rounded-xl border p-3", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: label }),
      /* @__PURE__ */ jsx(
        "div",
        {
          className: cn(
            "text-sm font-semibold",
            danger && "text-rose-700"
          ),
          children: value
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "mt-1 text-xs text-muted-foreground", children: hint })
  ] });
}
function MiniInfo({
  label,
  value,
  danger
}) {
  return /* @__PURE__ */ jsxs("div", { className: "rounded-xl border bg-background p-3", children: [
    /* @__PURE__ */ jsx("div", { className: "text-[11px] text-muted-foreground", children: label }),
    /* @__PURE__ */ jsx(
      "div",
      {
        className: cn(
          "mt-1 text-sm font-semibold",
          danger && "text-rose-700"
        ),
        children: value
      }
    )
  ] });
}
export {
  Dashboard as default
};
