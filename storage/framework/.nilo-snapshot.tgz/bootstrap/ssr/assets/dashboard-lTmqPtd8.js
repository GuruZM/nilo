import { jsxs, jsx } from "react/jsx-runtime";
import { A as AppSidebarLayout } from "./app-sidebar-layout-BGzXXcN9.js";
import { Head, Link } from "@inertiajs/react";
import { Users, CreditCard, DollarSign, MessageSquare } from "lucide-react";
import "react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "./button-DMGEFYrU.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "sonner";
const breadcrumbs = [
  { title: "Admin", href: "/admin" },
  { title: "Dashboard", href: "/admin" }
];
function Dashboard({ stats, planStats, recentUsers }) {
  const statCards = [
    { label: "Total Users", value: stats.totalUsers, icon: Users, href: "/admin/users", color: "text-blue-500" },
    { label: "Pending Payments", value: stats.pendingPayments, icon: CreditCard, href: "/admin/payments", color: "text-amber-500" },
    { label: "Total Revenue", value: `K${Number(stats.confirmedRevenue).toLocaleString()}`, icon: DollarSign, href: "/admin/payments?status=confirmed", color: "text-green-500" },
    { label: "Pending Inquiries", value: stats.pendingInquiries, icon: MessageSquare, href: "/admin/inquiries", color: "text-purple-500" }
  ];
  return /* @__PURE__ */ jsxs(AppSidebarLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Admin Dashboard" }),
    /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-6xl space-y-6 p-6", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-slate-900 dark:text-white", children: "Admin Dashboard" }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4", children: statCards.map((stat) => /* @__PURE__ */ jsxs(
        Link,
        {
          href: stat.href,
          className: "rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition-shadow hover:shadow-md dark:border-slate-700 dark:bg-slate-800",
          children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx(stat.icon, { className: `h-5 w-5 ${stat.color}` }),
              /* @__PURE__ */ jsx("span", { className: "text-sm text-slate-500 dark:text-slate-400", children: stat.label })
            ] }),
            /* @__PURE__ */ jsx("p", { className: "mt-2 text-2xl font-bold text-slate-900 dark:text-white", children: stat.value })
          ]
        },
        stat.label
      )) }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-6 lg:grid-cols-2", children: [
        /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: [
          /* @__PURE__ */ jsx("h2", { className: "mb-4 text-lg font-semibold text-slate-900 dark:text-white", children: "Users by Plan" }),
          /* @__PURE__ */ jsx("div", { className: "space-y-3", children: planStats.map((plan) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsx("span", { className: "text-sm font-medium text-slate-700 dark:text-slate-300", children: plan.name }),
            /* @__PURE__ */ jsx("span", { className: "rounded-full bg-slate-100 px-3 py-1 text-sm font-semibold text-slate-800 dark:bg-slate-700 dark:text-slate-200", children: plan.subscriptions_count })
          ] }, plan.id)) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-4 flex items-center justify-between", children: [
            /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold text-slate-900 dark:text-white", children: "Recent Users" }),
            /* @__PURE__ */ jsx(Link, { href: "/admin/users", className: "text-sm text-blue-500 hover:text-blue-600", children: "View all" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "space-y-3", children: recentUsers.map((user) => /* @__PURE__ */ jsxs(
            Link,
            {
              href: `/admin/users/${user.id}`,
              className: "flex items-center justify-between rounded-lg p-2 transition-colors hover:bg-slate-50 dark:hover:bg-slate-700",
              children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("p", { className: "text-sm font-medium text-slate-900 dark:text-white", children: user.name }),
                  /* @__PURE__ */ jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: user.email })
                ] }),
                /* @__PURE__ */ jsx("span", { className: "text-xs text-slate-400", children: new Date(user.created_at).toLocaleDateString() })
              ]
            },
            user.id
          )) })
        ] })
      ] })
    ] })
  ] });
}
export {
  Dashboard as default
};
