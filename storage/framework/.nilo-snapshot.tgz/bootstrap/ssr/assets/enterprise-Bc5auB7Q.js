import { jsxs, jsx } from "react/jsx-runtime";
import { A as AppLogoIcon } from "./app-logo-icon-B5cAnkkG.js";
import { I as InputError } from "./input-error-OAlVWCYk.js";
import { B as Button } from "./button-DMGEFYrU.js";
import { I as Input } from "./input-nVyaPHpJ.js";
import { L as Label } from "./label-BjflLCFy.js";
import { h as home } from "./index-NXMefbOa.js";
import { usePage, useForm, Head, Link } from "@inertiajs/react";
import { MessageCircle, Mail, Phone, ArrowLeft } from "lucide-react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
function Enterprise() {
  const { flash } = usePage().props;
  const { data, setData, post, processing, errors, reset } = useForm({
    name: "",
    email: "",
    phone: "",
    company_name: "",
    message: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post("/subscription/enterprise", {
      onSuccess: () => reset()
    });
  };
  return /* @__PURE__ */ jsxs("div", { className: "flex min-h-svh flex-col items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50 p-6 dark:from-slate-950 dark:to-slate-900", children: [
    /* @__PURE__ */ jsx(Head, { title: "Enterprise Plan" }),
    /* @__PURE__ */ jsxs("div", { className: "w-full max-w-lg", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-8 flex flex-col items-center gap-4 text-center", children: [
        /* @__PURE__ */ jsx(Link, { href: home(), children: /* @__PURE__ */ jsx(AppLogoIcon, { className: "h-12 w-auto" }) }),
        /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-slate-900 dark:text-white", children: "Enterprise Plan" }),
        /* @__PURE__ */ jsx("p", { className: "text-slate-600 dark:text-slate-400", children: "Get a custom solution tailored to your business needs." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: [
        /* @__PURE__ */ jsx("h2", { className: "mb-4 text-lg font-semibold text-slate-900 dark:text-white", children: "Get in Touch" }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-3", children: [
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: "https://wa.me/260970000000",
              target: "_blank",
              rel: "noopener noreferrer",
              className: "flex items-center gap-3 rounded-lg bg-green-50 p-3 text-sm text-green-800 transition-colors hover:bg-green-100 dark:bg-green-900/20 dark:text-green-300 dark:hover:bg-green-900/40",
              children: [
                /* @__PURE__ */ jsx(MessageCircle, { className: "h-5 w-5" }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("p", { className: "font-medium", children: "WhatsApp" }),
                  /* @__PURE__ */ jsx("p", { className: "text-xs opacity-80", children: "Chat with us on WhatsApp" })
                ] })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: "mailto:enterprise@nilo.co.zm",
              className: "flex items-center gap-3 rounded-lg bg-blue-50 p-3 text-sm text-blue-800 transition-colors hover:bg-blue-100 dark:bg-blue-900/20 dark:text-blue-300 dark:hover:bg-blue-900/40",
              children: [
                /* @__PURE__ */ jsx(Mail, { className: "h-5 w-5" }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("p", { className: "font-medium", children: "Email" }),
                  /* @__PURE__ */ jsx("p", { className: "text-xs opacity-80", children: "enterprise@nilo.co.zm" })
                ] })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: "tel:+260970000000",
              className: "flex items-center gap-3 rounded-lg bg-slate-50 p-3 text-sm text-slate-800 transition-colors hover:bg-slate-100 dark:bg-slate-700 dark:text-slate-300 dark:hover:bg-slate-600",
              children: [
                /* @__PURE__ */ jsx(Phone, { className: "h-5 w-5" }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("p", { className: "font-medium", children: "Phone" }),
                  /* @__PURE__ */ jsx("p", { className: "text-xs opacity-80", children: "+260 97 000 0000" })
                ] })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: [
        /* @__PURE__ */ jsx("h2", { className: "mb-4 text-lg font-semibold text-slate-900 dark:text-white", children: "Or Send Us a Message" }),
        flash?.success && /* @__PURE__ */ jsx("div", { className: "mb-4 rounded-lg bg-green-50 p-3 text-sm text-green-700 dark:bg-green-900/20 dark:text-green-300", children: flash.success }),
        /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "space-y-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "name", children: "Name" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "name",
                  value: data.name,
                  onChange: (e) => setData("name", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.name })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "email", children: "Email" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "email",
                  type: "email",
                  value: data.email,
                  onChange: (e) => setData("email", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.email })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "phone", children: "Phone (optional)" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "phone",
                  type: "tel",
                  value: data.phone,
                  onChange: (e) => setData("phone", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.phone })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "company_name", children: "Company (optional)" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "company_name",
                  value: data.company_name,
                  onChange: (e) => setData("company_name", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.company_name })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx(Label, { htmlFor: "message", children: "Message" }),
            /* @__PURE__ */ jsx(
              "textarea",
              {
                id: "message",
                rows: 4,
                className: "flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                placeholder: "Tell us about your business needs...",
                value: data.message,
                onChange: (e) => setData("message", e.target.value)
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.message })
          ] }),
          /* @__PURE__ */ jsx(Button, { type: "submit", className: "w-full", disabled: processing, children: processing ? "Sending..." : "Send Inquiry" })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "mt-4 text-center", children: /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/subscription/select",
          className: "inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300",
          children: [
            /* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }),
            "Back to plans"
          ]
        }
      ) })
    ] })
  ] });
}
export {
  Enterprise as default
};
