import { jsxs, jsx } from "react/jsx-runtime";
function GoogleLoginButton({
  label = "Continue with Google",
  tabIndex
}) {
  return /* @__PURE__ */ jsxs(
    "a",
    {
      href: "/auth/google",
      tabIndex,
      className: "inline-flex w-full items-center justify-center gap-3 rounded-lg border border-black/10 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 shadow-sm transition-all hover:bg-gray-50 hover:shadow-md active:scale-[0.99]",
      children: [
        /* @__PURE__ */ jsxs("svg", { className: "h-5 w-5", viewBox: "0 0 24 24", "aria-hidden": "true", children: [
          /* @__PURE__ */ jsx(
            "path",
            {
              fill: "#4285F4",
              d: "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
            }
          ),
          /* @__PURE__ */ jsx(
            "path",
            {
              fill: "#34A853",
              d: "M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23z"
            }
          ),
          /* @__PURE__ */ jsx(
            "path",
            {
              fill: "#FBBC05",
              d: "M5.84 14.1a6.6 6.6 0 0 1 0-4.2V7.06H2.18a11 11 0 0 0 0 9.88l3.66-2.84z"
            }
          ),
          /* @__PURE__ */ jsx(
            "path",
            {
              fill: "#EA4335",
              d: "M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1A11 11 0 0 0 2.18 7.06l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z"
            }
          )
        ] }),
        label
      ]
    }
  );
}
export {
  GoogleLoginButton as G
};
