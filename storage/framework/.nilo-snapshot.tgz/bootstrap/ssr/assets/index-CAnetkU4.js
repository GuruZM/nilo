import { jsxs, jsx } from "react/jsx-runtime";
import { usePage, Head, Link, router } from "@inertiajs/react";
import { motion } from "framer-motion";
import { Plus, LayoutTemplate, CheckCircle2, Star } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";
import { A as AppLayout } from "./app-layout-JvxHjkrs.js";
import { H as HeadingSmall } from "./heading-small-CT3emyQQ.js";
import { B as Button, c as cn } from "./button-DMGEFYrU.js";
import { C as Card } from "./card-MypPWj87.js";
import { S as Separator } from "./separator-Bcia5PKZ.js";
import "./Chatbot-yoo4250k.js";
import "./app-sidebar-layout-BGzXXcN9.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-separator";
function InvoiceTemplatesIndex({
  templates,
  module
}) {
  const page = usePage();
  const singularLabel = module.singularTitle.toLowerCase();
  const pluralLabel = module.pluralTitle.toLowerCase();
  const breadcrumbs = [
    { title: "Settings", href: "/settings/profile" },
    { title: module.pluralTitle, href: module.basePath }
  ];
  React.useEffect(() => {
    const s = page.props?.flash?.success;
    const e = page.props?.flash?.error;
    const i = page.props?.flash?.info;
    if (s) toast.success(s);
    if (e) toast.error(e);
    if (i) toast.message(i);
  }, [
    page.props?.flash?.success,
    page.props?.flash?.error,
    page.props?.flash?.info
  ]);
  const makeDefault = (id) => {
    router.post(
      `${module.basePath}/${id}/default`,
      {},
      {
        preserveScroll: true,
        onSuccess: () => toast.success(`Default ${singularLabel} updated.`),
        onError: (errors) => toast.error(errors?.template || "Failed to set default.")
      }
    );
  };
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: module.pluralTitle }),
    /* @__PURE__ */ jsxs(
      motion.div,
      {
        initial: { opacity: 0, y: 14 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.25, ease: "easeOut" },
        className: "space-y-6 px-4 py-6",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-4", children: [
            /* @__PURE__ */ jsx("div", { className: "space-y-1", children: /* @__PURE__ */ jsx(
              HeadingSmall,
              {
                title: module.pluralTitle,
                description: `Create and customize ${pluralLabel} for the active company.`
              }
            ) }),
            /* @__PURE__ */ jsx(
              Button,
              {
                asChild: true,
                className: "gap-2 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                children: /* @__PURE__ */ jsxs(Link, { href: module.createPath, children: [
                  /* @__PURE__ */ jsx(Plus, { className: "h-4 w-4" }),
                  "New template"
                ] })
              }
            )
          ] }),
          /* @__PURE__ */ jsx(Separator, {}),
          templates.length === 0 ? /* @__PURE__ */ jsx(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
            /* @__PURE__ */ jsx("div", { className: "grid h-11 w-11 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(LayoutTemplate, { className: "h-6 w-6 opacity-80" }) }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
              /* @__PURE__ */ jsxs("div", { className: "text-sm font-semibold", children: [
                "No ",
                pluralLabel,
                " yet"
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "text-sm text-muted-foreground", children: [
                "Create your first ",
                singularLabel,
                " to keep your",
                " ",
                module.type === "quotation" ? "quotations" : "invoices",
                " ",
                "consistently branded."
              ] }),
              /* @__PURE__ */ jsxs(
                Button,
                {
                  className: "mt-3 gap-2 rounded-xl",
                  onClick: () => router.visit(module.createPath),
                  children: [
                    /* @__PURE__ */ jsx(Plus, { className: "h-4 w-4" }),
                    "Create template"
                  ]
                }
              )
            ] })
          ] }) }) : /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 gap-4 md:grid-cols-2", children: templates.map((t) => /* @__PURE__ */ jsx(
            motion.div,
            {
              initial: { opacity: 0, y: 10 },
              animate: { opacity: 1, y: 0 },
              transition: { duration: 0.2 },
              children: /* @__PURE__ */ jsx(
                Card,
                {
                  className: cn(
                    "rounded-2xl border bg-background p-5 shadow-sm",
                    t.is_default && "border-foreground/20 bg-muted/20"
                  ),
                  children: /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
                    /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                        /* @__PURE__ */ jsx("div", { className: "truncate text-sm font-semibold", children: t.name }),
                        t.is_default && /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-xs", children: [
                          /* @__PURE__ */ jsx(CheckCircle2, { className: "h-3.5 w-3.5" }),
                          "Default"
                        ] })
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "mt-1 text-xs text-muted-foreground", children: [
                        "Created",
                        " ",
                        new Date(
                          t.created_at
                        ).toLocaleDateString()
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsx(
                        Button,
                        {
                          variant: "outline",
                          size: "sm",
                          className: "rounded-xl",
                          asChild: true,
                          children: /* @__PURE__ */ jsx(
                            Link,
                            {
                              href: `${module.basePath}/${t.id}/edit`,
                              children: "Edit"
                            }
                          )
                        }
                      ),
                      /* @__PURE__ */ jsxs(
                        Button,
                        {
                          variant: t.is_default ? "secondary" : "outline",
                          size: "sm",
                          className: "gap-2 rounded-xl",
                          onClick: () => makeDefault(t.id),
                          disabled: t.is_default,
                          children: [
                            /* @__PURE__ */ jsx(Star, { className: "h-4 w-4" }),
                            "Default"
                          ]
                        }
                      )
                    ] })
                  ] })
                }
              )
            },
            t.id
          )) })
        ]
      }
    )
  ] });
}
export {
  InvoiceTemplatesIndex as default
};
