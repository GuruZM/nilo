import { jsxs, jsx } from "react/jsx-runtime";
import { A as AppSidebarLayout } from "./app-sidebar-layout-BGzXXcN9.js";
import { B as Button } from "./button-DMGEFYrU.js";
import { I as Input } from "./input-nVyaPHpJ.js";
import { Head, Link, router } from "@inertiajs/react";
import { Search } from "lucide-react";
import { useState } from "react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "sonner";
import "clsx";
import "tailwind-merge";
const breadcrumbs = [
  { title: "Admin", href: "/admin" },
  { title: "Users", href: "/admin/users" }
];
const statusBadge = (status) => {
  const colors = {
    active: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
    pending_payment: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
    cancelled: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
    expired: "bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-400"
  };
  return colors[status ?? ""] ?? colors.expired;
};
function UsersIndex({ users, filters, plans }) {
  const [search, setSearch] = useState(filters.search ?? "");
  const handleSearch = (e) => {
    e.preventDefault();
    router.get("/admin/users", { search, plan: filters.plan }, { preserveState: true });
  };
  const handlePlanFilter = (slug) => {
    router.get("/admin/users", { search: filters.search, plan: slug }, { preserveState: true });
  };
  return /* @__PURE__ */ jsxs(AppSidebarLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Admin - Users" }),
    /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-6xl space-y-6 p-6", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-slate-900 dark:text-white", children: "Users" }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-3", children: [
        /* @__PURE__ */ jsxs("form", { onSubmit: handleSearch, className: "flex gap-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsx(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" }),
            /* @__PURE__ */ jsx(
              Input,
              {
                placeholder: "Search users...",
                value: search,
                onChange: (e) => setSearch(e.target.value),
                className: "pl-9"
              }
            )
          ] }),
          /* @__PURE__ */ jsx(Button, { type: "submit", variant: "outline", size: "sm", children: "Search" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex gap-1", children: [
          /* @__PURE__ */ jsx(
            Button,
            {
              variant: !filters.plan ? "default" : "outline",
              size: "sm",
              onClick: () => handlePlanFilter(null),
              children: "All"
            }
          ),
          plans.map((plan) => /* @__PURE__ */ jsx(
            Button,
            {
              variant: filters.plan === plan.slug ? "default" : "outline",
              size: "sm",
              onClick: () => handlePlanFilter(plan.slug),
              children: plan.name
            },
            plan.slug
          ))
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-800", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-sm", children: [
        /* @__PURE__ */ jsx("thead", { className: "border-b border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-800/50", children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-medium text-slate-700 dark:text-slate-300", children: "User" }),
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-medium text-slate-700 dark:text-slate-300", children: "Plan" }),
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-medium text-slate-700 dark:text-slate-300", children: "Status" }),
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-medium text-slate-700 dark:text-slate-300", children: "Companies" }),
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-medium text-slate-700 dark:text-slate-300", children: "Joined" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-slate-200 dark:divide-slate-700", children: users.data.map((user) => /* @__PURE__ */ jsxs("tr", { className: "transition-colors hover:bg-slate-50 dark:hover:bg-slate-700/50", children: [
          /* @__PURE__ */ jsxs("td", { className: "px-4 py-3", children: [
            /* @__PURE__ */ jsx(Link, { href: `/admin/users/${user.id}`, className: "font-medium text-blue-600 hover:text-blue-800 dark:text-blue-400", children: user.name }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: user.email })
          ] }),
          /* @__PURE__ */ jsx("td", { className: "px-4 py-3 text-slate-700 dark:text-slate-300", children: user.subscription?.plan?.name ?? "None" }),
          /* @__PURE__ */ jsx("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsx("span", { className: `inline-block rounded-full px-2 py-0.5 text-xs font-medium ${statusBadge(user.subscription?.status)}`, children: user.subscription?.status?.replace("_", " ") ?? "No subscription" }) }),
          /* @__PURE__ */ jsx("td", { className: "px-4 py-3 text-slate-700 dark:text-slate-300", children: user.owned_companies_count }),
          /* @__PURE__ */ jsx("td", { className: "px-4 py-3 text-slate-500 dark:text-slate-400", children: new Date(user.created_at).toLocaleDateString() })
        ] }, user.id)) })
      ] }) }),
      users.last_page > 1 && /* @__PURE__ */ jsx("div", { className: "flex justify-center gap-1", children: users.links.map((link, i) => /* @__PURE__ */ jsx(
        Link,
        {
          href: link.url ?? "#",
          className: `rounded px-3 py-1 text-sm ${link.active ? "bg-blue-500 text-white" : link.url ? "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-700" : "text-slate-300 dark:text-slate-600"}`,
          dangerouslySetInnerHTML: { __html: link.label }
        },
        i
      )) })
    ] })
  ] });
}
export {
  UsersIndex as default
};
