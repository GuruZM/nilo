import { jsxs, jsx } from "react/jsx-runtime";
import { A as AppSidebarLayout } from "./app-sidebar-layout-BGzXXcN9.js";
import { B as Button } from "./button-DMGEFYrU.js";
import { Head, Link, router } from "@inertiajs/react";
import { Check } from "lucide-react";
import "react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "sonner";
import "clsx";
import "tailwind-merge";
const breadcrumbs = [
  { title: "Admin", href: "/admin" },
  { title: "Inquiries", href: "/admin/inquiries" }
];
function InquiriesIndex({ inquiries }) {
  const handleMarkHandled = (id) => {
    router.post(`/admin/inquiries/${id}/handle`);
  };
  return /* @__PURE__ */ jsxs(AppSidebarLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Admin - Enterprise Inquiries" }),
    /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-6xl space-y-6 p-6", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-slate-900 dark:text-white", children: "Enterprise Inquiries" }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
        inquiries.data.map((inquiry) => /* @__PURE__ */ jsxs(
          "div",
          {
            className: `rounded-xl border bg-white p-5 shadow-sm dark:bg-slate-800 ${inquiry.is_handled ? "border-slate-200 opacity-60 dark:border-slate-700" : "border-blue-200 dark:border-blue-800"}`,
            children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("h3", { className: "font-semibold text-slate-900 dark:text-white", children: inquiry.name }),
                  /* @__PURE__ */ jsxs("p", { className: "text-sm text-slate-500 dark:text-slate-400", children: [
                    inquiry.email,
                    inquiry.phone && ` | ${inquiry.phone}`,
                    inquiry.company_name && ` | ${inquiry.company_name}`
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-xs text-slate-400", children: new Date(inquiry.created_at).toLocaleDateString() }),
                  inquiry.is_handled ? /* @__PURE__ */ jsx("span", { className: "rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-800 dark:bg-green-900/30 dark:text-green-400", children: "Handled" }) : /* @__PURE__ */ jsxs(
                    Button,
                    {
                      size: "sm",
                      variant: "outline",
                      onClick: () => handleMarkHandled(inquiry.id),
                      children: [
                        /* @__PURE__ */ jsx(Check, { className: "mr-1 h-3.5 w-3.5" }),
                        "Mark Handled"
                      ]
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-3 text-sm text-slate-700 dark:text-slate-300", children: inquiry.message })
            ]
          },
          inquiry.id
        )),
        inquiries.data.length === 0 && /* @__PURE__ */ jsx("div", { className: "rounded-xl border border-slate-200 bg-white p-8 text-center text-slate-500 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400", children: "No inquiries yet." })
      ] }),
      inquiries.last_page > 1 && /* @__PURE__ */ jsx("div", { className: "flex justify-center gap-1", children: inquiries.links.map((link, i) => /* @__PURE__ */ jsx(
        Link,
        {
          href: link.url ?? "#",
          className: `rounded px-3 py-1 text-sm ${link.active ? "bg-blue-500 text-white" : link.url ? "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-700" : "text-slate-300 dark:text-slate-600"}`,
          dangerouslySetInnerHTML: { __html: link.label }
        },
        i
      )) })
    ] })
  ] });
}
export {
  InquiriesIndex as default
};
