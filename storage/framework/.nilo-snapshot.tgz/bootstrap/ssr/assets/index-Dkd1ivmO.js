import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { A as AppSidebarLayout } from "./app-sidebar-layout-BGzXXcN9.js";
import { B as Button } from "./button-DMGEFYrU.js";
import { Head, router, Link } from "@inertiajs/react";
import { CheckCircle, XCircle } from "lucide-react";
import "react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "sonner";
import "clsx";
import "tailwind-merge";
const breadcrumbs = [
  { title: "Admin", href: "/admin" },
  { title: "Payments", href: "/admin/payments" }
];
function PaymentsIndex({ payments, filters }) {
  const statusTabs = ["pending", "confirmed", "rejected", "all"];
  const handleConfirm = (paymentId) => {
    if (confirm("Confirm this payment and activate the subscription?")) {
      router.post(`/admin/payments/${paymentId}/confirm`);
    }
  };
  const handleReject = (paymentId) => {
    if (confirm("Reject this payment?")) {
      router.post(`/admin/payments/${paymentId}/reject`);
    }
  };
  return /* @__PURE__ */ jsxs(AppSidebarLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Admin - Payments" }),
    /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-6xl space-y-6 p-6", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-slate-900 dark:text-white", children: "Payments" }),
      /* @__PURE__ */ jsx("div", { className: "flex gap-1", children: statusTabs.map((tab) => /* @__PURE__ */ jsx(
        Button,
        {
          variant: filters.status === tab ? "default" : "outline",
          size: "sm",
          onClick: () => router.get("/admin/payments", { status: tab }, { preserveState: true }),
          className: "capitalize",
          children: tab
        },
        tab
      )) }),
      /* @__PURE__ */ jsx("div", { className: "overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-800", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-sm", children: [
        /* @__PURE__ */ jsx("thead", { className: "border-b border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-800/50", children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-medium text-slate-700 dark:text-slate-300", children: "User" }),
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-medium text-slate-700 dark:text-slate-300", children: "Plan" }),
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-medium text-slate-700 dark:text-slate-300", children: "Amount" }),
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-medium text-slate-700 dark:text-slate-300", children: "Method" }),
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-medium text-slate-700 dark:text-slate-300", children: "Reference" }),
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-medium text-slate-700 dark:text-slate-300", children: "Date" }),
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-medium text-slate-700 dark:text-slate-300", children: "Actions" })
        ] }) }),
        /* @__PURE__ */ jsxs("tbody", { className: "divide-y divide-slate-200 dark:divide-slate-700", children: [
          payments.data.map((payment) => /* @__PURE__ */ jsxs("tr", { className: "transition-colors hover:bg-slate-50 dark:hover:bg-slate-700/50", children: [
            /* @__PURE__ */ jsxs("td", { className: "px-4 py-3", children: [
              /* @__PURE__ */ jsx(Link, { href: `/admin/users/${payment.user.id}`, className: "font-medium text-blue-600 dark:text-blue-400", children: payment.user.name }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-slate-500", children: payment.user.email })
            ] }),
            /* @__PURE__ */ jsx("td", { className: "px-4 py-3 text-slate-700 dark:text-slate-300", children: payment.plan.name }),
            /* @__PURE__ */ jsxs("td", { className: "px-4 py-3 font-medium text-slate-900 dark:text-white", children: [
              "K",
              parseFloat(payment.amount).toLocaleString()
            ] }),
            /* @__PURE__ */ jsx("td", { className: "px-4 py-3 text-slate-700 dark:text-slate-300", children: payment.payment_method === "airtel_money" ? "Airtel Money" : "Bank Transfer" }),
            /* @__PURE__ */ jsxs("td", { className: "px-4 py-3 text-slate-500 dark:text-slate-400", children: [
              payment.payment_reference ?? "-",
              payment.pop_file_path && /* @__PURE__ */ jsx(
                "a",
                {
                  href: `/storage/${payment.pop_file_path}`,
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "ml-1 text-blue-500 hover:text-blue-600",
                  children: "(View POP)"
                }
              )
            ] }),
            /* @__PURE__ */ jsx("td", { className: "px-4 py-3 text-slate-500 dark:text-slate-400", children: new Date(payment.created_at).toLocaleDateString() }),
            /* @__PURE__ */ jsx("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1", children: [
              payment.status === "pending" && /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsxs(Button, { size: "sm", variant: "outline", onClick: () => handleConfirm(payment.id), children: [
                  /* @__PURE__ */ jsx(CheckCircle, { className: "mr-1 h-3.5 w-3.5 text-green-500" }),
                  "Confirm"
                ] }),
                /* @__PURE__ */ jsxs(Button, { size: "sm", variant: "outline", onClick: () => handleReject(payment.id), children: [
                  /* @__PURE__ */ jsx(XCircle, { className: "mr-1 h-3.5 w-3.5 text-red-500" }),
                  "Reject"
                ] })
              ] }),
              payment.status !== "pending" && /* @__PURE__ */ jsx("span", { className: `inline-block rounded-full px-2 py-0.5 text-xs font-medium ${payment.status === "confirmed" ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"}`, children: payment.status })
            ] }) })
          ] }, payment.id)),
          payments.data.length === 0 && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: 7, className: "px-4 py-8 text-center text-slate-500 dark:text-slate-400", children: "No payments found." }) })
        ] })
      ] }) }),
      payments.last_page > 1 && /* @__PURE__ */ jsx("div", { className: "flex justify-center gap-1", children: payments.links.map((link, i) => /* @__PURE__ */ jsx(
        Link,
        {
          href: link.url ?? "#",
          className: `rounded px-3 py-1 text-sm ${link.active ? "bg-blue-500 text-white" : link.url ? "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-700" : "text-slate-300 dark:text-slate-600"}`,
          dangerouslySetInnerHTML: { __html: link.label }
        },
        i
      )) })
    ] })
  ] });
}
export {
  PaymentsIndex as default
};
