import { jsxs, jsx } from "react/jsx-runtime";
import { A as AppLayout } from "./app-layout-JvxHjkrs.js";
import { Head } from "@inertiajs/react";
import { useState } from "react";
import "./Chatbot-yoo4250k.js";
import "lucide-react";
import "./app-sidebar-layout-BGzXXcN9.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "./button-DMGEFYrU.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "sonner";
const breadcrumbs = [
  { title: "Invoices", href: "/invoices" },
  { title: "Create", href: "/invoices/create" }
];
function InvoiceBuilder() {
  const [items, setItems] = useState([
    { description: "", quantity: 1, price: 0 }
  ]);
  const [client, setClient] = useState("");
  const [date, setDate] = useState("");
  const addItem = () => setItems([...items, { description: "", quantity: 1, price: 0 }]);
  const updateItem = (idx, field, value) => {
    setItems(
      items.map(
        (item, i) => i === idx ? { ...item, [field]: value } : item
      )
    );
  };
  const removeItem = (idx) => setItems(items.filter((_, i) => i !== idx));
  const total = items.reduce(
    (sum, item) => sum + item.quantity * item.price,
    0
  );
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Create Invoice" }),
    /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-2xl rounded bg-white p-6 shadow", children: [
      /* @__PURE__ */ jsx("h1", { className: "mb-4 text-2xl font-bold", children: "Create Invoice" }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "mb-1 block font-medium", children: "Client" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            value: client,
            onChange: (e) => setClient(e.target.value),
            className: "w-full rounded border px-3 py-2"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "mb-1 block font-medium", children: "Date" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "date",
            value: date,
            onChange: (e) => setDate(e.target.value),
            className: "w-full rounded border px-3 py-2"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("label", { className: "mb-2 block font-medium", children: "Items" }),
        items.map((item, idx) => /* @__PURE__ */ jsxs("div", { className: "mb-2 flex gap-2", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              placeholder: "Description",
              value: item.description,
              onChange: (e) => updateItem(
                idx,
                "description",
                e.target.value
              ),
              className: "flex-1 rounded border px-2 py-1"
            }
          ),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "number",
              min: 1,
              value: item.quantity,
              onChange: (e) => updateItem(
                idx,
                "quantity",
                Number(e.target.value)
              ),
              className: "w-20 rounded border px-2 py-1"
            }
          ),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "number",
              min: 0,
              value: item.price,
              onChange: (e) => updateItem(
                idx,
                "price",
                Number(e.target.value)
              ),
              className: "w-24 rounded border px-2 py-1"
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: () => removeItem(idx),
              className: "text-red-500",
              children: "×"
            }
          )
        ] }, idx)),
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "button",
            onClick: addItem,
            className: "mt-2 rounded bg-blue-600 px-3 py-1 text-white",
            children: "Add Item"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-6 text-right text-lg font-bold", children: [
        "Total: $",
        total.toFixed(2)
      ] }),
      /* @__PURE__ */ jsx("button", { className: "mt-6 w-full rounded bg-green-600 py-2 font-semibold text-white", children: "Save Invoice" })
    ] })
  ] });
}
export {
  InvoiceBuilder as default
};
