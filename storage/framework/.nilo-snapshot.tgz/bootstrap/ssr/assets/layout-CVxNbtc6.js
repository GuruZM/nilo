import { jsxs, jsx } from "react/jsx-runtime";
import { B as Button, c as cn } from "./button-DMGEFYrU.js";
import { S as Separator } from "./separator-Bcia5PKZ.js";
import { e as edit$1 } from "./index-Ovdv7nCr.js";
import { g as edit } from "./app-sidebar-layout-BGzXXcN9.js";
import { Link } from "@inertiajs/react";
import { User, KeyRound } from "lucide-react";
function Heading({
  title,
  description
}) {
  return /* @__PURE__ */ jsxs("div", { className: "mb-8 space-y-0.5", children: [
    /* @__PURE__ */ jsx("h2", { className: "text-xl font-semibold tracking-tight", children: title }),
    description && /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: description })
  ] });
}
const sidebarNavItems = [
  {
    title: "Profile",
    href: edit(),
    icon: User
  },
  {
    title: "Password",
    href: edit$1(),
    icon: KeyRound
  }
];
function SettingsLayout({ children }) {
  if (typeof window === "undefined") {
    return null;
  }
  const currentPath = window.location.pathname;
  return /* @__PURE__ */ jsxs("div", { className: "px-4 py-6", children: [
    /* @__PURE__ */ jsx(
      Heading,
      {
        title: "Settings",
        description: "Manage your profile and account access"
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col lg:flex-row lg:space-x-12", children: [
      /* @__PURE__ */ jsx("aside", { className: "w-full max-w-xl lg:w-56", children: /* @__PURE__ */ jsx("nav", { className: "flex flex-col space-y-1", children: sidebarNavItems.map((item, index) => {
        const href = typeof item.href === "string" ? item.href : item.href.url;
        const isActive = currentPath === href || currentPath.startsWith(href + "/");
        return /* @__PURE__ */ jsx(
          Button,
          {
            size: "sm",
            variant: "ghost",
            asChild: true,
            className: cn(
              "w-full justify-start gap-3 rounded-xl px-3 py-2 transition-colors",
              {
                "bg-muted font-medium": isActive
              }
            ),
            children: /* @__PURE__ */ jsxs(Link, { href: item.href, children: [
              item.icon && /* @__PURE__ */ jsx(item.icon, { className: "h-4 w-4 opacity-80" }),
              /* @__PURE__ */ jsx("span", { children: item.title })
            ] })
          },
          `${href}-${index}`
        );
      }) }) }),
      /* @__PURE__ */ jsx(Separator, { className: "my-6 lg:hidden" }),
      /* @__PURE__ */ jsx("div", { className: "flex-1", children: /* @__PURE__ */ jsx("section", { className: "space-y-12", children }) })
    ] })
  ] });
}
export {
  SettingsLayout as S
};
