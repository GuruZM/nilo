import { jsx, jsxs } from "react/jsx-runtime";
import { q as queryParams, r as register } from "./index-NXMefbOa.js";
import { G as GoogleLoginButton } from "./google-login-button-8WBbQ6gO.js";
import { I as InputError } from "./input-error-OAlVWCYk.js";
import { T as TextLink } from "./text-link-Bo2rQfJF.js";
import { c as cn, B as Button } from "./button-DMGEFYrU.js";
import * as CheckboxPrimitive from "@radix-ui/react-checkbox";
import { CheckIcon, LoaderCircle } from "lucide-react";
import { I as Input } from "./input-nVyaPHpJ.js";
import { L as Label } from "./label-BjflLCFy.js";
import { A as AuthLayout } from "./auth-layout-CLi3tegl.js";
import { r as request } from "./index-Ovdv7nCr.js";
import { useForm, Head } from "@inertiajs/react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
import "./app-logo-icon-B5cAnkkG.js";
import "./PaperGlyphs-ClQ5oP_s.js";
import "./index-DqawoI4q.js";
const create = (options) => ({
  url: create.url(options),
  method: "get"
});
create.definition = {
  methods: ["get", "head"],
  url: "/login"
};
create.url = (options) => {
  return create.definition.url + queryParams(options);
};
create.get = (options) => ({
  url: create.url(options),
  method: "get"
});
create.head = (options) => ({
  url: create.url(options),
  method: "head"
});
const createForm = (options) => ({
  action: create.url(options),
  method: "get"
});
createForm.get = (options) => ({
  action: create.url(options),
  method: "get"
});
createForm.head = (options) => ({
  action: create.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
create.form = createForm;
const store = (options) => ({
  url: store.url(options),
  method: "post"
});
store.definition = {
  methods: ["post"],
  url: "/login"
};
store.url = (options) => {
  return store.definition.url + queryParams(options);
};
store.post = (options) => ({
  url: store.url(options),
  method: "post"
});
const storeForm = (options) => ({
  action: store.url(options),
  method: "post"
});
storeForm.post = (options) => ({
  action: store.url(options),
  method: "post"
});
store.form = storeForm;
const destroy = (options) => ({
  url: destroy.url(options),
  method: "post"
});
destroy.definition = {
  methods: ["post"],
  url: "/logout"
};
destroy.url = (options) => {
  return destroy.definition.url + queryParams(options);
};
destroy.post = (options) => ({
  url: destroy.url(options),
  method: "post"
});
const destroyForm = (options) => ({
  action: destroy.url(options),
  method: "post"
});
destroyForm.post = (options) => ({
  action: destroy.url(options),
  method: "post"
});
destroy.form = destroyForm;
const AuthenticatedSessionController = { store };
function Checkbox({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    CheckboxPrimitive.Root,
    {
      "data-slot": "checkbox",
      className: cn(
        "peer border-input data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground data-[state=checked]:border-primary focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive size-4 shrink-0 rounded-[4px] border shadow-xs transition-shadow outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsx(
        CheckboxPrimitive.Indicator,
        {
          "data-slot": "checkbox-indicator",
          className: "flex items-center justify-center text-current transition-none",
          children: /* @__PURE__ */ jsx(CheckIcon, { className: "size-3.5" })
        }
      )
    }
  );
}
function Login({ status, canResetPassword }) {
  const { data, setData, post, processing, errors, reset } = useForm({
    email: "",
    password: "",
    remember: false
  });
  const submit = (event) => {
    event.preventDefault();
    post(AuthenticatedSessionController.store.url(), {
      onSuccess: () => reset("password")
    });
  };
  return /* @__PURE__ */ jsxs(
    AuthLayout,
    {
      title: "Log in",
      description: "Enter your email and password to open your dashboard.",
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Log in" }),
        status && /* @__PURE__ */ jsx("div", { className: "border border-brand/20 bg-brand-50 p-4 text-center text-sm font-medium text-brand dark:bg-brand-950/50 dark:text-brand-300", children: status }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-6", children: [
          /* @__PURE__ */ jsx(GoogleLoginButton, { tabIndex: 0 }),
          /* @__PURE__ */ jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsx("div", { className: "absolute inset-0 flex items-center", children: /* @__PURE__ */ jsx("span", { className: "w-full border-t border-border" }) }),
            /* @__PURE__ */ jsx("div", { className: "relative flex justify-center text-xs uppercase", children: /* @__PURE__ */ jsx("span", { className: "bg-background px-2 text-muted-foreground", children: "Or continue with email" }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "flex flex-col gap-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "grid gap-6", children: [
            /* @__PURE__ */ jsxs("div", { className: "grid gap-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "email", children: "Email address" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "email",
                  type: "email",
                  name: "email",
                  required: true,
                  autoFocus: true,
                  tabIndex: 1,
                  autoComplete: "email",
                  placeholder: "email@example.com",
                  value: data.email,
                  onChange: (event) => setData("email", event.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.email })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid gap-2", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "password", children: "Password" }),
                canResetPassword && /* @__PURE__ */ jsx(
                  TextLink,
                  {
                    href: request(),
                    className: "ml-auto text-sm",
                    tabIndex: 5,
                    children: "Forgot password?"
                  }
                )
              ] }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "password",
                  type: "password",
                  name: "password",
                  required: true,
                  tabIndex: 2,
                  autoComplete: "current-password",
                  placeholder: "Password",
                  value: data.password,
                  onChange: (event) => setData("password", event.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.password })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center space-x-3", children: [
              /* @__PURE__ */ jsx(
                Checkbox,
                {
                  id: "remember",
                  name: "remember",
                  tabIndex: 3,
                  checked: data.remember,
                  onCheckedChange: (checked) => setData("remember", checked === true)
                }
              ),
              /* @__PURE__ */ jsx(Label, { htmlFor: "remember", children: "Remember me" })
            ] }),
            /* @__PURE__ */ jsxs(
              Button,
              {
                type: "submit",
                className: "mt-2 w-full bg-brand text-white hover:bg-brand-700",
                tabIndex: 4,
                disabled: processing,
                "data-test": "login-button",
                children: [
                  processing && /* @__PURE__ */ jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
                  "Log in"
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "text-center text-sm text-muted-foreground", children: [
            "New to Nilo?",
            " ",
            /* @__PURE__ */ jsx(TextLink, { href: register(), tabIndex: 5, children: "Create your free account" })
          ] })
        ] })
      ]
    }
  );
}
export {
  Login as default
};
