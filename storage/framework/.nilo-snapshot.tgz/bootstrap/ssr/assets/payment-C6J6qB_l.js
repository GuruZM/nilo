import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { A as AppLogoIcon } from "./app-logo-icon-B5cAnkkG.js";
import { B as Button } from "./button-DMGEFYrU.js";
import { I as Input } from "./input-nVyaPHpJ.js";
import { L as Label } from "./label-BjflLCFy.js";
import { I as InputError } from "./input-error-OAlVWCYk.js";
import { h as home } from "./index-NXMefbOa.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { Phone, Building2, Upload, ArrowLeft } from "lucide-react";
import { useState } from "react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
function Payment({ plan }) {
  const [method, setMethod] = useState("airtel_money");
  const { data, setData, post, processing, errors } = useForm({
    plan_id: plan.id,
    payment_method: "airtel_money",
    phone_number: "",
    payment_reference: "",
    pop_file: null
  });
  const handleMethodChange = (newMethod) => {
    setMethod(newMethod);
    setData("payment_method", newMethod);
  };
  const submit = (e) => {
    e.preventDefault();
    post("/subscription/payment", {
      forceFormData: true
    });
  };
  return /* @__PURE__ */ jsxs("div", { className: "flex min-h-svh flex-col items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50 p-6 dark:from-slate-950 dark:to-slate-900", children: [
    /* @__PURE__ */ jsx(Head, { title: "Payment" }),
    /* @__PURE__ */ jsxs("div", { className: "w-full max-w-lg", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-8 flex flex-col items-center gap-4 text-center", children: [
        /* @__PURE__ */ jsx(Link, { href: home(), children: /* @__PURE__ */ jsx(AppLogoIcon, { className: "h-12 w-auto" }) }),
        /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-slate-900 dark:text-white", children: "Complete Payment" }),
        /* @__PURE__ */ jsxs("p", { className: "text-slate-600 dark:text-slate-400", children: [
          "Subscribe to ",
          /* @__PURE__ */ jsx("span", { className: "font-semibold", children: plan.name }),
          " — K",
          parseFloat(plan.price).toLocaleString(),
          "/month"
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: [
        /* @__PURE__ */ jsxs("div", { className: "mb-6 flex gap-2 rounded-lg bg-slate-100 p-1 dark:bg-slate-700", children: [
          /* @__PURE__ */ jsxs(
            "button",
            {
              type: "button",
              onClick: () => handleMethodChange("airtel_money"),
              className: `flex flex-1 items-center justify-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-colors ${method === "airtel_money" ? "bg-white text-slate-900 shadow-sm dark:bg-slate-600 dark:text-white" : "text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"}`,
              children: [
                /* @__PURE__ */ jsx(Phone, { className: "h-4 w-4" }),
                "Airtel Money"
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            "button",
            {
              type: "button",
              onClick: () => handleMethodChange("bank_transfer"),
              className: `flex flex-1 items-center justify-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-colors ${method === "bank_transfer" ? "bg-white text-slate-900 shadow-sm dark:bg-slate-600 dark:text-white" : "text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"}`,
              children: [
                /* @__PURE__ */ jsx(Building2, { className: "h-4 w-4" }),
                "Bank Transfer"
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "space-y-5", children: [
          /* @__PURE__ */ jsx("input", { type: "hidden", name: "plan_id", value: plan.id }),
          /* @__PURE__ */ jsx("input", { type: "hidden", name: "payment_method", value: method }),
          method === "airtel_money" && /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "phone_number", children: "Airtel Money Number" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "phone_number",
                  type: "tel",
                  placeholder: "e.g. 097XXXXXXX",
                  value: data.phone_number,
                  onChange: (e) => setData("phone_number", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.phone_number })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "payment_reference", children: "Transaction Reference (optional)" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "payment_reference",
                  type: "text",
                  placeholder: "Enter reference if you already paid",
                  value: data.payment_reference,
                  onChange: (e) => setData("payment_reference", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.payment_reference })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "rounded-lg bg-blue-50 p-4 text-sm text-blue-800 dark:bg-blue-900/20 dark:text-blue-300", children: [
              /* @__PURE__ */ jsx("p", { className: "font-semibold", children: "How to pay with Airtel Money:" }),
              /* @__PURE__ */ jsxs("ol", { className: "mt-2 list-inside list-decimal space-y-1", children: [
                /* @__PURE__ */ jsx("li", { children: "Dial *778# on your Airtel phone" }),
                /* @__PURE__ */ jsx("li", { children: 'Select "Send Money"' }),
                /* @__PURE__ */ jsx("li", { children: "Enter the payment number provided" }),
                /* @__PURE__ */ jsxs("li", { children: [
                  "Enter amount: K",
                  parseFloat(plan.price).toLocaleString()
                ] }),
                /* @__PURE__ */ jsx("li", { children: "Confirm and enter your PIN" })
              ] })
            ] })
          ] }),
          method === "bank_transfer" && /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsxs("div", { className: "rounded-lg bg-slate-50 p-4 text-sm dark:bg-slate-700", children: [
              /* @__PURE__ */ jsx("p", { className: "mb-3 font-semibold text-slate-900 dark:text-white", children: "Bank Details:" }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-1 text-slate-700 dark:text-slate-300", children: [
                /* @__PURE__ */ jsxs("p", { children: [
                  /* @__PURE__ */ jsx("span", { className: "font-medium", children: "Bank:" }),
                  " Stanbic Bank Zambia"
                ] }),
                /* @__PURE__ */ jsxs("p", { children: [
                  /* @__PURE__ */ jsx("span", { className: "font-medium", children: "Account Name:" }),
                  " Nilo Technologies Ltd"
                ] }),
                /* @__PURE__ */ jsxs("p", { children: [
                  /* @__PURE__ */ jsx("span", { className: "font-medium", children: "Account Number:" }),
                  " 9130001234567"
                ] }),
                /* @__PURE__ */ jsxs("p", { children: [
                  /* @__PURE__ */ jsx("span", { className: "font-medium", children: "Branch:" }),
                  " Main Branch"
                ] }),
                /* @__PURE__ */ jsxs("p", { children: [
                  /* @__PURE__ */ jsx("span", { className: "font-medium", children: "Amount:" }),
                  " K",
                  parseFloat(plan.price).toLocaleString()
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "payment_reference", children: "Payment Reference / Receipt Number" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "payment_reference",
                  type: "text",
                  placeholder: "Enter your payment reference",
                  value: data.payment_reference,
                  onChange: (e) => setData("payment_reference", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.payment_reference })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "pop_file", children: "Upload Proof of Payment" }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxs(
                  "label",
                  {
                    htmlFor: "pop_file",
                    className: "flex flex-1 cursor-pointer items-center gap-3 rounded-lg border-2 border-dashed border-slate-300 p-4 transition-colors hover:border-blue-400 dark:border-slate-600 dark:hover:border-blue-500",
                    children: [
                      /* @__PURE__ */ jsx(Upload, { className: "h-5 w-5 text-slate-400" }),
                      /* @__PURE__ */ jsx("span", { className: "text-sm text-slate-600 dark:text-slate-400", children: data.pop_file ? data.pop_file.name : "Click to upload (JPG, PNG, PDF, max 5MB)" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    id: "pop_file",
                    type: "file",
                    className: "hidden",
                    accept: ".jpg,.jpeg,.png,.pdf",
                    onChange: (e) => {
                      const file = e.target.files?.[0] ?? null;
                      setData("pop_file", file);
                    }
                  }
                )
              ] }),
              /* @__PURE__ */ jsx(InputError, { message: errors.pop_file })
            ] })
          ] }),
          /* @__PURE__ */ jsx(Button, { type: "submit", className: "w-full", disabled: processing, children: processing ? "Submitting..." : "Submit Payment" })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "mt-4 text-center", children: /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/subscription/select",
          className: "inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300",
          children: [
            /* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }),
            "Back to plans"
          ]
        }
      ) })
    ] })
  ] });
}
export {
  Payment as default
};
