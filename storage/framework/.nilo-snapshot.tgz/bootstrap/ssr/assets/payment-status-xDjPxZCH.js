import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { A as AppLogoIcon } from "./app-logo-icon-B5cAnkkG.js";
import { B as Button } from "./button-DMGEFYrU.js";
import { h as home } from "./index-NXMefbOa.js";
import { usePage, Head, Link } from "@inertiajs/react";
import { XCircle, CheckCircle, Clock } from "lucide-react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
const statusConfig = {
  pending: {
    icon: Clock,
    color: "text-amber-500",
    bgColor: "bg-amber-50 dark:bg-amber-900/20",
    title: "Payment Pending Confirmation",
    description: "Your payment has been submitted and is awaiting admin confirmation. This usually takes a few hours."
  },
  confirmed: {
    icon: CheckCircle,
    color: "text-green-500",
    bgColor: "bg-green-50 dark:bg-green-900/20",
    title: "Payment Confirmed!",
    description: "Your payment has been confirmed and your subscription is now active."
  },
  rejected: {
    icon: XCircle,
    color: "text-red-500",
    bgColor: "bg-red-50 dark:bg-red-900/20",
    title: "Payment Rejected",
    description: "Your payment could not be verified. Please try again or contact support."
  }
};
function PaymentStatus({ payment, subscription }) {
  const { flash } = usePage().props;
  const status = payment?.status ?? "pending";
  const config = statusConfig[status] ?? statusConfig.pending;
  const Icon = config.icon;
  return /* @__PURE__ */ jsxs("div", { className: "flex min-h-svh flex-col items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50 p-6 dark:from-slate-950 dark:to-slate-900", children: [
    /* @__PURE__ */ jsx(Head, { title: "Payment Status" }),
    /* @__PURE__ */ jsxs("div", { className: "w-full max-w-md", children: [
      /* @__PURE__ */ jsx("div", { className: "mb-8 flex flex-col items-center gap-4 text-center", children: /* @__PURE__ */ jsx(Link, { href: home(), children: /* @__PURE__ */ jsx(AppLogoIcon, { className: "h-12 w-auto" }) }) }),
      /* @__PURE__ */ jsxs("div", { className: `rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm dark:border-slate-700 dark:bg-slate-800`, children: [
        /* @__PURE__ */ jsx("div", { className: `mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full ${config.bgColor}`, children: /* @__PURE__ */ jsx(Icon, { className: `h-8 w-8 ${config.color}` }) }),
        /* @__PURE__ */ jsx("h1", { className: "mb-2 text-xl font-bold text-slate-900 dark:text-white", children: config.title }),
        /* @__PURE__ */ jsx("p", { className: "mb-6 text-sm text-slate-600 dark:text-slate-400", children: config.description }),
        payment && /* @__PURE__ */ jsx("div", { className: "mb-6 rounded-lg bg-slate-50 p-4 text-left text-sm dark:bg-slate-700", children: /* @__PURE__ */ jsxs("div", { className: "space-y-2 text-slate-700 dark:text-slate-300", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsx("span", { children: "Plan:" }),
            /* @__PURE__ */ jsx("span", { className: "font-medium", children: payment.plan?.name })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsx("span", { children: "Amount:" }),
            /* @__PURE__ */ jsxs("span", { className: "font-medium", children: [
              "K",
              parseFloat(payment.amount).toLocaleString()
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsx("span", { children: "Method:" }),
            /* @__PURE__ */ jsx("span", { className: "font-medium", children: payment.payment_method === "airtel_money" ? "Airtel Money" : "Bank Transfer" })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
          status === "confirmed" && /* @__PURE__ */ jsx(Button, { asChild: true, className: "w-full", children: /* @__PURE__ */ jsx(Link, { href: "/dashboard", children: "Go to Dashboard" }) }),
          status === "rejected" && /* @__PURE__ */ jsx(Button, { asChild: true, className: "w-full", children: /* @__PURE__ */ jsx(Link, { href: "/subscription/select", children: "Try Again" }) }),
          status === "pending" && /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(Button, { asChild: true, variant: "outline", className: "w-full", children: /* @__PURE__ */ jsx(Link, { href: "/subscription/payment-status", children: "Refresh Status" }) }),
            /* @__PURE__ */ jsx("p", { className: "mt-2 text-xs text-slate-500 dark:text-slate-400", children: "You will be able to access the app once your payment is confirmed." })
          ] })
        ] })
      ] })
    ] })
  ] });
}
export {
  PaymentStatus as default
};
