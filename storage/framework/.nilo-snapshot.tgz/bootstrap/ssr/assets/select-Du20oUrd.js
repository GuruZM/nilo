import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { A as AppLogoIcon } from "./app-logo-icon-B5cAnkkG.js";
import { B as Button } from "./button-DMGEFYrU.js";
import { h as home } from "./index-NXMefbOa.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { Star, Check, Crown, Sparkles } from "lucide-react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
function formatPrice(price, currencyCode) {
  const numPrice = parseFloat(price);
  if (numPrice === 0) return "Free";
  return `K${numPrice.toLocaleString()}`;
}
const planIcons = {
  free: /* @__PURE__ */ jsx(Star, { className: "h-6 w-6" }),
  standard: /* @__PURE__ */ jsx(Sparkles, { className: "h-6 w-6" }),
  premium: /* @__PURE__ */ jsx(Crown, { className: "h-6 w-6" }),
  enterprise: /* @__PURE__ */ jsx(Crown, { className: "h-6 w-6" })
};
function Select({ plans, currentPlan }) {
  const { post, processing } = useForm({
    plan_id: 0
  });
  const handleSelect = (plan) => {
    post("/subscription/subscribe", {
      data: { plan_id: plan.id }
    });
  };
  return /* @__PURE__ */ jsxs("div", { className: "flex min-h-svh flex-col items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50 p-6 dark:from-slate-950 dark:to-slate-900", children: [
    /* @__PURE__ */ jsx(Head, { title: "Choose Your Plan" }),
    /* @__PURE__ */ jsxs("div", { className: "w-full max-w-5xl", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-10 flex flex-col items-center gap-4 text-center", children: [
        /* @__PURE__ */ jsx(Link, { href: home(), children: /* @__PURE__ */ jsx(AppLogoIcon, { className: "h-12 w-auto" }) }),
        /* @__PURE__ */ jsx("h1", { className: "text-3xl font-bold text-slate-900 dark:text-white", children: "Choose Your Plan" }),
        /* @__PURE__ */ jsx("p", { className: "max-w-lg text-slate-600 dark:text-slate-400", children: "Select the plan that best fits your business needs. You can upgrade anytime." })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4", children: plans.map((plan) => {
        const isCurrentPlan = currentPlan?.id === plan.id;
        const isPopular = plan.slug === "standard";
        const isEnterprise = plan.slug === "enterprise";
        const features = plan.features ?? [];
        return /* @__PURE__ */ jsxs(
          "div",
          {
            className: `relative flex flex-col rounded-2xl border-2 bg-white p-6 shadow-sm transition-all duration-200 hover:shadow-lg dark:bg-slate-800 ${isPopular ? "border-blue-500 shadow-blue-100 dark:shadow-blue-900/20" : "border-slate-200 dark:border-slate-700"}`,
            children: [
              isPopular && /* @__PURE__ */ jsx("div", { className: "absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-blue-500 px-3 py-1 text-xs font-semibold text-white", children: "Popular" }),
              /* @__PURE__ */ jsxs("div", { className: "mb-4 flex items-center gap-2 text-slate-700 dark:text-slate-300", children: [
                planIcons[plan.slug] ?? /* @__PURE__ */ jsx(Star, { className: "h-6 w-6" }),
                /* @__PURE__ */ jsx("h3", { className: "text-lg font-semibold", children: plan.name })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "mb-1", children: isEnterprise ? /* @__PURE__ */ jsx("span", { className: "text-2xl font-bold text-slate-900 dark:text-white", children: "Custom" }) : /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsx("span", { className: "text-3xl font-bold text-slate-900 dark:text-white", children: formatPrice(
                  plan.price,
                  plan.currency_code
                ) }),
                parseFloat(plan.price) > 0 && /* @__PURE__ */ jsx("span", { className: "text-sm text-slate-500 dark:text-slate-400", children: "/month" })
              ] }) }),
              /* @__PURE__ */ jsx("p", { className: "mb-6 text-sm text-slate-500 dark:text-slate-400", children: plan.description }),
              /* @__PURE__ */ jsx("ul", { className: "mb-6 flex-1 space-y-3", children: features.map((feature) => /* @__PURE__ */ jsxs(
                "li",
                {
                  className: "flex items-start gap-2 text-sm text-slate-700 dark:text-slate-300",
                  children: [
                    /* @__PURE__ */ jsx(Check, { className: "mt-0.5 h-4 w-4 shrink-0 text-green-500" }),
                    feature
                  ]
                },
                feature
              )) }),
              isCurrentPlan ? /* @__PURE__ */ jsx(
                Button,
                {
                  variant: "outline",
                  disabled: true,
                  className: "w-full",
                  children: "Current Plan"
                }
              ) : isEnterprise ? /* @__PURE__ */ jsx(
                Button,
                {
                  variant: "outline",
                  className: "w-full",
                  asChild: true,
                  children: /* @__PURE__ */ jsx(Link, { href: "/subscription/enterprise", children: "Contact Us" })
                }
              ) : /* @__PURE__ */ jsx(
                Button,
                {
                  className: `w-full ${isPopular ? "bg-blue-500 hover:bg-blue-600" : ""}`,
                  disabled: processing,
                  onClick: () => handleSelect(plan),
                  children: processing ? "Processing..." : plan.slug === "free" ? "Get Started Free" : "Subscribe"
                }
              )
            ]
          },
          plan.id
        );
      }) })
    ] })
  ] });
}
export {
  Select as default
};
