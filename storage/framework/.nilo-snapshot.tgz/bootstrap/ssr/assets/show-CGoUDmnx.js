import { jsxs, jsx } from "react/jsx-runtime";
import { A as AppSidebarLayout } from "./app-sidebar-layout-BGzXXcN9.js";
import { B as Button } from "./button-DMGEFYrU.js";
import { Head, Link, router } from "@inertiajs/react";
import { ArrowLeft, CheckCircle, XCircle } from "lucide-react";
import "react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "sonner";
import "clsx";
import "tailwind-merge";
const breadcrumbs = [
  { title: "Admin", href: "/admin" },
  { title: "Payments", href: "/admin/payments" },
  { title: "Payment Detail", href: "#" }
];
function PaymentShow({ payment }) {
  const handleConfirm = () => {
    if (confirm("Confirm this payment and activate the subscription?")) {
      router.post(`/admin/payments/${payment.id}/confirm`);
    }
  };
  const handleReject = () => {
    if (confirm("Reject this payment?")) {
      router.post(`/admin/payments/${payment.id}/reject`);
    }
  };
  return /* @__PURE__ */ jsxs(AppSidebarLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Payment Detail" }),
    /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-3xl space-y-6 p-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsx(Link, { href: "/admin/payments", className: "text-slate-400 hover:text-slate-600 dark:hover:text-slate-300", children: /* @__PURE__ */ jsx(ArrowLeft, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold text-slate-900 dark:text-white", children: [
          "Payment #",
          payment.id
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: [
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4 text-sm", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "User" }),
            /* @__PURE__ */ jsx("p", { className: "font-medium text-slate-900 dark:text-white", children: payment.user.name }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-slate-500", children: payment.user.email })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "Plan" }),
            /* @__PURE__ */ jsx("p", { className: "font-medium text-slate-900 dark:text-white", children: payment.plan.name })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "Amount" }),
            /* @__PURE__ */ jsxs("p", { className: "font-medium text-slate-900 dark:text-white", children: [
              "K",
              parseFloat(payment.amount).toLocaleString()
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "Method" }),
            /* @__PURE__ */ jsx("p", { className: "font-medium text-slate-900 dark:text-white", children: payment.payment_method === "airtel_money" ? "Airtel Money" : "Bank Transfer" })
          ] }),
          payment.phone_number && /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "Phone Number" }),
            /* @__PURE__ */ jsx("p", { className: "font-medium text-slate-900 dark:text-white", children: payment.phone_number })
          ] }),
          payment.payment_reference && /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "Reference" }),
            /* @__PURE__ */ jsx("p", { className: "font-medium text-slate-900 dark:text-white", children: payment.payment_reference })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "Date" }),
            /* @__PURE__ */ jsx("p", { className: "font-medium text-slate-900 dark:text-white", children: new Date(payment.created_at).toLocaleString() })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "Status" }),
            /* @__PURE__ */ jsx("p", { className: "font-medium capitalize text-slate-900 dark:text-white", children: payment.status })
          ] })
        ] }),
        payment.pop_file_path && /* @__PURE__ */ jsxs("div", { className: "mt-6 border-t border-slate-200 pt-4 dark:border-slate-700", children: [
          /* @__PURE__ */ jsx("p", { className: "mb-2 text-sm font-medium text-slate-700 dark:text-slate-300", children: "Proof of Payment" }),
          payment.pop_file_path.endsWith(".pdf") ? /* @__PURE__ */ jsx(
            "a",
            {
              href: `/storage/${payment.pop_file_path}`,
              target: "_blank",
              rel: "noopener noreferrer",
              className: "text-blue-500 hover:text-blue-600",
              children: "View PDF"
            }
          ) : /* @__PURE__ */ jsx(
            "img",
            {
              src: `/storage/${payment.pop_file_path}`,
              alt: "Proof of Payment",
              className: "max-w-md rounded-lg border border-slate-200 dark:border-slate-600"
            }
          )
        ] }),
        payment.status === "pending" && /* @__PURE__ */ jsxs("div", { className: "mt-6 flex gap-3 border-t border-slate-200 pt-4 dark:border-slate-700", children: [
          /* @__PURE__ */ jsxs(Button, { onClick: handleConfirm, children: [
            /* @__PURE__ */ jsx(CheckCircle, { className: "mr-1 h-4 w-4" }),
            "Confirm Payment"
          ] }),
          /* @__PURE__ */ jsxs(Button, { variant: "outline", onClick: handleReject, children: [
            /* @__PURE__ */ jsx(XCircle, { className: "mr-1 h-4 w-4 text-red-500" }),
            "Reject"
          ] })
        ] })
      ] })
    ] })
  ] });
}
export {
  PaymentShow as default
};
