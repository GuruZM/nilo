import { jsxs, jsx } from "react/jsx-runtime";
import { A as AppSidebarLayout } from "./app-sidebar-layout-BGzXXcN9.js";
import { B as Button } from "./button-DMGEFYrU.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { ArrowLeft } from "lucide-react";
import "react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
import "sonner";
import "clsx";
import "tailwind-merge";
function UserShow({ user, plans }) {
  const breadcrumbs = [
    { title: "Admin", href: "/admin" },
    { title: "Users", href: "/admin/users" },
    { title: user.name, href: `/admin/users/${user.id}` }
  ];
  const { data, setData, post, processing } = useForm({
    plan_id: user.subscription?.plan?.id ?? 0
  });
  const handleAssignPlan = (e) => {
    e.preventDefault();
    post(`/admin/users/${user.id}/subscription`);
  };
  return /* @__PURE__ */ jsxs(AppSidebarLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: `Admin - ${user.name}` }),
    /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-4xl space-y-6 p-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsx(Link, { href: "/admin/users", className: "text-slate-400 hover:text-slate-600 dark:hover:text-slate-300", children: /* @__PURE__ */ jsx(ArrowLeft, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-slate-900 dark:text-white", children: user.name })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-6 lg:grid-cols-2", children: [
        /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: [
          /* @__PURE__ */ jsx("h2", { className: "mb-4 text-lg font-semibold text-slate-900 dark:text-white", children: "User Details" }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-3 text-sm", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "Name" }),
              /* @__PURE__ */ jsx("span", { className: "font-medium text-slate-900 dark:text-white", children: user.name })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "Email" }),
              /* @__PURE__ */ jsx("span", { className: "font-medium text-slate-900 dark:text-white", children: user.email })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "Joined" }),
              /* @__PURE__ */ jsx("span", { className: "font-medium text-slate-900 dark:text-white", children: new Date(user.created_at).toLocaleDateString() })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "Companies" }),
              /* @__PURE__ */ jsx("span", { className: "font-medium text-slate-900 dark:text-white", children: user.owned_companies.length })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: [
          /* @__PURE__ */ jsx("h2", { className: "mb-4 text-lg font-semibold text-slate-900 dark:text-white", children: "Subscription" }),
          user.subscription ? /* @__PURE__ */ jsxs("div", { className: "mb-4 space-y-2 text-sm", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "Plan" }),
              /* @__PURE__ */ jsx("span", { className: "font-medium text-slate-900 dark:text-white", children: user.subscription.plan.name })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsx("span", { className: "text-slate-500 dark:text-slate-400", children: "Status" }),
              /* @__PURE__ */ jsx("span", { className: "font-medium capitalize text-slate-900 dark:text-white", children: user.subscription.status.replace("_", " ") })
            ] })
          ] }) : /* @__PURE__ */ jsx("p", { className: "mb-4 text-sm text-slate-500 dark:text-slate-400", children: "No active subscription" }),
          /* @__PURE__ */ jsxs("form", { onSubmit: handleAssignPlan, className: "space-y-3", children: [
            /* @__PURE__ */ jsx("label", { className: "text-sm font-medium text-slate-700 dark:text-slate-300", children: "Assign Plan" }),
            /* @__PURE__ */ jsxs(
              "select",
              {
                value: data.plan_id,
                onChange: (e) => setData("plan_id", Number(e.target.value)),
                className: "w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-600 dark:bg-slate-700 dark:text-white",
                children: [
                  /* @__PURE__ */ jsx("option", { value: 0, children: "Select a plan..." }),
                  plans.map((plan) => /* @__PURE__ */ jsx("option", { value: plan.id, children: plan.name }, plan.id))
                ]
              }
            ),
            /* @__PURE__ */ jsx(Button, { type: "submit", disabled: processing || data.plan_id === 0, className: "w-full", children: processing ? "Assigning..." : "Assign Plan" })
          ] })
        ] })
      ] }),
      user.payments.length > 0 && /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: [
        /* @__PURE__ */ jsx("h2", { className: "mb-4 text-lg font-semibold text-slate-900 dark:text-white", children: "Payment History" }),
        /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-sm", children: [
          /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "border-b border-slate-200 dark:border-slate-700", children: [
            /* @__PURE__ */ jsx("th", { className: "pb-2 text-left font-medium text-slate-500 dark:text-slate-400", children: "Plan" }),
            /* @__PURE__ */ jsx("th", { className: "pb-2 text-left font-medium text-slate-500 dark:text-slate-400", children: "Amount" }),
            /* @__PURE__ */ jsx("th", { className: "pb-2 text-left font-medium text-slate-500 dark:text-slate-400", children: "Method" }),
            /* @__PURE__ */ jsx("th", { className: "pb-2 text-left font-medium text-slate-500 dark:text-slate-400", children: "Status" }),
            /* @__PURE__ */ jsx("th", { className: "pb-2 text-left font-medium text-slate-500 dark:text-slate-400", children: "Date" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-slate-100 dark:divide-slate-700", children: user.payments.map((payment) => /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { className: "py-2 text-slate-900 dark:text-white", children: payment.plan.name }),
            /* @__PURE__ */ jsxs("td", { className: "py-2 text-slate-900 dark:text-white", children: [
              "K",
              parseFloat(payment.amount).toLocaleString()
            ] }),
            /* @__PURE__ */ jsx("td", { className: "py-2 text-slate-700 dark:text-slate-300", children: payment.payment_method === "airtel_money" ? "Airtel Money" : "Bank Transfer" }),
            /* @__PURE__ */ jsx("td", { className: "py-2", children: /* @__PURE__ */ jsx("span", { className: `inline-block rounded-full px-2 py-0.5 text-xs font-medium ${payment.status === "confirmed" ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" : payment.status === "pending" ? "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400" : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"}`, children: payment.status }) }),
            /* @__PURE__ */ jsx("td", { className: "py-2 text-slate-500 dark:text-slate-400", children: new Date(payment.created_at).toLocaleDateString() })
          ] }, payment.id)) })
        ] }) })
      ] })
    ] })
  ] });
}
export {
  UserShow as default
};
