import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { usePage, Head, router } from "@inertiajs/react";
import { motion } from "framer-motion";
import { FileText, CheckCircle2, Eye, Printer, Download, RefreshCw } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";
import { c as cn, B as Button } from "./button-DMGEFYrU.js";
import { C as Card } from "./card-MypPWj87.js";
import { S as Separator } from "./separator-Bcia5PKZ.js";
import { A as AppLayout } from "./app-layout-JvxHjkrs.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-separator";
import "./Chatbot-yoo4250k.js";
import "./app-sidebar-layout-BGzXXcN9.js";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "./index-NXMefbOa.js";
import "./index-DPKrZTLE.js";
function InvoiceShow({ invoice }) {
  const page = usePage();
  React.useEffect(() => {
    const s = page.props?.flash?.success;
    const e = page.props?.flash?.error;
    const i = page.props?.flash?.info;
    if (s) toast.success(s);
    if (e) toast.error(e);
    if (i) toast.message(i);
  }, [
    page.props?.flash?.success,
    page.props?.flash?.error,
    page.props?.flash?.info
  ]);
  const breadcrumbs = [
    { title: "Invoices", href: "/invoices" },
    {
      title: invoice.number ?? `Invoice #${invoice.id}`,
      href: `/invoices/${invoice.id}`
    }
  ];
  const money = (n) => `${invoice.currency_code} ${Number.isFinite(n) ? n.toFixed(2) : "0.00"}`;
  const preview = () => {
    window.open(
      `/invoices/${invoice.id}/preview`,
      "_blank",
      "noopener,noreferrer"
    );
  };
  const print = () => {
    window.open(
      `/invoices/${invoice.id}/print`,
      "_blank",
      "noopener,noreferrer"
    );
  };
  const downloadPdf = () => {
    window.open(
      `/invoices/${invoice.id}/print?download=1`,
      "_blank",
      "noopener,noreferrer"
    );
  };
  const toggleStatus = () => {
    const nextStatus = invoice.status === "paid" ? "pending" : "paid";
    router.post(
      `/invoices/${invoice.id}/status`,
      { status: nextStatus },
      {
        preserveScroll: true,
        preserveState: false,
        onSuccess: () => {
          toast.success(`Invoice marked as ${nextStatus}.`);
          router.reload({ only: ["invoice", "flash"] });
        },
        onError: (errors) => {
          toast.error(
            errors?.status || errors?.invoice || "Failed to update invoice status."
          );
        }
      }
    );
  };
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(
      Head,
      {
        title: invoice.number ? `Invoice ${invoice.number}` : "Invoice"
      }
    ),
    /* @__PURE__ */ jsxs(
      motion.div,
      {
        initial: { opacity: 0, y: 14 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.25, ease: "easeOut" },
        className: "mx-auto w-full px-4 py-10 sm:px-6",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-6 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "grid h-11 w-11 place-items-center rounded-2xl bg-muted", children: /* @__PURE__ */ jsx(FileText, { className: "h-6 w-6 text-foreground/80" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight sm:text-3xl", children: invoice.number ?? `Invoice #${invoice.id}` }),
                /* @__PURE__ */ jsxs("div", { className: "mt-1 text-sm text-muted-foreground", children: [
                  "Status:",
                  " ",
                  /* @__PURE__ */ jsxs(
                    "span",
                    {
                      className: cn(
                        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold",
                        invoice.status === "paid" ? "bg-emerald-500/10 text-emerald-600" : "bg-amber-500/10 text-amber-600"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(CheckCircle2, { className: "h-3.5 w-3.5" }),
                        invoice.status
                      ]
                    }
                  )
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
              /* @__PURE__ */ jsxs(
                Button,
                {
                  type: "button",
                  variant: "outline",
                  onClick: preview,
                  className: "gap-2 rounded-xl",
                  children: [
                    /* @__PURE__ */ jsx(Eye, { className: "h-4 w-4" }),
                    "Preview"
                  ]
                }
              ),
              /* @__PURE__ */ jsxs(
                Button,
                {
                  type: "button",
                  variant: "outline",
                  onClick: print,
                  className: "gap-2 rounded-xl",
                  children: [
                    /* @__PURE__ */ jsx(Printer, { className: "h-4 w-4" }),
                    "Print"
                  ]
                }
              ),
              /* @__PURE__ */ jsxs(
                Button,
                {
                  type: "button",
                  variant: "outline",
                  onClick: downloadPdf,
                  className: "gap-2 rounded-xl",
                  children: [
                    /* @__PURE__ */ jsx(Download, { className: "h-4 w-4" }),
                    "Download PDF"
                  ]
                }
              ),
              /* @__PURE__ */ jsxs(
                Button,
                {
                  type: "button",
                  onClick: toggleStatus,
                  className: "gap-2 rounded-xl transition-transform hover:scale-[1.02] active:scale-[0.98]",
                  children: [
                    /* @__PURE__ */ jsx(RefreshCw, { className: "h-4 w-4" }),
                    invoice.status === "paid" ? "Mark as pending" : "Mark as paid"
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-6 lg:grid-cols-12", children: [
            /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-8", children: [
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
                /* @__PURE__ */ jsx(
                  Info,
                  {
                    label: "Client",
                    value: invoice.client?.name ?? "—"
                  }
                ),
                /* @__PURE__ */ jsx(
                  Info,
                  {
                    label: "Issue date",
                    value: invoice.issue_date
                  }
                ),
                /* @__PURE__ */ jsx(
                  Info,
                  {
                    label: "Due date",
                    value: invoice.due_date ?? "—"
                  }
                ),
                /* @__PURE__ */ jsx(
                  Info,
                  {
                    label: "Reference",
                    value: invoice.reference ?? "—"
                  }
                )
              ] }),
              /* @__PURE__ */ jsx(Separator, { className: "my-6" }),
              /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border", children: [
                /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-12 gap-2 border-b bg-muted/40 px-4 py-3 text-xs font-semibold text-muted-foreground", children: [
                  /* @__PURE__ */ jsx("div", { className: "col-span-6", children: "Description" }),
                  /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: "Qty" }),
                  /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: "Price" }),
                  /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: "Line" })
                ] }),
                /* @__PURE__ */ jsx("div", { className: "divide-y", children: invoice.items.map((it) => /* @__PURE__ */ jsxs(
                  "div",
                  {
                    className: "grid grid-cols-12 gap-2 px-4 py-3 text-sm",
                    children: [
                      /* @__PURE__ */ jsxs("div", { className: "col-span-6 min-w-0", children: [
                        /* @__PURE__ */ jsx("div", { className: "truncate font-medium", children: it.description }),
                        it.unit ? /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground", children: [
                          "Unit: ",
                          it.unit
                        ] }) : null
                      ] }),
                      /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: Number(it.quantity).toFixed(2) }),
                      /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right", children: money(Number(it.unit_price)) }),
                      /* @__PURE__ */ jsx("div", { className: "col-span-2 text-right font-semibold", children: money(Number(it.line_total)) })
                    ]
                  },
                  it.id
                )) })
              ] }),
              (invoice.notes || invoice.terms) && /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsx(Separator, { className: "my-6" }),
                invoice.notes ? /* @__PURE__ */ jsx(
                  Block,
                  {
                    title: "Notes",
                    value: invoice.notes
                  }
                ) : null,
                invoice.terms ? /* @__PURE__ */ jsx(
                  Block,
                  {
                    title: "Terms",
                    value: invoice.terms
                  }
                ) : null
              ] })
            ] }),
            /* @__PURE__ */ jsxs(Card, { className: "rounded-2xl border bg-background p-6 shadow-sm lg:col-span-4", children: [
              /* @__PURE__ */ jsx("div", { className: "mb-3 text-sm font-semibold", children: "Totals" }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-2 rounded-2xl border bg-muted/20 p-4", children: [
                /* @__PURE__ */ jsx(
                  TotalRow,
                  {
                    label: "Subtotal",
                    value: money(invoice.subtotal)
                  }
                ),
                /* @__PURE__ */ jsx(
                  TotalRow,
                  {
                    label: "Line discount",
                    value: money(invoice.discount_total)
                  }
                ),
                /* @__PURE__ */ jsx(
                  TotalRow,
                  {
                    label: "Invoice discount",
                    value: money(
                      Number(invoice.invoice_discount ?? 0)
                    )
                  }
                ),
                /* @__PURE__ */ jsx(
                  TotalRow,
                  {
                    label: "Tax",
                    value: money(invoice.tax_total)
                  }
                ),
                /* @__PURE__ */ jsx(Separator, { className: "my-2" }),
                /* @__PURE__ */ jsx(
                  TotalRow,
                  {
                    label: "Total",
                    value: money(invoice.total),
                    strong: true
                  }
                )
              ] })
            ] })
          ] })
        ]
      }
    )
  ] });
}
function Info({ label, value }) {
  return /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border p-4", children: [
    /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: label }),
    /* @__PURE__ */ jsx("div", { className: "mt-1 text-sm font-semibold", children: value })
  ] });
}
function TotalRow({
  label,
  value,
  strong
}) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
    /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground", children: label }),
    /* @__PURE__ */ jsx(
      "span",
      {
        className: cn("text-sm", strong && "text-base font-semibold"),
        children: value
      }
    )
  ] });
}
function Block({ title, value }) {
  return /* @__PURE__ */ jsxs("div", { className: "mt-4 rounded-2xl border p-4", children: [
    /* @__PURE__ */ jsx("div", { className: "text-xs font-semibold text-muted-foreground", children: title }),
    /* @__PURE__ */ jsx("div", { className: "mt-2 text-sm whitespace-pre-wrap", children: value })
  ] });
}
export {
  InvoiceShow as default
};
