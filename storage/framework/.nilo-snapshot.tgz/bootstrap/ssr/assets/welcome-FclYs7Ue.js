import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { C as Chatbot } from "./Chatbot-yoo4250k.js";
import { useReducedMotion, motion, useScroll, useTransform } from "framer-motion";
import { Zap, MessageSquarePlus, TrendingUp, ArrowRight, UserPlus, FileText, Send, Sun, Moon, X, Menu, Check } from "lucide-react";
import { A as AppLogoIcon } from "./app-logo-icon-B5cAnkkG.js";
import { r as register, l as login, h as home, d as dashboard } from "./index-NXMefbOa.js";
import { Link, usePage, Head } from "@inertiajs/react";
import { P as PaperSheet, C as CheckedDocument } from "./PaperGlyphs-ClQ5oP_s.js";
import { u as useAppearance } from "./use-appearance-CnmYxJGn.js";
import { useState, useEffect } from "react";
const features = [
  {
    icon: Zap,
    title: "Nothing to manage",
    desc: "Sign in and send. Nilo takes care of the setup, updates, and maintenance, so you never hire anyone to run it."
  },
  {
    icon: MessageSquarePlus,
    title: "You ask, we build",
    desc: "Request new features and changes from your plan. Your requests shape what Nilo becomes."
  },
  {
    icon: TrendingUp,
    title: "Grows with you",
    desc: "Start free with one company and one invoice. Add companies, templates, and volume as the work comes in."
  }
];
function About() {
  const reducedMotion = useReducedMotion();
  const reveal = {
    initial: { opacity: 0, y: reducedMotion ? 0 : 40 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true, margin: "-80px" }
  };
  return /* @__PURE__ */ jsxs("section", { id: "about", className: "relative overflow-hidden bg-background py-24", children: [
    /* @__PURE__ */ jsx(
      "div",
      {
        "aria-hidden": true,
        className: "absolute -top-24 -left-32 h-96 w-96 rounded-full bg-brand-100/50 blur-3xl dark:bg-brand-900/20"
      }
    ),
    /* @__PURE__ */ jsx(
      "div",
      {
        "aria-hidden": true,
        className: "absolute right-[-8rem] bottom-[-6rem] h-80 w-80 rounded-full bg-brand-50 blur-3xl dark:bg-brand-950/40"
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "relative mx-auto max-w-7xl px-6", children: [
      /* @__PURE__ */ jsx(
        motion.h2,
        {
          ...reveal,
          transition: { duration: 0.5, ease: "easeOut" },
          className: "text-3xl font-bold text-brand sm:text-4xl dark:text-brand-300",
          children: "Built for startups"
        }
      ),
      /* @__PURE__ */ jsx(
        motion.p,
        {
          ...reveal,
          transition: { duration: 0.5, ease: "easeOut", delay: 0.1 },
          className: "mt-6 max-w-2xl text-lg text-muted-foreground",
          children: "Big systems need someone to run them. Nilo asks nothing from you beyond a sign-in: your invoices, quotations, and payments live in one place, billed in your own currency, ready before your first client calls."
        }
      ),
      /* @__PURE__ */ jsx(
        motion.div,
        {
          className: "mt-14 grid gap-6 md:grid-cols-3",
          initial: "hidden",
          whileInView: "visible",
          viewport: { once: true, margin: "-80px" },
          variants: {
            hidden: {},
            visible: {
              transition: { staggerChildren: reducedMotion ? 0 : 0.12 }
            }
          },
          children: features.map((feature) => /* @__PURE__ */ jsxs(
            motion.div,
            {
              variants: {
                hidden: { opacity: 0, y: reducedMotion ? 0 : 40 },
                visible: {
                  opacity: 1,
                  y: 0,
                  transition: { duration: 0.5, ease: "easeOut" }
                }
              },
              whileHover: reducedMotion ? {} : { y: -6 },
              className: "group rounded-2xl border border-border bg-card p-8 shadow-sm shadow-brand-900/5 transition-[box-shadow,border-color] duration-300 hover:border-brand/30 hover:shadow-xl hover:shadow-brand-900/10",
              children: [
                /* @__PURE__ */ jsx("div", { className: "flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 text-brand transition-colors duration-300 group-hover:bg-brand group-hover:text-white dark:bg-brand-950/60 dark:text-brand-300 dark:group-hover:bg-brand-300 dark:group-hover:text-brand-950", children: /* @__PURE__ */ jsx(feature.icon, { className: "h-6 w-6" }) }),
                /* @__PURE__ */ jsx("h3", { className: "mt-5 text-xl font-bold", children: feature.title }),
                /* @__PURE__ */ jsx("p", { className: "mt-2 text-muted-foreground", children: feature.desc })
              ]
            },
            feature.title
          ))
        }
      )
    ] })
  ] });
}
const links = [
  { href: "#about", label: "About" },
  { href: "#features", label: "How it works" },
  { href: "#pricing", label: "Pricing" }
];
function Footer() {
  const reducedMotion = useReducedMotion();
  return /* @__PURE__ */ jsxs("footer", { className: "relative overflow-hidden bg-gradient-to-b from-brand-900 to-brand-950 text-white", children: [
    /* @__PURE__ */ jsx(
      "div",
      {
        "aria-hidden": true,
        className: "absolute -top-32 right-[-8rem] h-96 w-96 rounded-full bg-brand-500/15 blur-3xl"
      }
    ),
    /* @__PURE__ */ jsx(
      "div",
      {
        "aria-hidden": true,
        className: "absolute bottom-[-10rem] left-[-6rem] h-80 w-80 rounded-full bg-brand-400/10 blur-3xl"
      }
    ),
    /* @__PURE__ */ jsxs(
      motion.div,
      {
        className: "relative mx-auto max-w-7xl px-6 py-20",
        initial: { opacity: 0, y: reducedMotion ? 0 : 32 },
        whileInView: { opacity: 1, y: 0 },
        transition: { duration: 0.4, ease: "easeOut" },
        viewport: { once: true },
        children: [
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-8 border-b border-white/10 pb-16 lg:flex-row lg:items-end lg:justify-between", children: [
            /* @__PURE__ */ jsxs("h2", { className: "max-w-xl text-3xl leading-tight font-bold sm:text-4xl", children: [
              "Ready to send",
              " ",
              /* @__PURE__ */ jsx("span", { className: "text-brand-300", children: "your first invoice?" })
            ] }),
            /* @__PURE__ */ jsxs(
              Link,
              {
                href: register(),
                className: "group inline-flex w-fit items-center gap-2 rounded-lg bg-white px-8 py-4 text-sm font-semibold tracking-wider text-brand-900 uppercase shadow-lg shadow-brand-950/40 transition-all duration-300 hover:-translate-y-0.5 hover:bg-brand-50 hover:shadow-xl active:translate-y-0",
                children: [
                  "Start free",
                  /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-10 pt-16 md:flex-row md:justify-between", children: [
            /* @__PURE__ */ jsx(AppLogoIcon, { className: "h-12 w-auto self-start brightness-0 invert" }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-x-16 gap-y-10", children: [
              /* @__PURE__ */ jsx("nav", { className: "flex flex-col gap-3 text-sm", "aria-label": "Footer", children: links.map((link) => /* @__PURE__ */ jsx(
                "a",
                {
                  href: link.href,
                  className: "text-white/70 transition-colors hover:text-white",
                  children: link.label
                },
                link.href
              )) }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-3 text-sm", children: [
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: login(),
                    className: "text-white/70 transition-colors hover:text-white",
                    children: "Log in"
                  }
                ),
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: register(),
                    className: "text-white/70 transition-colors hover:text-white",
                    children: "Register"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { id: "contact", className: "flex flex-col gap-3 text-sm", children: [
                /* @__PURE__ */ jsx("span", { className: "font-semibold text-white", children: "Contact" }),
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "/subscription/enterprise",
                    className: "text-white/70 transition-colors hover:text-white",
                    children: "Enterprise inquiries"
                  }
                )
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-16 flex flex-col gap-2 border-t border-white/10 pt-6 text-xs text-white/50 sm:flex-row sm:items-center sm:justify-between", children: [
            /* @__PURE__ */ jsxs("span", { children: [
              "© ",
              (/* @__PURE__ */ new Date()).getFullYear(),
              " Nilo. All rights reserved."
            ] }),
            /* @__PURE__ */ jsx("span", { children: "Crafted by Resonantt" })
          ] })
        ]
      }
    )
  ] });
}
function Hero() {
  const reducedMotion = useReducedMotion();
  const { scrollY } = useScroll();
  const shapeY = useTransform(scrollY, [0, 600], [0, reducedMotion ? 0 : 90]);
  const contentY = useTransform(
    scrollY,
    [0, 600],
    [0, reducedMotion ? 0 : -40]
  );
  const container = {
    hidden: {},
    visible: { transition: { staggerChildren: reducedMotion ? 0 : 0.08 } }
  };
  const item = {
    hidden: { opacity: 0, y: reducedMotion ? 0 : 28 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5, ease: "easeOut" }
    }
  };
  const float = (duration, distance) => reducedMotion ? {} : {
    animate: { y: [0, -distance, 0] },
    transition: {
      duration,
      repeat: Infinity,
      ease: "easeInOut"
    }
  };
  return /* @__PURE__ */ jsxs("section", { className: "relative overflow-hidden bg-gradient-to-br from-brand-700 via-brand-800 to-brand-950", children: [
    /* @__PURE__ */ jsxs(motion.div, { "aria-hidden": true, style: { y: shapeY }, className: "absolute inset-0", children: [
      /* @__PURE__ */ jsx(
        motion.div,
        {
          ...float(10, 24),
          className: "absolute -top-32 -right-24 h-[28rem] w-[28rem] rounded-full bg-gradient-to-br from-brand-400/30 to-brand-600/10 blur-3xl"
        }
      ),
      /* @__PURE__ */ jsx(
        motion.div,
        {
          ...float(14, 32),
          className: "absolute -bottom-40 left-1/4 h-[24rem] w-[24rem] rounded-full bg-gradient-to-tr from-brand-300/20 to-transparent blur-3xl"
        }
      ),
      /* @__PURE__ */ jsx(
        motion.div,
        {
          ...float(11, 22),
          className: "absolute top-[14%] right-[6%] hidden rotate-[24deg] opacity-30 lg:block",
          children: /* @__PURE__ */ jsx(PaperSheet, { className: "h-24 w-20" })
        }
      ),
      /* @__PURE__ */ jsx(
        motion.div,
        {
          ...float(14, 18),
          className: "absolute top-[30%] right-[22%] hidden -rotate-12 opacity-45 lg:block",
          children: /* @__PURE__ */ jsx(PaperSheet, { className: "h-28 w-24" })
        }
      ),
      /* @__PURE__ */ jsx(
        motion.div,
        {
          ...float(17, 14),
          className: "absolute top-[52%] right-[30%] hidden rotate-[8deg] opacity-60 lg:block",
          children: /* @__PURE__ */ jsx(PaperSheet, { className: "h-24 w-20" })
        }
      ),
      /* @__PURE__ */ jsx(
        motion.div,
        {
          ...float(13, 16),
          className: "absolute top-[46%] right-[8%] hidden drop-shadow-[0_20px_40px_rgba(0,18,38,0.5)] lg:block",
          children: /* @__PURE__ */ jsx(CheckedDocument, { className: "h-56 w-44" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxs(
      motion.div,
      {
        className: "relative mx-auto flex min-h-svh w-full max-w-7xl flex-col justify-center px-6 pt-24 pb-16",
        style: { y: contentY },
        variants: container,
        initial: "hidden",
        animate: "visible",
        children: [
          /* @__PURE__ */ jsxs(
            motion.h1,
            {
              variants: item,
              className: "max-w-3xl text-5xl leading-tight font-bold text-white sm:text-6xl lg:text-7xl",
              children: [
                "The paperwork lives",
                " ",
                /* @__PURE__ */ jsx("span", { className: "animate-shimmer bg-[linear-gradient(110deg,var(--color-orange-500),45%,var(--color-orange-200),55%,var(--color-orange-500))] bg-[length:200%_100%] bg-clip-text text-transparent", children: "here." })
              ]
            }
          ),
          /* @__PURE__ */ jsx(
            motion.p,
            {
              variants: item,
              className: "mt-6 max-w-xl text-lg leading-relaxed text-brand-100",
              children: "Nilo is the business repository for SMEs: invoices, quotations, clients, and payments, with no system to manage. When your business needs more, you ask and we build it."
            }
          ),
          /* @__PURE__ */ jsxs(motion.div, { variants: item, className: "mt-10 flex flex-wrap items-center gap-4", children: [
            /* @__PURE__ */ jsxs(
              Link,
              {
                href: register(),
                className: "group inline-flex items-center gap-2 rounded-lg bg-white px-8 py-4 text-base font-semibold text-brand-900 shadow-lg shadow-brand-950/40 transition-all duration-300 hover:-translate-y-0.5 hover:bg-brand-50 hover:shadow-xl hover:shadow-brand-950/50 active:translate-y-0",
                children: [
                  "Start free",
                  /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" })
                ]
              }
            ),
            /* @__PURE__ */ jsx(
              "a",
              {
                href: "#pricing",
                className: "inline-flex items-center rounded-lg border border-white/40 px-8 py-4 text-base font-semibold text-white backdrop-blur-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-white hover:bg-white/10 active:translate-y-0",
                children: "See pricing"
              }
            )
          ] })
        ]
      }
    )
  ] });
}
const steps = [
  {
    icon: UserPlus,
    title: "Create your account",
    desc: "Sign up free and add your company profile and logo."
  },
  {
    icon: FileText,
    title: "Build the document",
    desc: "Pick a template, add line items, and Nilo totals it in your currency."
  },
  {
    icon: Send,
    title: "Send and track",
    desc: "Deliver it to your client and watch the status move from sent to paid."
  }
];
function HowItWorks() {
  const reducedMotion = useReducedMotion();
  const reveal = {
    initial: { opacity: 0, y: reducedMotion ? 0 : 40 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true, margin: "-80px" }
  };
  return /* @__PURE__ */ jsxs(
    "section",
    {
      id: "features",
      className: "relative overflow-hidden bg-gradient-to-b from-brand-50/70 via-brand-50/30 to-background py-24 dark:from-brand-950/40 dark:via-brand-950/20 dark:to-background",
      children: [
        /* @__PURE__ */ jsx(
          "div",
          {
            "aria-hidden": true,
            className: "absolute top-1/3 -right-24 h-96 w-96 rounded-full bg-brand-100/60 blur-3xl dark:bg-brand-900/20"
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "relative mx-auto max-w-7xl px-6", children: [
          /* @__PURE__ */ jsx(
            motion.h2,
            {
              ...reveal,
              transition: { duration: 0.5, ease: "easeOut" },
              className: "text-3xl font-bold text-brand sm:text-4xl dark:text-brand-300",
              children: "From quote to cash in three steps"
            }
          ),
          /* @__PURE__ */ jsx(
            motion.p,
            {
              ...reveal,
              transition: { duration: 0.5, ease: "easeOut", delay: 0.1 },
              className: "mt-6 max-w-2xl text-lg text-muted-foreground",
              children: "Everything runs in the browser. No installs, no spreadsheets."
            }
          ),
          /* @__PURE__ */ jsx("div", { className: "mt-14 grid gap-6 md:grid-cols-3", children: steps.map((step, i) => /* @__PURE__ */ jsxs(
            motion.div,
            {
              ...reveal,
              transition: {
                duration: 0.5,
                ease: "easeOut",
                delay: reducedMotion ? 0 : i * 0.12
              },
              whileHover: reducedMotion ? {} : { y: -6 },
              className: "group rounded-2xl border border-border bg-card p-8 shadow-sm shadow-brand-900/5 transition-[box-shadow,border-color] duration-300 hover:border-brand/30 hover:shadow-xl hover:shadow-brand-900/10",
              children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsx("span", { className: "flex h-10 w-10 items-center justify-center rounded-xl bg-brand text-sm font-bold text-white shadow-md shadow-brand-900/20 transition-transform duration-300 group-hover:scale-110", children: i + 1 }),
                  /* @__PURE__ */ jsx(step.icon, { className: "h-6 w-6 text-brand dark:text-brand-300" })
                ] }),
                /* @__PURE__ */ jsx("h3", { className: "mt-5 text-xl font-bold", children: step.title }),
                /* @__PURE__ */ jsx("p", { className: "mt-2 text-muted-foreground", children: step.desc })
              ]
            },
            step.title
          )) })
        ] })
      ]
    }
  );
}
const sections = [
  { href: "#about", label: "About" },
  { href: "#features", label: "How it works" },
  { href: "#pricing", label: "Pricing" },
  { href: "#contact", label: "Contact" }
];
function Nav() {
  const { auth } = usePage().props;
  const { appearance, updateAppearance } = useAppearance();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [isDark, setIsDark] = useState(false);
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  useEffect(() => {
    setIsDark(document.documentElement.classList.contains("dark"));
  }, [appearance]);
  const toggleTheme = () => updateAppearance(isDark ? "light" : "dark");
  const onDark = !scrolled;
  const linkClass = onDark ? "text-white/80 hover:text-white" : "text-foreground/70 hover:text-foreground";
  return /* @__PURE__ */ jsx(
    "nav",
    {
      className: `fixed top-0 z-50 w-full transition-all duration-300 ${scrolled ? "border-b border-border bg-background/90 shadow-md shadow-brand-950/5 backdrop-blur-xl" : "bg-transparent"}`,
      children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-7xl px-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex h-16 items-center justify-between", children: [
          /* @__PURE__ */ jsx(Link, { href: home(), "aria-label": "Nilo home", children: /* @__PURE__ */ jsx(
            AppLogoIcon,
            {
              className: `h-9 w-auto transition-all duration-300 ${onDark ? "brightness-0 invert" : "dark:brightness-0 dark:invert"}`
            }
          ) }),
          /* @__PURE__ */ jsxs("div", { className: "hidden items-center gap-8 md:flex", children: [
            sections.map((item) => /* @__PURE__ */ jsx(
              "a",
              {
                href: item.href,
                className: `text-sm font-medium transition-colors duration-200 ${linkClass}`,
                children: item.label
              },
              item.href
            )),
            auth?.user ? /* @__PURE__ */ jsx(
              Link,
              {
                href: dashboard(),
                className: `rounded-lg px-5 py-2.5 text-sm font-semibold shadow-md shadow-brand-950/20 transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0 ${onDark ? "bg-white text-brand-900 hover:bg-brand-100" : "bg-brand text-white hover:bg-brand-700"}`,
                children: "Dashboard"
              }
            ) : /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx(
                Link,
                {
                  href: login(),
                  className: `text-sm font-medium transition-colors duration-200 ${linkClass}`,
                  children: "Log in"
                }
              ),
              /* @__PURE__ */ jsx(
                Link,
                {
                  href: register(),
                  className: `rounded-lg px-5 py-2.5 text-sm font-semibold shadow-md shadow-brand-950/20 transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0 ${onDark ? "bg-white text-brand-900 hover:bg-brand-100" : "bg-brand text-white hover:bg-brand-700"}`,
                  children: "Get started"
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: toggleTheme,
                "aria-label": isDark ? "Switch to light mode" : "Switch to dark mode",
                className: `cursor-pointer rounded-lg p-2 transition-colors duration-200 ${linkClass}`,
                children: isDark ? /* @__PURE__ */ jsx(Sun, { className: "h-5 w-5" }) : /* @__PURE__ */ jsx(Moon, { className: "h-5 w-5" })
              }
            )
          ] }),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              className: `cursor-pointer p-2 md:hidden ${onDark ? "text-white" : "text-foreground"}`,
              onClick: () => setMobileMenuOpen(!mobileMenuOpen),
              "aria-label": mobileMenuOpen ? "Close menu" : "Open menu",
              children: mobileMenuOpen ? /* @__PURE__ */ jsx(X, { className: "h-6 w-6" }) : /* @__PURE__ */ jsx(Menu, { className: "h-6 w-6" })
            }
          )
        ] }),
        mobileMenuOpen && /* @__PURE__ */ jsx("div", { className: "mb-4 rounded-2xl border border-border bg-background py-4 shadow-xl shadow-brand-950/10 md:hidden", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-4 px-6", children: [
          sections.map((item) => /* @__PURE__ */ jsx(
            "a",
            {
              href: item.href,
              onClick: () => setMobileMenuOpen(false),
              className: "text-sm font-medium text-foreground/80 transition-colors hover:text-foreground",
              children: item.label
            },
            item.href
          )),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-t border-border pt-4", children: [
            auth?.user ? /* @__PURE__ */ jsx(
              Link,
              {
                href: dashboard(),
                className: "rounded-lg bg-brand px-5 py-2.5 text-sm font-semibold text-white shadow-md shadow-brand-900/20 transition-all duration-300 hover:-translate-y-0.5 hover:bg-brand-700 active:translate-y-0",
                children: "Dashboard"
              }
            ) : /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsx(
                Link,
                {
                  href: login(),
                  className: "text-sm font-medium text-foreground/80 hover:text-foreground",
                  children: "Log in"
                }
              ),
              /* @__PURE__ */ jsx(
                Link,
                {
                  href: register(),
                  className: "rounded-lg bg-brand px-5 py-2.5 text-sm font-semibold text-white shadow-md shadow-brand-900/20 transition-all duration-300 hover:-translate-y-0.5 hover:bg-brand-700 active:translate-y-0",
                  children: "Get started"
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: toggleTheme,
                "aria-label": isDark ? "Switch to light mode" : "Switch to dark mode",
                className: "cursor-pointer p-2 text-foreground/70 hover:text-foreground",
                children: isDark ? /* @__PURE__ */ jsx(Sun, { className: "h-5 w-5" }) : /* @__PURE__ */ jsx(Moon, { className: "h-5 w-5" })
              }
            )
          ] })
        ] }) })
      ] })
    }
  );
}
function formatPrice(plan) {
  if (plan.slug === "enterprise") {
    return "Custom";
  }
  const amount = parseFloat(plan.price);
  if (amount === 0) {
    return "Free";
  }
  return new Intl.NumberFormat("en", {
    style: "currency",
    currency: plan.currency_code,
    maximumFractionDigits: 0
  }).format(amount);
}
function periodLabel(plan) {
  if (plan.slug === "enterprise" || parseFloat(plan.price) === 0) {
    return null;
  }
  return plan.billing_period === "yearly" ? "/yr" : "/mo";
}
function ctaLabel(plan) {
  if (plan.slug === "enterprise") {
    return "Contact Us";
  }
  return parseFloat(plan.price) === 0 ? "Get Started" : "Subscribe";
}
function Pricing({ plans }) {
  const reducedMotion = useReducedMotion();
  const reveal = {
    initial: { opacity: 0, y: reducedMotion ? 0 : 32 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true }
  };
  if (!plans?.length) {
    return null;
  }
  return /* @__PURE__ */ jsx("section", { id: "pricing", className: "bg-background py-24", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-7xl px-6", children: [
    /* @__PURE__ */ jsx(
      motion.h2,
      {
        ...reveal,
        transition: { duration: 0.4, ease: "easeOut" },
        className: "text-3xl font-bold text-brand sm:text-4xl dark:text-brand-300",
        children: "Pricing"
      }
    ),
    /* @__PURE__ */ jsx(
      motion.p,
      {
        ...reveal,
        transition: { duration: 0.4, ease: "easeOut", delay: 0.1 },
        className: "mt-6 max-w-2xl text-lg text-muted-foreground",
        children: "Start free with one company and one invoice. Paid plans let you request the features you need, and higher plans get them built first."
      }
    ),
    /* @__PURE__ */ jsx("div", { className: "mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4", children: plans.map((plan, i) => {
      const highlight = plan.slug === "standard";
      const period = periodLabel(plan);
      const href = plan.slug === "enterprise" ? "/subscription/enterprise" : register();
      return /* @__PURE__ */ jsxs(
        motion.div,
        {
          ...reveal,
          transition: {
            duration: 0.4,
            ease: "easeOut",
            delay: reducedMotion ? 0 : i * 0.08
          },
          whileHover: reducedMotion ? {} : { y: -6 },
          className: `relative flex flex-col rounded-2xl p-8 transition-[box-shadow,border-color] duration-300 ${highlight ? "bg-gradient-to-b from-brand-600 to-brand-800 text-white shadow-xl shadow-brand-900/25 hover:shadow-2xl hover:shadow-brand-900/35" : "border border-border bg-card shadow-sm shadow-brand-900/5 hover:border-brand/30 hover:shadow-xl hover:shadow-brand-900/10"}`,
          children: [
            highlight && /* @__PURE__ */ jsx("span", { className: "absolute -top-3 right-8 rounded-md bg-white px-4 py-1.5 text-xs font-bold tracking-wider text-brand-900 uppercase shadow-md shadow-brand-950/20", children: "Popular" }),
            /* @__PURE__ */ jsx(
              "h3",
              {
                className: `text-xl font-bold ${highlight ? "text-white" : "text-foreground"}`,
                children: plan.name
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "mt-4", children: [
              /* @__PURE__ */ jsx("span", { className: "text-3xl font-bold", children: formatPrice(plan) }),
              period && /* @__PURE__ */ jsx(
                "span",
                {
                  className: `text-sm ${highlight ? "text-brand-100" : "text-muted-foreground"}`,
                  children: period
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              "ul",
              {
                className: `mt-6 mb-8 space-y-2 text-sm ${highlight ? "text-brand-100" : "text-muted-foreground"}`,
                children: (plan.features ?? []).map((feature) => /* @__PURE__ */ jsxs("li", { className: "flex items-start gap-2", children: [
                  /* @__PURE__ */ jsx(
                    Check,
                    {
                      className: `mt-0.5 h-4 w-4 shrink-0 ${highlight ? "text-brand-300" : "text-brand dark:text-brand-300"}`
                    }
                  ),
                  feature
                ] }, feature))
              }
            ),
            /* @__PURE__ */ jsx(
              Link,
              {
                href,
                className: `mt-auto rounded-lg px-6 py-3 text-center text-sm font-semibold tracking-wider uppercase transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0 ${highlight ? "bg-white text-brand-900 shadow-lg shadow-brand-950/30 hover:bg-brand-50 hover:shadow-xl" : "border-2 border-brand text-brand hover:bg-brand hover:text-white hover:shadow-lg hover:shadow-brand-900/20 dark:border-brand-300 dark:text-brand-300 dark:hover:bg-brand-300 dark:hover:text-brand-950"}`,
                children: ctaLabel(plan)
              }
            )
          ]
        },
        plan.id
      );
    }) })
  ] }) });
}
function Welcome({ plans }) {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Invoicing for startups and SMEs" }),
    /* @__PURE__ */ jsx(Nav, {}),
    /* @__PURE__ */ jsx(Hero, {}),
    /* @__PURE__ */ jsx(About, {}),
    /* @__PURE__ */ jsx(HowItWorks, {}),
    /* @__PURE__ */ jsx(Pricing, { plans }),
    /* @__PURE__ */ jsx(Footer, {}),
    /* @__PURE__ */ jsx(Chatbot, {})
  ] });
}
export {
  Welcome as default
};
