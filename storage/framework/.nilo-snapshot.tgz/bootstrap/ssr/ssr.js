import { jsx } from "react/jsx-runtime";
import { createInertiaApp } from "@inertiajs/react";
import createServer from "@inertiajs/react/server";
import ReactDOMServer from "react-dom/server";
async function resolvePageComponent(path, pages) {
  for (const p of Array.isArray(path) ? path : [path]) {
    const page = pages[p];
    if (typeof page === "undefined") {
      continue;
    }
    return typeof page === "function" ? page() : page;
  }
  throw new Error(`Page not found: ${path}`);
}
const appName = "Nilo";
createServer(
  (page) => createInertiaApp({
    page,
    render: ReactDOMServer.renderToString,
    title: (title) => title ? `${title} - ${appName}` : appName,
    resolve: (name) => resolvePageComponent(
      `./pages/${name}.tsx`,
      /* @__PURE__ */ Object.assign({ "./pages/Clients/Create.tsx": () => import("./assets/Create-B0Y6lRip.js"), "./pages/Clients/Index.tsx": () => import("./assets/Index-dYPKod2d.js"), "./pages/Companies/Index.tsx": () => import("./assets/Index-DxbulMkz.js"), "./pages/Invoices/Create.tsx": () => import("./assets/Create-DqXbwFHg.js"), "./pages/Invoices/Index.tsx": () => import("./assets/Index-CmlG-oXM.js"), "./pages/Invoices/show.tsx": () => import("./assets/show-N09XCmbk.js"), "./pages/Quotations/Create.tsx": () => import("./assets/Create-BIcruCuJ.js"), "./pages/Quotations/Index.tsx": () => import("./assets/Index-BgpQpA9w.js"), "./pages/admin/dashboard.tsx": () => import("./assets/dashboard-lTmqPtd8.js"), "./pages/admin/inquiries/index.tsx": () => import("./assets/index-DWKNP8Xo.js"), "./pages/admin/payments/index.tsx": () => import("./assets/index-Dkd1ivmO.js"), "./pages/admin/payments/show.tsx": () => import("./assets/show-CGoUDmnx.js"), "./pages/admin/users/index.tsx": () => import("./assets/index-DVPGsCXR.js"), "./pages/admin/users/show.tsx": () => import("./assets/show-DuGZnHya.js"), "./pages/auth/confirm-password.tsx": () => import("./assets/confirm-password-D4IC8Hx6.js"), "./pages/auth/forgot-password.tsx": () => import("./assets/forgot-password-DFV5fjts.js"), "./pages/auth/login.tsx": () => import("./assets/login-25S01rEB.js"), "./pages/auth/register.tsx": () => import("./assets/register-DtnyRymV.js"), "./pages/auth/reset-password.tsx": () => import("./assets/reset-password-Cxo2YAfs.js"), "./pages/auth/two-factor-challenge.tsx": () => import("./assets/two-factor-challenge-oiz0B4GA.js"), "./pages/auth/verify-email.tsx": () => import("./assets/verify-email-NVao4Xtl.js"), "./pages/dashboard.tsx": () => import("./assets/dashboard-C6bTOGSE.js"), "./pages/invoice-create.tsx": () => import("./assets/invoice-create-CggOm1TF.js"), "./pages/settings/appearance.tsx": () => import("./assets/appearance-DeZKXQDO.js"), "./pages/settings/currencies.tsx": () => import("./assets/currencies-BwjATDMC.js"), "./pages/settings/invoicetemplates/builder.tsx": () => import("./assets/builder-BlZPLCD1.js"), "./pages/settings/invoicetemplates/index.tsx": () => import("./assets/index-CAnetkU4.js"), "./pages/settings/password.tsx": () => import("./assets/password-efblReFI.js"), "./pages/settings/profile.tsx": () => import("./assets/profile-DNiDvlQV.js"), "./pages/settings/two-factor.tsx": () => import("./assets/two-factor-UPQDUXdx.js"), "./pages/subscription/current.tsx": () => import("./assets/current-BMMyEZgc.js"), "./pages/subscription/enterprise.tsx": () => import("./assets/enterprise-Bc5auB7Q.js"), "./pages/subscription/payment-status.tsx": () => import("./assets/payment-status-xDjPxZCH.js"), "./pages/subscription/payment.tsx": () => import("./assets/payment-C6J6qB_l.js"), "./pages/subscription/select.tsx": () => import("./assets/select-Du20oUrd.js"), "./pages/welcome.tsx": () => import("./assets/welcome-FclYs7Ue.js") })
    ),
    setup: ({ App, props }) => {
      return /* @__PURE__ */ jsx(App, { ...props });
    }
  })
);
